package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.Address;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Member.Status;
import com.opm.shop.service.ItemServiceLocal;
import com.opm.shop.service.MemberServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MemberDetailBean implements Serializable {

	private List<Item> items;
	private Address member;
	private Member mem;
	private int maxItemSize = 8;

	private Pager pager;

	@Inject
	private MemberServiceLocal service;

	@Inject
	private ItemServiceLocal itemService;

	String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");

	@PostConstruct
	public void init() {
		items = new ArrayList<>();
		mem = service.findById(Long.parseLong(str));
		member = service.findByMember(Long.parseLong(str));
		searchById(1, 0);
	}

	public void searchById(int currentPage, int id) {
		if (currentPage > 0) {
			Long totalSize = itemService.findByMemberId(Integer.parseInt(str), 0, 0).stream().count();
			if ((currentPage - 1) * maxItemSize <= totalSize) {
				pager = new Pager(totalSize.intValue(), currentPage, maxItemSize);
				items.addAll(itemService.findByMemberId(mem.getId(), (currentPage - 1) * maxItemSize, maxItemSize));
			}
		}
	}

	public void ban() {
		mem.setStatus(Status.Ban);
		service.update(mem);
	}

	public String buy() {
		return "";
	}

	public Address getMember() {
		return member;
	}

	public void setMember(Address address) {
		this.member = address;
	}

	public Member getMem() {
		return mem;
	}

	public void setMem(Member mem) {
		this.mem = mem;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public int getMaxItemSize() {
		return maxItemSize;
	}

	public void setMaxItemSize(int maxItemSize) {
		this.maxItemSize = maxItemSize;
	}

	public Pager getPager() {
		return pager;
	}

	public void setPager(Pager pager) {
		this.pager = pager;
	}

}