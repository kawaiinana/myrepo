package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.service.ItemServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class ItemSearchResultBean implements Serializable {

	private List<Item> items;
	
	private String keyword;
	private int brandId;
	private String price;
	private List<Integer> stateId;

	private Member member;
	
	@Inject
	private ItemServiceLocal service;
	
	@Inject
	private CategorySelectBean categoryBean;

	@PostConstruct
	public void init() {
		categoryBean.setFirst(null);
		categoryBean.changeFirst();
			
		/*double startprice = 0;
		double endprice = 0;
		
		if(keyword == null)
			keyword = "";
		
		
		if(null != price && !price.isEmpty()) {
			String[] array = price.split(",");
			startprice = (null !=array[0] ? Double.parseDouble(array[0]) : 0) ;
			endprice = (null !=array[1] ? Double.parseDouble(array[1]) : 0) ;
		} 
		
		items = service.find(keyword,brandId,
				startprice,
				endprice,
				(null != categoryBean.getSelectedCategory() ? categoryBean.getSelectedCategory().getId() : 0));*/
	}

	public String search() {
		double startprice = 0;
		double endprice = 0;
		
		if(keyword == null)
			keyword = "";
		
		
		if(null != price && !price.isEmpty()) {
			String[] array = price.split(",");
			startprice = (null !=array[0] ? Double.parseDouble(array[0]) : 0) ;
			endprice = (null !=array[1] ? Double.parseDouble(array[1]) : 0) ;
		} 
		
		items = service.find(keyword,
				brandId,
				startprice,
				endprice,
				(null != categoryBean.getSelectedCategory() ? categoryBean.getSelectedCategory().getId() : 0));
		
		return "/product-search-result.xhtml?faces-redirect=true";
	}
	
	public String searchBycategoryId(int id){
		items = service.find(id, keyword);
		return "";
	}
	
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public CategorySelectBean getCategoryBean() {
		return categoryBean;
	}

	public void setCategoryBean(CategorySelectBean categoryBean) {
		this.categoryBean = categoryBean;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public List<Integer> getStateId() {
		return stateId;
	}

	public void setStateId(List<Integer> stateId) {
		this.stateId = stateId;
	}
}