package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.Member;
import com.opm.shop.service.MemberServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MemberHomeBean implements Serializable {

	private String name;
	private List<Member> memberList;
	private List<Integer> num;

	@Inject
	private MemberServiceLocal service;

	private int maxItemSize = 10;

	private Pager pager;

	@PostConstruct
	public void init() {
		search(1);
	}

	public void search(int currentPage) {

		if (currentPage > 0) {
			Long totalSize = service.findCount(name);
			if ((currentPage - 1) * maxItemSize <= totalSize) {
				pager = new Pager(totalSize.intValue(), currentPage, maxItemSize);
				memberList = service.find(name, (currentPage - 1) * maxItemSize, maxItemSize);
			}
		}
	}

	public List<Integer> getNum() {
		return num;
	}

	public void setNum(List<Integer> num) {
		this.num = num;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Member> getMemberList() {
		return memberList;
	}

	public void setMemberList(List<Member> memberList) {
		this.memberList = memberList;
	}

	public int getMaxItemSize() {
		return maxItemSize;
	}

	public void setMaxItemSize(int maxItemSize) {
		this.maxItemSize = maxItemSize;
	}

	public Pager getPager() {
		return pager;
	}

	public void setPager(Pager pager) {
		this.pager = pager;
	}

}