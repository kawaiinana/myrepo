package com.opm.shop.rest.util;

import javax.enterprise.inject.Produces;
import javax.enterprise.inject.spi.InjectionPoint;
import javax.ws.rs.core.CacheControl;

public class CacheControlFactory {
	
	@Produces
	public CacheControl get(InjectionPoint ip) {
		CacheConfig ccConfig = ip.getAnnotated().getAnnotation(CacheConfig.class);
		CacheControl cc = null;

		if (null != ccConfig) {
			cc = new CacheControl();
			cc.setMaxAge(ccConfig.maxAge());
			cc.setMustRevalidate(ccConfig.mustRevalidate());
			cc.setNoCache(ccConfig.noCache());
			cc.setNoStore(ccConfig.noStore());
			cc.setNoTransform(ccConfig.noTransform());
			cc.setPrivate(ccConfig.isPrivate());
			cc.setProxyRevalidate(ccConfig.proxyRevalidate());
			cc.setSMaxAge(ccConfig.sMaxAge());
		}

		return cc;
	}
}
