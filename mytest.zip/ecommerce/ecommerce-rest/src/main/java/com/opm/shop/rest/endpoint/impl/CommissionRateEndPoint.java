package com.opm.shop.rest.endpoint.impl;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.opm.shop.service.CommissionRateLocal;

@Path("/commissionRates")
public class CommissionRateEndPoint {

	@Inject
	private CommissionRateLocal service;

	@GET
	@Path("{price}")
	@Produces(MediaType.TEXT_PLAIN)
	public Response calculate(@PathParam("price") double price) {

		if (price > 0) {
			double commissionRate = service.calculateRate(price);
			return Response.ok(commissionRate).build();
		}
		return Response.status(Status.NOT_ACCEPTABLE).entity("Commission rate can't be calculated!").build();

	}
}
