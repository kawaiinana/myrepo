package com.opm.shop.rest.endpoint.impl;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.opm.shop.entity.Country;
import com.opm.shop.service.CountryServiceLocal;

@Path("/countries")
public class CountryEndPoint {

	@Inject
	private CountryServiceLocal service;

	@GET
	@Path("{id: \\d+}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response findById(@PathParam("id") int id) {
		Country country = service.findById(id);

		if (null != country) {
			return Response.ok(country).build();
		}
		return Response.status(Status.NOT_FOUND).entity("Country not found!").build();
	}

	@Path("{name}")
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public Response findByName(@PathParam("name") String name) {
		Country country = service.findByName(name);
		if (null != country) {
			return Response.ok(country).build();
		}
		return Response.status(Status.NOT_FOUND).entity("Country not found!").build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAll() {
		List<Country> country = service.getAll();
		return Response.ok(country).build();
	}

}
