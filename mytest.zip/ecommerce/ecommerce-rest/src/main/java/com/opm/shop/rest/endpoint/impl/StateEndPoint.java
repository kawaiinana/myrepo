package com.opm.shop.rest.endpoint.impl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.opm.shop.entity.Country;
import com.opm.shop.entity.State;
import com.opm.shop.service.StateServiceLocal;

@Path("/states")
public class StateEndPoint {

	@Inject
	private StateServiceLocal service;

	@Path("{id:\\d+}")
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public Response findById(@PathParam("id") int id) {
		State state = service.findById(id);

		if (null != state) {
			return Response.ok(state).build();
		}
		return Response.status(Status.NOT_FOUND).entity("State not found!").build();
	}

	@Path("{name}")
	@Produces(MediaType.APPLICATION_JSON)
	@GET
	public Response findByName(@PathParam("name") String name) {
		State state = service.findByName(name);

		if (null != state) {
			return Response.ok(state).build();
		}
		return Response.status(Status.NOT_FOUND).entity("No state found by this name!").build();
	}

	@Path("findByCountries")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response findByCountries(List<Country> countries) {
		List<State> states = new ArrayList<>();

		countries.forEach(c -> {
			states.addAll(service.findByCountry(c));
		});

		return Response.ok(states).build();
	}

	@Path("findByCountry")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response findByCountry(Country country) {
		List<State> states = service.findByCountry(country);

		return Response.ok(states).build();
	}
}
