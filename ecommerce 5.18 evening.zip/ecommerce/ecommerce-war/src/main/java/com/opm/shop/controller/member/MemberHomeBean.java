package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Member;
import com.opm.shop.service.MemberServiceLocal;


@ViewScoped
@Named
@SuppressWarnings("serial")
public class MemberHomeBean implements Serializable {
   
    private String name;
    private List<Member> memberList;
    
    @Inject
    private MemberServiceLocal service;    

    @PostConstruct
    public void init() {
    	search(name);
    }
    
    public void search(String name) {   
    	memberList = service.find(name);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Member> getMemberList() {
		return memberList;
	}

	public void setMemberList(List<Member> memberList) {
		this.memberList = memberList;
	}

}