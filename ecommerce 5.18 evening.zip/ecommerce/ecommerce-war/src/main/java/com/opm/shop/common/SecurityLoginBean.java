package com.opm.shop.common;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Model;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Member.Status;
import com.opm.shop.service.AccountServiceLocal;

@Model
@SuppressWarnings("serial")
public class SecurityLoginBean implements Serializable{
    
    @NotBlank(message = "Must fill Nick Name.")
    private String name;
    
    @Pattern(regexp="[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\."
            +"[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@"
            +"(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?",
                 message="Enter valid email")
    private String email;
    
    @Pattern(regexp = "[a-zA-Z0-9]+",message="Enter password")
    private String password;
    
    private Member member1;
    private List<Account> accounts;
    
    @Inject
    private AccountServiceLocal service;
    
    @Inject
    private Event<String> loginEvent;
    
    @PostConstruct
    private void init(){
    	accounts = service.findAllAccounts();
    }
    
    public String login(boolean isSignUpMember) {

    	try {
			ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
			HttpServletRequest req = (HttpServletRequest) ctx.getRequest();
			
			req.login(email, password);
			
			loginEvent.fire(email);
			
			if(req.isUserInRole("Admin")) {
				return "/admin/home?faces-redirect=true";
			}
			
			if (isSignUpMember) {
				return "/member/my-profile?faces-redirect=true";
			}
			
			return "/index?faces-redirect=true";
				
		} catch (Exception e) {
			FacesMessage message = new FacesMessage("Login Error", "Please check your Email and Password!");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		
    	return "";
    }

    public String signUp(String confirmPassword) {
    	if (!accounts.stream().filter(a -> a.getEmail().equals(email)).findAny().isPresent()) {
    		if(password.equals(confirmPassword)){
        		Member m = new Member();
            	m.setNickname(name);
            	m.setEmail(email);
            	m.setStatus(Status.Active);
            	m.setPassword(password);
            	
            	service.create(m);
            	
            	boolean isSignUpMember = true;
                return login(isSignUpMember);
        	} else {
        		FacesMessage message = new FacesMessage("Password Error", "This confirm password do not match!");
    			FacesContext.getCurrentInstance().addMessage(null, message);
    		}
		} else {
			FacesMessage message = new FacesMessage("Account Error", "This account already exist.");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
    	
    	return "";
    }

    public String logout() {
		ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
		ctx.invalidateSession();
		return "/index?faces-redirect=true";
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Member getMember() {
		return member1;
	}

	public void setMember(Member member) {
		this.member1 = member;
	}
    
}