package com.opm.shop.converters;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.faces.bean.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.State;
import com.opm.shop.service.StateServiceLocal;

@Named
@RequestScoped
public class StateSetConverter implements Converter{

	@Inject
	private StateServiceLocal service;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		if(null != value && !value.isEmpty()){
			State s = service.findByName(value);
			return s ;
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if(null!= value && value instanceof Set){
			Set<State> set= (Set<State>) value;
			List<State> list=new ArrayList<>(set);
			StringBuffer sb=new StringBuffer();
			for (int i = 0; i < list.size(); i++) {
				if(i>0){
					sb.append(", ");
				}
				sb.append(list.get(i).getName());
			}
			return sb.toString();
		}
		return null;
	}
}
