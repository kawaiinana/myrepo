package com.opm.shop.repo;

import com.opm.shop.entity.ItemState;

public class ItemStateRepo extends AbstractRepository<ItemState> {

	public ItemStateRepo() {
		super(ItemState.class);
	}
}