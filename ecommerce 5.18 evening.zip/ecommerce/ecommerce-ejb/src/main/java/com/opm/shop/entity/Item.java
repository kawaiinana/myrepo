package com.opm.shop.entity;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;
import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.opm.shop.entity.SecurityInfo.Valid;

@SuppressWarnings("serial")
@Entity
public class Item implements Serializable {

	public enum Status {
		Available, SoldOut, Ban
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	@NotBlank
	private String name;

	@NotNull
	private double price;

	@NotNull
	private double commissionRate;

	@NotBlank
	private String size;

	@NotBlank
	private String color;

	@NotBlank
	@Lob
	private String description;

	@Enumerated(STRING)
	private Status status;

	@ManyToOne
	private Member owner;

	@ManyToOne
	private Category category;

	@ManyToOne
	private Brand brand;

	@ManyToOne
	private ItemState itemState;

	@Size(min = 1)
	@ElementCollection(fetch = EAGER)
	private Set<Price> prices;

	@Size(min = 1)
	@ElementCollection(fetch = EAGER)
	private Set<String> image;

	@NotBlank
	private String coverImage;

	@Size(min = 1)
	@ManyToMany(fetch = EAGER)
	private Set<Country> country;

	@Size(min = 1)
	@ManyToMany(fetch = EAGER)
	private Set<State> state;

	@MapKeyColumn(name = "language")
	@ElementCollection
	private Map<String, String> names;

	@MapKeyColumn(name = "language")
	@ElementCollection
	private Map<String, String> descriptions;

	@Embedded
	private SecurityInfo security;

	public Item() {
		security = new SecurityInfo();
		prices = new LinkedHashSet<>();
		image = new LinkedHashSet<>();
		state = new LinkedHashSet<>();
		country = new LinkedHashSet<>();
		coverImage = "";
	}

	@PrePersist
	private void prePersist() {
		security.setCreation(new Date());
		security.setModification(new Date());
		security.setValid(Valid.ON);
	}

	@PreUpdate
	private void preUpdate() {
		security.setModification(new Date());
	}

	public void addPrice(Price price) {
		prices.add(price);
	}

	public void addImage(String img) {
		image.add(img);
	}

	public void removeImage(String img) {
		image.remove(img);
	}

	public void addState(State s) {
		state.add(s);
	}

	public void addCountry(Country c) {
		country.add(c);
	}

	public void addStates(Collection<State> s) {
		state.addAll(s);
	}

	public void addCountries(Collection<Country> c) {
		country.addAll(c);
	}

	private int level() {
		return category.getParent() == null ? 1
				: category.getParent().getParent() == null ? 2
						: category.getParent().getParent().getParent() == null ? 3 : 0;
	}

	public String getFirstCategory() {
		return level() == 1 ? category.getName()
				: level() == 2 ? category.getParent().getName()
						: level() == 3 ? category.getParent().getParent().getName() : "";
	}

	public String getSecondCategory() {
		return level() == 1 ? ""
				: level() == 2 ? category.getName() : level() == 3 ? category.getParent().getName() : "";
	}

	public String getThirdCategory() {
		return level() == 1 ? "" : level() == 2 ? "" : level() == 3 ? category.getName() : "";
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Map<String, String> getNames() {
		return names;
	}

	public void setNames(Map<String, String> names) {
		this.names = names;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<String> getImageList() {
		return new ArrayList<>(image);
	}

	public Set<String> getImage() {
		return image;
	}

	public void setImage(Set<String> image) {
		this.image = image;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Set<Country> getCountry() {
		return country;
	}

	public void setCountry(Set<Country> country) {
		this.country = country;
	}

	public Set<State> getState() {
		return state;
	}

	public void setState(Set<State> state) {
		this.state = state;
	}

	public Map<String, String> getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(Map<String, String> descriptions) {
		this.descriptions = descriptions;
	}

	public Member getOwner() {
		return owner;
	}

	public void setOwner(Member owner) {
		this.owner = owner;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public Set<Price> getPrices() {
		return prices;
	}

	public void setPrices(Set<Price> prices) {
		this.prices = prices;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(double commissionRate) {
		this.commissionRate = commissionRate;
	}

	public String getCoverImage() {
		return coverImage;
	}

	public void setCoverImage(String coverImage) {
		this.coverImage = coverImage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((color == null) ? 0 : color.hashCode());
		long temp;
		temp = Double.doubleToLongBits(commissionRate);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((descriptions == null) ? 0 : descriptions.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((image == null) ? 0 : image.hashCode());
		result = prime * result + ((itemState == null) ? 0 : itemState.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((owner == null) ? 0 : owner.hashCode());
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((prices == null) ? 0 : prices.hashCode());
		result = prime * result + ((security == null) ? 0 : security.hashCode());
		result = prime * result + ((size == null) ? 0 : size.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (color == null) {
			if (other.color != null)
				return false;
		} else if (!color.equals(other.color))
			return false;
		if (Double.doubleToLongBits(commissionRate) != Double.doubleToLongBits(other.commissionRate))
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (descriptions == null) {
			if (other.descriptions != null)
				return false;
		} else if (!descriptions.equals(other.descriptions))
			return false;
		if (id != other.id)
			return false;
		if (image == null) {
			if (other.image != null)
				return false;
		} else if (!image.equals(other.image))
			return false;
		if (itemState == null) {
			if (other.itemState != null)
				return false;
		} else if (!itemState.equals(other.itemState))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (owner == null) {
			if (other.owner != null)
				return false;
		} else if (!owner.equals(other.owner))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (prices == null) {
			if (other.prices != null)
				return false;
		} else if (!prices.equals(other.prices))
			return false;
		if (security == null) {
			if (other.security != null)
				return false;
		} else if (!security.equals(other.security))
			return false;
		if (size == null) {
			if (other.size != null)
				return false;
		} else if (!size.equals(other.size))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		if (status != other.status)
			return false;
		return true;
	}
}