package com.opm.hms.producer;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.faces.context.FacesContext;
import javax.inject.Named;

@ApplicationScoped
public class ListCountProducer {

	@Named
	@Produces
	private int limit;
	
	@PostConstruct
	private void init() {
		String str = FacesContext.getCurrentInstance().getExternalContext().getInitParameter("page.limit");
		limit = Integer.parseInt(str);
	}
}
