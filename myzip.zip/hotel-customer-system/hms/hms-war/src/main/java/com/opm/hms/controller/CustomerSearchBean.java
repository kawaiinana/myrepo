package com.opm.hms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.enterprise.context.Dependent;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Customer;
import com.opm.hms.service.CustomerService;
import com.opm.hms.service.search.Impl.CustomerSearch;
import com.opm.hms.service.vo.CustomerListVO;

@SuppressWarnings("serial")
@Named
@Dependent
public class CustomerSearchBean implements Serializable {

	@Inject
	private CustomerSearch search;

	private List<CustomerListVO> list;

	@Inject
	private CustomerService service;
	
	@PostConstruct
	private void postConstruct() {
		list = new ArrayList<>();
	}
	
	public void search() {
		list = service.search(search);
	}

	public CustomerSearch getSearch() {
		return search;
	}

	public void setSearch(CustomerSearch search) {
		this.search = search;
	}

	public List<CustomerListVO> getList() {
		return list;
	}

	public void setList(List<CustomerListVO> list) {
		this.list = list;
	}
	
	public List<Customer> getSelectedCustomers() {
		return list.stream().filter(a -> a.isSelect())
				.map(a -> a.getCustomer()).collect(Collectors.toList());
	}

	public void clearSearch() {
		search.clear();
		list = new ArrayList<>();
	}

}
