package com.opm.hms.controller;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Named;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class ReservationReportBean implements Serializable {

	public ReservationReportBean() {
	}

	public void init() {
		// TODO implement here
	}

	public void search() {
		// TODO implement here
	}

}