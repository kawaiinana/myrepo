package com.opm.hms.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Rate;
import com.opm.hms.entity.User;
import com.opm.hms.service.RateService;
import com.opm.hms.utils.producer.RateProducer;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class RateBean implements Serializable {

	private Rate data;

	private String title;

	private List<Rate> list;

	@Inject
	private Event<Rate> event;

	@Inject
	private RateService service;

	@Inject
	private RateProducer producer;

	@Inject
	@Named
	private User loginUser;

	private boolean showPopup;


	@PostConstruct
	public void init() {
		list = service.search();
	}

	public void addNew() {
		title = "Add New Rate";
		this.data = new Rate();
		this.data.getSecurity().setCreateUser(loginUser.getLogin());
		showPopup = true;
	}

	public void edit(Rate rate) {
		title = "Edit Rate";
		this.data = rate;
		showPopup = true;
	}

	public String save() {
		this.data.getSecurity().setModUser(loginUser.getLogin());
		service.save(data);
		event.fire(data);
		return "/admin/rates?faces-redirect=true";
	}

	public Rate getData() {
		return data;
	}

	public void setData(Rate data) {
		this.data = data;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<Rate> getList() {
		return list;
	}

	public void setList(List<Rate> list) {
		this.list = list;
	}

	public RateProducer getProducer() {
		return producer;
	}

	public void setProducer(RateProducer producer) {
		this.producer = producer;
	}

	public boolean isShowPopup() {
		return showPopup;
	}

	public void setShowPopup(boolean showPopup) {
		this.showPopup = showPopup;
	}

}