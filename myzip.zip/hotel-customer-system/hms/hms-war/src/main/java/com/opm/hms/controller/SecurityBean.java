package com.opm.hms.controller;

import javax.enterprise.event.Event;
import javax.enterprise.inject.Model;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

@Model
public class SecurityBean {

	private String login;

	private String pass;

	@Inject
	private Event<String> loginEvent;

	public String login() {
		try {

			ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
			HttpServletRequest req = (HttpServletRequest) ctx.getRequest();

			req.login(login, pass);

			loginEvent.fire(login);

			if (req.isUserInRole("Manager")) {
				return "/admin/home?faces-redirect=true";
			}

			if (req.isUserInRole("Front")) {
				return "/front/reservation-list?faces-redirect=true";
			}

			return "";
			
		} catch (Exception e) {
			FacesMessage message = new FacesMessage("Login Error", "Please check your Login ID and Password.");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String logout() {
		ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
		ctx.invalidateSession();
		return "/login?faces-redirect=true";
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public Event<String> getLoginEvent() {
		return loginEvent;
	}

	public void setLoginEvent(Event<String> loginEvent) {
		this.loginEvent = loginEvent;
	}

}