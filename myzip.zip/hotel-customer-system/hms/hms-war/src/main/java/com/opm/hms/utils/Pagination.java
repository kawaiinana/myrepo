package com.opm.hms.utils;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

@Pager
@SuppressWarnings("serial")
public class Pagination implements Serializable {

	@Inject
	@Named
	private int limit;

	private List<Page> pages;
	private long total;

	public List<Page> getPages() {
		return pages;
	}

	public void setPages(List<Page> pages) {
		this.pages = pages;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}

	public int getStart(int page) {
		setPage(page);
		return ((page - 1) * limit);
	}

	public int getLimit() {
		return limit;
	}

	private void setPage(int page) {
		
		// current
		class PageHelper {
			
			int remain = 0;
			int pages = 0;
			int pageSize = 0;
			int first = 0;
			int last = 0;
			
			public PageHelper() {
				
				pages = ((int) total) / limit;
				remain = ((int) total) % limit;
				
				pageSize = remain == 0 ? pages : pages + 1;
				
				if(pageSize > 5) {
					first = (page < 3) ? 1 : page -2;
					last = (page < pageSize - 2) ? pageSize : page + 2;
				} else {
					first = 1;
					last = pageSize;
				}
			}
			
			List<Integer> getPageNumbers() {
				List<Integer> list = new ArrayList<>();
				for(int i = first; i <= last; i++) {
					list.add(i);
				}
				return list;
			}
		}
		
		PageHelper helper = new PageHelper();
		
		// create page list
		pages.clear();
		
		List<Integer> pageNumbers = helper.getPageNumbers();
		
		for(Integer i : pageNumbers) {
			pages.add(new Page(i, String.valueOf(i), i == page));
		}

		// less than or equal to 5
		if(helper.pageSize > 5) {
			
			// first
			if(page > 1) {
				pages.add(0, new Page(1, " << ", 1 == page));
			}
			
			// last
			if(page < helper.pageSize) {
				pages.add(new Page(helper.pageSize, " >> ", helper.pageSize == page));
			}
		}
	}


	@PostConstruct
	private void init() {
		pages = new ArrayList<>();
	}
}
