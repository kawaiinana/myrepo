package com.opm.hms.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.RoomType;
import com.opm.hms.service.RoomTypeService;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class RoomTypeBean implements Serializable {

	private RoomType data;

	private String title;

	private List<RoomType> list;

	@Inject
	private Event<RoomType> event;

	@Inject
	private RoomTypeService service;

	private boolean showPopup;

	@PostConstruct
	public void init() {
		list = service.getAll();
	}

	public void addNew() {
		title = "Add New Room Type";
		this.data = new RoomType();
		showPopup = true;
	}

	public void edit(RoomType type) {
		title = "Edit Room Type";
		this.data = type;
		showPopup = true;
	}

	public String save() {
		service.save(data);
		event.fire(data);
		return "/admin/roomTypes?faces-redirect=true";
	}

	public RoomType getData() {
		return data;
	}

	public void setData(RoomType data) {
		this.data = data;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<RoomType> getList() {
		return list;
	}

	public void setList(List<RoomType> list) {
		this.list = list;
	}

	public boolean isShowPopup() {
		return showPopup;
	}

	public void setShowPopup(boolean showPopup) {
		this.showPopup = showPopup;
	}

}
