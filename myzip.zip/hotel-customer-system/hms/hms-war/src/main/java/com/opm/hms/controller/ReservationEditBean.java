package com.opm.hms.controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Customer;
import com.opm.hms.entity.CustomerPoint;
import com.opm.hms.entity.CustomerReservation;
import com.opm.hms.entity.MasterData;
import com.opm.hms.entity.Reservation;
import com.opm.hms.entity.Room;
import com.opm.hms.entity.RoomReservation;
import com.opm.hms.service.ReservationService;
import com.opm.hms.service.RoomService;
import com.opm.hms.service.vo.RoomStateVO;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class ReservationEditBean implements Serializable {

	private Reservation reservation;

	private Map<Room, List<RoomStateVO>> rooms;

	private List<Room> keys;

	private List<LocalDate> dates;

	private boolean onlyFree;

	private LocalDate totalStayDate;
	
	@Inject
	private ReservationService service;

	@Inject
	private RoomService roomService;

	@Inject
	@Named
	private List<MasterData> reservationStatuses;

	@Inject
	private CustomerSearchBean oldCustomerSearch;

	private Customer customer;

	private boolean showPopup;

	@PostConstruct
	public void init() {
		onlyFree = true;
		customer = new Customer();
		reservation = new Reservation();

		reservation.setReserveDate(LocalDate.now());

		if (reservationStatuses.size() > 0) {
			reservation.setStatus(reservationStatuses.get(0).getValue());
		}

		rooms = new LinkedHashMap<>();

	}

	public void searchOldCustomer() {
		oldCustomerSearch.clearSearch();
		showPopup = true;
	}

	public void selectCustomer() {
		oldCustomerSearch.getSelectedCustomers().forEach(a -> {
			CustomerReservation cr = new CustomerReservation();
			cr.setCustomer(a);

			if (reservation.getCustomers().size() == 0) {
				cr.setReservedCustomer(true);
			}

			reservation.addCustomer(cr);
		});

		showPopup = false;
	}

	public String save() {

		reservation.getRooms().clear();

		keys.stream().filter(a -> a.isSelect()).forEach(r -> {
			LocalDate refDate = reservation.getCheckInDate();

			while (refDate.compareTo(reservation.getCheckOutDate()) < 0) {
				RoomReservation rr = new RoomReservation();
				rr.setStayDate(refDate);
				rr.setRoom(r);
				reservation.addRoom(rr);

				refDate = refDate.plusDays(1);
			}
		});

		reservation.calculate();
		service.save(reservation);
		
		for(CustomerPoint p : reservation.getCustomer().getPoints()) {
			if(p.getReservation() == null 
					|| p.getReservation().getId() == reservation.getId()
					|| p.getReservation().getId() == 0 ) {
				p.setReservation(reservation);
				service.save(p);
			}
		}
		
		return "/front/reservation-details?faces-redirect=true&id=" + reservation.getId();

	}

	public void addCustomer() {
		CustomerReservation cr = new CustomerReservation();
		cr.setCustomer(customer);

		if (reservation.getCustomers().isEmpty()) {
			cr.setReservedCustomer(true);
		}

		reservation.addCustomer(cr);
		customer = new Customer();
	}

	public void searchRoom() {
		
		if(null == reservation.getCheckInDate()) {
			FacesMessage message = new FacesMessage(null, "Please enter Check In Date.");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return;
		}
		
		if(null == reservation.getCheckOutDate()) {
			FacesMessage message = new FacesMessage(null, "Please enter Check Out Date.");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return;
		}
		
		if(reservation.getCheckInDate().compareTo(reservation.getCheckOutDate()) >= 0) {
			FacesMessage message = new FacesMessage(null, "Check Out date must be greater than Check In Date.");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return;
		}
		
		rooms = roomService.findAvialableRoom(reservation.getCheckInDate(), reservation.getCheckOutDate(), onlyFree);
		keys = new ArrayList<>(rooms.keySet());
		dates = new ArrayList<>();
		LocalDate refDate = reservation.getCheckInDate().minusDays(2);

		while (refDate.compareTo(reservation.getCheckOutDate().plusDays(2)) <= 0) {
			dates.add(refDate);

			refDate = refDate.plusDays(1);
		}
	}

	public void removeCustomer(CustomerReservation cust) {
		this.reservation.getCustomers().remove(cust);
	}

	public Reservation getReservation() {
		return reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

	public Map<Room, List<RoomStateVO>> getRooms() {
		return rooms;
	}

	public List<RoomStateVO> getRoomState(Room r) {
		return rooms.get(r);
	}

	public void setRooms(Map<Room, List<RoomStateVO>> rooms) {
		this.rooms = rooms;
	}

	public List<Room> getKeys() {
		return keys;
	}

	public void setKeys(List<Room> keys) {
		this.keys = keys;
	}

	public List<LocalDate> getDates() {
		return dates;
	}

	public void setDates(List<LocalDate> dates) {
		this.dates = dates;
	}

	public boolean isOnlyFree() {
		return onlyFree;
	}

	public void setOnlyFree(boolean onlyFree) {
		this.onlyFree = onlyFree;
	}

	public LocalDate getTotalStayDate() {
		return totalStayDate;
	}

	public void setTotalStayDate(LocalDate totalStayDate) {
		this.totalStayDate = totalStayDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public CustomerSearchBean getOldCustomerSearch() {
		return oldCustomerSearch;
	}

	public void setOldCustomerSearch(CustomerSearchBean oldCustomerSearch) {
		this.oldCustomerSearch = oldCustomerSearch;
	}

	public boolean isShowPopup() {
		return showPopup;
	}

	public void setShowPopup(boolean showPopup) {
		this.showPopup = showPopup;
	}


}
