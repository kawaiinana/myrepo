package com.opm.hms.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Room;
import com.opm.hms.entity.User;
import com.opm.hms.service.RoomService;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class RoomBean implements Serializable {
	
	private String title;

	private Room data;

	private List<Room> list;

	@Inject
	private Event<Room> event;

	@Inject
	private RoomService service;
	
	@Inject
	@Named
	private User loginUser;
	
	private boolean showPopup;
	

	@PostConstruct
	public void init() {
		list = service.search();
	}
	
	public void addNew() {
		title = "Add New Room";
		this.data = new Room();
		this.data.getSecurity().setCreateUser(loginUser.getLogin());
		this.data.getSecurity().setModUser(loginUser.getLogin());
		showPopup = true;
	}
	
	public void edit(Room room) {
		title = "Edit Room";
		this.data = room;
		this.data.getSecurity().setModUser(loginUser.getLogin());
		showPopup = true;
	}
	
	public String save() {
		service.save(data);
		event.fire(data);
		return "/admin/rooms?faces-redirect=true";
	}

	public Room getData() {
		return data;
	}

	public void setData(Room data) {
		this.data = data;
	}

	public List<Room> getList() {
		return list;
	}

	public void setList(List<Room> list) {
		this.list = list;
	}

	public Event<Room> getEvent() {
		return event;
	}

	public void setEvent(Event<Room> event) {
		this.event = event;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public boolean isShowPopup() {
		return showPopup;
	}

	public void setShowPopup(boolean showPopup) {
		this.showPopup = showPopup;
	}

	
}