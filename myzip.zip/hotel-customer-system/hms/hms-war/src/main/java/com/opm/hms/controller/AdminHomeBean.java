package com.opm.hms.controller;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Room;
import com.opm.hms.service.RoomService;
import com.opm.hms.service.vo.RoomStateVO;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class AdminHomeBean implements Serializable {

	private LocalDate dateFrom;
	private LocalDate dateTo;

	private Map<Room, List<RoomStateVO>> result;

	private List<Room> rooms;
	private List<LocalDate> dates;
	private List<Double> dateSummary;

	@Inject
	private RoomService service;

	public AdminHomeBean() {
	}

	@PostConstruct
	public void init() {
		dateFrom = LocalDate.now().withDayOfMonth(1);
		dateTo = LocalDate.now();
		dates = new ArrayList<>();
		dateSummary = new ArrayList<>();
		
		searchRoom();
	}
	
	public List<RoomStateVO> getRoomStates(Room room) {
		return result.get(room);
	}
	
	public double getRoomTotal(Room room) {
		return getRoomStates(room).stream().mapToDouble(a -> a.getTotalAmount()).sum();
	}

	public void searchRoom() {

		// Find Room Condition
		result = service.findRoomData(dateFrom, dateTo);
		rooms = new ArrayList<>(result.keySet());

		LocalDate refDate = dateFrom == null ? LocalDate.now().withDayOfMonth(1) : dateFrom;
		LocalDate endDate = dateTo == null ? LocalDate.now() : dateTo;

		// Date List
		dates.clear();
		while (refDate.compareTo(endDate) <= 0) {
			dates.add(refDate);
			refDate = refDate.plusDays(1);
		}

		// Date Summary
		dateSummary.clear();
		for (int i = 0; i < dates.size(); i++) {
			double d = 0;
			for (List<RoomStateVO> list : result.values()) {
				RoomStateVO vo = list.get(i);
				if (null != vo) {
					d += vo.getTotalAmount();
				}
			}

			dateSummary.add(d);
		}

	}

	public LocalDate getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(LocalDate dateFrom) {
		this.dateFrom = dateFrom;
	}

	public LocalDate getDateTo() {
		return dateTo;
	}

	public void setDateTo(LocalDate dateTo) {
		this.dateTo = dateTo;
	}

	public Map<Room, List<RoomStateVO>> getResult() {
		return result;
	}

	public void setResult(Map<Room, List<RoomStateVO>> result) {
		this.result = result;
	}

	public List<Room> getRooms() {
		return rooms;
	}

	public void setRooms(List<Room> rooms) {
		this.rooms = rooms;
	}

	public List<LocalDate> getDates() {
		return dates;
	}

	public void setDates(List<LocalDate> dates) {
		this.dates = dates;
	}

	public List<Double> getDateSummary() {
		return dateSummary;
	}

	public void setDateSummary(List<Double> dateSummary) {
		this.dateSummary = dateSummary;
	}

}