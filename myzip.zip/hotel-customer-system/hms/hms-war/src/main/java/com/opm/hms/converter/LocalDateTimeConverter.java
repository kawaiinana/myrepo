package com.opm.hms.converter;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

import javax.enterprise.inject.Model;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

@Model
public class LocalDateTimeConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		try {
			if (null != value && !value.isEmpty()) {
				return LocalTime.parse(value.contains(":") ? value : value.concat(":00"),
						DateTimeFormatter.ofPattern("H:mm"));
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (value != null) {
			return DateTimeFormatter.ofPattern("HH:mm").format((LocalTime) value);
		}
		return null;
	}

}
