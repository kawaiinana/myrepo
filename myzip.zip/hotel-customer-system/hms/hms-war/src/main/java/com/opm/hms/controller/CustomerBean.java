package com.opm.hms.controller;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import com.opm.hms.service.CustomerService;
import com.opm.hms.service.vo.CustomerVO;

@Model
public class CustomerBean {

	@Inject
	private CustomerService service;

	private CustomerVO data;
	
	private long id;
	
	@PostConstruct
	public void init() {
		
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		
		if(null != str && !str.isEmpty()) {
			id = Long.parseLong(str);
			data = service.search(id);
		} else {
			data = new CustomerVO();
		}
	}

	public String save() {
		service.save(data);
		return "/front/customer-list";
	}

	public CustomerVO getData() {
		return data;
	}

	public void setData(CustomerVO data) {
		this.data = data;
	}

}