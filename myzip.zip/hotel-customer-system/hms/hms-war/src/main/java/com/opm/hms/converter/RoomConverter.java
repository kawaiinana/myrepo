package com.opm.hms.converter;

import java.util.List;

import javax.enterprise.inject.Model;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Room;

@Model
public class RoomConverter implements Converter {

	@Named
	@Inject
	private List<Room> rooms;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		
		for (Room room : rooms) {
			if(room.getRoomNumber().equals(value)) {
				return room;
			}
		}
		
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if (null != value && !value.equals("")) {
			Room r = (Room) value;
			return r.getRoomNumber();
		}
		return null;
	}

}
