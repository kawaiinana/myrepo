package com.opm.hms.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Site;
import com.opm.hms.entity.User;
import com.opm.hms.service.SiteService;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class SiteBean implements Serializable {

	private Site data;

	private String title;
	
	private List<Site> list;

	@Inject
	private Event<Site> event;

	@Inject
	private SiteService service;
	
	@Inject
	@Named
	private User loginUser;
	
	private boolean showPopup;

	@PostConstruct
	public void init() {
		list = service.search();
	}
	
	public void addNew() {
		title = "Add New Site";
		this.data = new Site();
		this.data.getSecurity().setCreateUser(loginUser.getLogin());
		showPopup = true;
	}

	public void edit(Site site) {
		title = "Edit Site";
		this.data = site;
		showPopup = true;
	}

	public String save() {
		this.data.getSecurity().setModUser(loginUser.getLogin());
		service.save(data);
		event.fire(data);
		return "/admin/sites?faces-redirect=true";
	}

	public Site getData() {
		return data;
	}

	public void setData(Site data) {
		this.data = data;
	}

	public List<Site> getList() {
		return list;
	}

	public void setList(List<Site> list) {
		this.list = list;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public boolean isShowPopup() {
		return showPopup;
	}

	public void setShowPopup(boolean showPopup) {
		this.showPopup = showPopup;
	}

}