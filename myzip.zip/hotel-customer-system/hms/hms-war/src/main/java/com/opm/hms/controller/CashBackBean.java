package com.opm.hms.controller;

import java.io.Serializable;

import javax.enterprise.event.Event;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.PointCalculation;
import com.opm.hms.entity.User;
import com.opm.hms.service.PointCalculationService;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CashBackBean implements Serializable {

	private PointCalculation data;

	private String title;
	
	@Inject
	private Event<PointCalculation> event;

	@Inject
	private PointCalculationService service;
	
	@Inject
	@Named
	private User loginUser;
	
	private boolean showPopup;

	public void addNew() {
		title = "Add New Calculation";
		this.data = new PointCalculation();
		this.data.getSecurity().setCreateUser(loginUser.getLogin());
		showPopup = true;
	}

	public void edit(PointCalculation data) {
		title = "Edit Calculation";
		this.data = data;
		showPopup = true;
	}

	public String save() {
		this.data.getSecurity().setModUser(loginUser.getLogin());
		service.save(data);
		event.fire(data);
		return "/admin/cashback?faces-redirect=true";
	}

	public PointCalculation getData() {
		return data;
	}

	public void setData(PointCalculation data) {
		this.data = data;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Event<PointCalculation> getEvent() {
		return event;
	}

	public void setEvent(Event<PointCalculation> event) {
		this.event = event;
	}

	public boolean isShowPopup() {
		return showPopup;
	}

	public void setShowPopup(boolean showPopup) {
		this.showPopup = showPopup;
	}

}