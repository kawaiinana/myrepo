package com.opm.hms.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Reservation;
import com.opm.hms.service.ReservationService;
import com.opm.hms.service.search.Impl.ReservationSearch;
import com.opm.hms.utils.Pager;
import com.opm.hms.utils.Pagination;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class ReservationListBean implements Serializable {

	@Inject
	private ReservationService service;

	private List<Reservation> list;

	@Inject
	private ReservationSearch search;
	
	@Pager
	@Inject
	private Pagination pagination;
	
	@PostConstruct
	public void init() {
		search();
	}

	public void search() {
		pageSearch(1);
	}
	
	public void pageSearch(int page) {
		
		long total = service.searchCount(search);
		pagination.setTotal(total);
		
		search.setLimit(pagination.getLimit());
		search.setStart(pagination.getStart(page));
		
		list = service.search(search);
		System.out.println(list.size() + " list bean ");
	}

	public List<Reservation> getList() {
		return list;
	}

	public void setList(List<Reservation> list) {
		this.list = list;
	}

	public ReservationSearch getSearch() {
		return search;
	}

	public void setSearch(ReservationSearch search) {
		this.search = search;
	}

	public Pagination getPagination() {
		return pagination;
	}

	public void setPagination(Pagination pagination) {
		this.pagination = pagination;
	}

}