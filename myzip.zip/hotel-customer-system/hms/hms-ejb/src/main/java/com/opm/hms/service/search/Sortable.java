package com.opm.hms.service.search;

public interface Sortable {

    public String orderBy();

}