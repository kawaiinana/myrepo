package com.opm.hms.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.Site;
import com.opm.hms.repo.SiteRepo;
import com.opm.hms.service.search.Searchable;

@LocalBean
@Stateless
public class SiteService {

	@Inject
	private SiteRepo repo;

	public void save(Site data) {
		repo.save(data);
	}

	public List<Site> search() {
		return repo.find(null);
	}

	public Site findByName(String name) {
		
		@SuppressWarnings("serial")
		List<Site> site = repo.find(new Searchable() {

			@Override
			public String where() {
				return "and upper(t.name) = upper(:name) ";
			}

			@Override
			public Map<String, Object> params() {
				Map<String, Object> params = new HashMap<>();
				params.put("name", name);
				return params;
			}
		});

		if (site.size() > 0)
			return site.get(0);

		return null;
	}

}