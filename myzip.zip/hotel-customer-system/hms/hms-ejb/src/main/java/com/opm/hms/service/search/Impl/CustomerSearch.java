package com.opm.hms.service.search.Impl;

import java.util.HashMap;
import java.util.Map;

import com.opm.hms.service.search.PageEnable;
import com.opm.hms.service.search.Searchable;
import com.opm.hms.service.search.Sortable;

@SuppressWarnings("serial")
public class CustomerSearch implements Searchable, PageEnable, Sortable {

	private String firstName;

	private String lastName;

	private String email;

	private String phone;

	private String passport;

	private String nationality;

	private int start;
	private int limit;

	public void setStart(int start) {
		this.start = start;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	@Override
	public String where() {

		StringBuffer sb = new StringBuffer();

		// firstName
		if (null != firstName) {
			sb.append("and upper(t.firstName) like upper(:firstName) ");
		}

		// lastName
		if (null != lastName) {
			sb.append("and upper(t.lastName) like upper(:lastName) ");
		}

		// email
		if (null != email) {
			sb.append("and upper(t.email) like upper(:email) ");
		}

		// phone
		if (null != phone) {
			sb.append("and upper(t.phone) like upper(:phone) ");
		}

		// passport
		if (null != passport) {
			sb.append("and upper(t.passport) like upper(:passport) ");
		}

		// nationality
		if (null != nationality) {
			sb.append("and upper(t.nationality) like upper(:nationality) ");
		}

		return sb.toString();
	}

	@Override
	public Map<String, Object> params() {

		Map<String, Object> params = new HashMap<>();

		// firstName
		if (null != firstName) {
			params.put("firstName", "%".concat(firstName).concat("%"));
		}

		// lastName
		if (null != lastName) {
			params.put("lastName", "%".concat(lastName).concat("%"));
		}

		// email
		if (null != email) {
			params.put("email", "%".concat(email).concat("%"));
		}

		// phone
		if (null != phone) {
			params.put("phone", "%".concat(phone).concat("%"));
		}

		// passport
		if (null != passport) {
			params.put("passport", "%".concat(passport).concat("%"));
		}

		// nationality
		if (null != nationality) {
			params.put("nationality", "%".concat(nationality).concat("%"));
		}

		return params;
	}

	@Override
	public int start() {
		return start;
	}

	@Override
	public int limit() {
		return limit;
	}

	@Override
	public String orderBy() {
		return "t.firstName, t.lastName";
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getPassport() {
		return passport;
	}

	public void setPassport(String passport) {
		this.passport = passport;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public void clear() {
		firstName = "";
		lastName = "";
		email = "";
		phone = "";
		passport = "";
		nationality = "";
	}

}