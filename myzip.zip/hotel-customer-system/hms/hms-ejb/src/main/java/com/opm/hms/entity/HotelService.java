package com.opm.hms.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.opm.hms.repo.LongIdEntity;

@Entity
public abstract class HotelService implements LongIdEntity {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	private LocalDateTime serviceTime;

	private double total;

	@ManyToOne
	private RoomReservation reservation;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDateTime getServiceTime() {
		return serviceTime;
	}

	public void setServiceTime(LocalDateTime serviceTime) {
		this.serviceTime = serviceTime;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public RoomReservation getReservation() {
		return reservation;
	}

	public void setReservation(RoomReservation reservation) {
		this.reservation = reservation;
	}

}