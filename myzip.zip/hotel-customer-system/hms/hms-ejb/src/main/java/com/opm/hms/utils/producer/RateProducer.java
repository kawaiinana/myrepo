package com.opm.hms.utils.producer;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Rate;
import com.opm.hms.service.RateService;

@ApplicationScoped
public class RateProducer {

	@Named
	@Produces
	private List<Rate> rates;

	@Inject
	private RateService service;
	
	@PostConstruct
	public void init() {
		load(null);
	}

	public void load(@Observes Rate data) {
		rates = service.search();
	}

	public Rate get(LocalDate date) {
		return rates.stream()
				.filter(a -> a.getRefDate().compareTo(date) <= 0)
				.sorted((a,b) -> b.getRefDate().compareTo(a.getRefDate()))
				.findFirst().orElse(null);
	}

	public List<Rate> search(LocalDate date) {
		return rates.stream()
				.filter(a -> a.getRefDate().compareTo(date) <= 0)
				.sorted((a,b) -> b.getRefDate().compareTo(a.getRefDate()))
				.collect(Collectors.toList());
	}

}