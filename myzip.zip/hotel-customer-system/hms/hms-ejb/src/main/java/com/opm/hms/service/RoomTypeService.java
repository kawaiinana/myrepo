package com.opm.hms.service;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.RoomType;
import com.opm.hms.repo.RoomTypeRepo;

@LocalBean
@Stateless
public class RoomTypeService {

	@Inject
	private RoomTypeRepo repo;
	
	public void save(RoomType type) {
		repo.save(type);
	}
	
	public List<RoomType> getAll() {
		return repo.find(null);
	}
}
