package com.opm.hms.repo;

import java.io.Serializable;

public interface LongIdEntity extends Serializable{

    public long getId();

}