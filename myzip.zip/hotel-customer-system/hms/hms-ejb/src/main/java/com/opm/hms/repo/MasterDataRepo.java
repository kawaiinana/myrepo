package com.opm.hms.repo;

import com.opm.hms.entity.MasterData;

public class MasterDataRepo extends AbstractRepository<MasterData> {

    public MasterDataRepo() {
    	super(MasterData.class);
    }

}