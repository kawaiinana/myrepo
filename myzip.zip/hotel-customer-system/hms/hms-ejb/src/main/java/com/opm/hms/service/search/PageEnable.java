package com.opm.hms.service.search;

/**
 * 
 */
public interface PageEnable {

    public int start();

    public int limit();

}