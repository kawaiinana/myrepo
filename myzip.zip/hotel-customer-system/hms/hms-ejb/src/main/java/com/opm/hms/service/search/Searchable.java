package com.opm.hms.service.search;

import java.io.Serializable;
import java.util.Map;

public interface Searchable extends Serializable {

    public String where();

    public Map<String, Object> params();

}