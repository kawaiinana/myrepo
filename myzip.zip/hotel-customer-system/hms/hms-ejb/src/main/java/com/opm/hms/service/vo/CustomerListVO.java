package com.opm.hms.service.vo;

import java.time.LocalDate;

import com.opm.hms.entity.Customer;

public class CustomerListVO {

	private boolean select;
	
	private int point;

	private LocalDate lastStayDate;

	private Customer customer;

	public CustomerListVO() {
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public LocalDate getLastStayDate() {
		return lastStayDate;
	}

	public void setLastStayDate(LocalDate lastStayDate) {
		this.lastStayDate = lastStayDate;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public boolean isSelect() {
		return select;
	}

	public void setSelect(boolean select) {
		this.select = select;
	}

}