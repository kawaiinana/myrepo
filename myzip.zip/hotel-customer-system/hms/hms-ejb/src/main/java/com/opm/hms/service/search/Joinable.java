package com.opm.hms.service.search;

public interface Joinable {

    public String join();

}