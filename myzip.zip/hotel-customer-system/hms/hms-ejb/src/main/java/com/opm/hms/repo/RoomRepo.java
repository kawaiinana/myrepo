package com.opm.hms.repo;

import com.opm.hms.entity.Room;

public class RoomRepo extends AbstractRepository<Room> {

    public RoomRepo() {
    	super(Room.class);
    }

}