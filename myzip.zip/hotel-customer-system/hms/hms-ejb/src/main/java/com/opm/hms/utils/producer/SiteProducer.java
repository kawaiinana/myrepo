package com.opm.hms.utils.producer;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Site;
import com.opm.hms.service.SiteService;

@ApplicationScoped
public class SiteProducer {

	@Named
	@Produces
	private List<Site> sites;

	@Inject
	private SiteService service;

	@PostConstruct
	public void init() {
		load(null);
	}

	public void load(@Observes Site data) {
		sites = service.search();
	}

}