package com.opm.hms.utils.producer;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.PointCalculation;
import com.opm.hms.service.PointCalculationService;

@ApplicationScoped
public class PointCalculationProducer {

	@Named
	@Produces
	private List<PointCalculation> calculations;
	
	@Inject
	private PointCalculationService service;
	
	@PostConstruct
	private void init() {
		load(null);
	}
	
	private void load(@Observes PointCalculation c) {
		calculations = service.getAll();
	}
}
