package com.opm.hms.utils.producer;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.RoomType;
import com.opm.hms.service.RoomTypeService;

@ApplicationScoped
public class RoomTypeProducer {

	@Produces
	@Named
	private List<RoomType> roomTypes;
	
	@Inject
	private RoomTypeService service;
	
	@PostConstruct
	private void init() {
		load(null);
	}
	
	public void load(@Observes RoomType type) {
		roomTypes = service.getAll();
	}
}
