package com.opm.hms.repo;

import com.opm.hms.entity.RoomType;

public class RoomTypeRepo extends AbstractRepository<RoomType>{
	
	public RoomTypeRepo() {
		super(RoomType.class);
	}

}
