package com.opm.hms.repo;

import java.io.Serializable;

public interface StringIdEntity extends Serializable {

    public String getId();

}