package com.opm.hms.repo;

import com.opm.hms.entity.CustomerPoint;

public class CustomerPointRepo extends AbstractRepository<CustomerPoint> {

    public CustomerPointRepo() {
    	super(CustomerPoint.class);
    }

}