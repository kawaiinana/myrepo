package com.opm.hms.repo;

import com.opm.hms.entity.PointCalculation;

public class PointCalculationRepo extends AbstractRepository<PointCalculation>{

	public PointCalculationRepo() {
		super(PointCalculation.class);
	}

}
