package com.opm.hms.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.time.LocalDateTime;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import org.hibernate.validator.constraints.NotEmpty;

import com.opm.hms.repo.LongIdEntity;

@Entity
@Cacheable
public class Site implements LongIdEntity {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	@NotEmpty(message = "Site Name must not be empty!")
	private String name;

	private String url;

	private String description;

	private boolean cashBack;

	private Security security;

	public Site() {
		security = new Security();
	}

	@PrePersist
	public void prePersist() {
		security.setCreation(LocalDateTime.now());
		security.setModification(LocalDateTime.now());
	}

	@PreUpdate
	private void preUpdate() {
		security.setModification(LocalDateTime.now());
	}

	public long getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Security getSecurity() {
		return security;
	}

	public void setSecurity(Security security) {
		this.security = security;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isCashBack() {
		return cashBack;
	}

	public void setCashBack(boolean cashBack) {
		this.cashBack = cashBack;
	}

}