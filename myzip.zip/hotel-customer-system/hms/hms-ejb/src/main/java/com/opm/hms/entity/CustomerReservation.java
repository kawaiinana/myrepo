package com.opm.hms.entity;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.CascadeType.PERSIST;
import static javax.persistence.GenerationType.IDENTITY;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;

import com.opm.hms.repo.LongIdEntity;

@Entity
public class CustomerReservation implements LongIdEntity {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	private boolean reservedCustomer;

	@ManyToOne(cascade = { PERSIST, MERGE })
	private Customer customer;

	@ManyToOne
	private Reservation reservation;

	private Security security;
	
	public CustomerReservation() {
		security = new Security();
	}

	@PrePersist
	public void prePersist() {
		security.setCreation(LocalDateTime.now());
		security.setModification(LocalDateTime.now());
	}
	
	public long getId() {
		return id;
	}

	public boolean isReservedCustomer() {
		return reservedCustomer;
	}

	public void setReservedCustomer(boolean reservedCustomer) {
		this.reservedCustomer = reservedCustomer;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Reservation getReservation() {
		return reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Security getSecurity() {
		return security;
	}

	public void setSecurity(Security security) {
		this.security = security;
	}

}