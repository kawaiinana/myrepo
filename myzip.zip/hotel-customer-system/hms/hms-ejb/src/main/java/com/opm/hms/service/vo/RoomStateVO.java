package com.opm.hms.service.vo;

import java.io.Serializable;

import com.opm.hms.entity.Room;

@SuppressWarnings("serial")
public class RoomStateVO implements Serializable {

	private String status;
	private String contact;
	private Room room;
	private double totalAmount;
	private String currency;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

}
