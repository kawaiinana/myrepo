package com.opm.hms.service;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.PointCalculation;
import com.opm.hms.repo.PointCalculationRepo;

@LocalBean
@Stateless
public class PointCalculationService {

	@Inject
	private PointCalculationRepo repo;
	
	public void save(PointCalculation point) {
		repo.save(point);
	}
	
	public List<PointCalculation> getAll() {
		return repo.find(null);
	}
}
