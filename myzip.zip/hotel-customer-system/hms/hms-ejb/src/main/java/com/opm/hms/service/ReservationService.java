package com.opm.hms.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.Customer;
import com.opm.hms.entity.CustomerPoint;
import com.opm.hms.entity.CustomerReservation;
import com.opm.hms.entity.LaundryService;
import com.opm.hms.entity.Reservation;
import com.opm.hms.entity.Reservation.CashBackStatus;
import com.opm.hms.entity.RestaurantService;
import com.opm.hms.repo.CustomerPointRepo;
import com.opm.hms.repo.CustomerRepo;
import com.opm.hms.repo.CustomerReservationRepo;
import com.opm.hms.repo.LaundryServiceRepo;
import com.opm.hms.repo.ReservationRepo;
import com.opm.hms.repo.RestaurantServiceRepo;
import com.opm.hms.service.search.Searchable;
import com.opm.hms.service.search.Impl.CustomerLaundrySearch;
import com.opm.hms.service.search.Impl.CustomerReservationSearch;
import com.opm.hms.service.search.Impl.CustomerRestaurantSearch;

@LocalBean
@Stateless
public class ReservationService {

	@Inject
	private ReservationRepo reservRepo;

	@Inject
	private RestaurantServiceRepo restRepo;

	@Inject
	private LaundryServiceRepo laundRepo;

	@Inject
	private CustomerReservationRepo custReservRepo;
	
	@Inject
	private CustomerRepo custRepo;
	
	@Inject
	private CustomerPointRepo pointRepo;
	
	@Resource
	private SessionContext ctx;

	public void save(Reservation data) {
		// old customer
		data.getCustomers().forEach(a -> {
			if(a.getCustomer().getId() > 0) {
				a.setCustomer(custRepo.find(a.getCustomer().getId()));
			}
		});
		
		// reservation
		reservRepo.save(data);
		
		data.getSecurity().setModUser(ctx.getCallerPrincipal().getName());

		// point add 
		if(data.getSite().isCashBack() && !data.isGivePoint()) {
			calculatePoints(data, true, "Add point by Reservation ID - {0}");
		}
		
		// point deduction by cancel operation
		if(data.getSite().isCashBack() && data.isGivePoint() && data.getStatus().equals("Cancel")) {
			calculatePoints(data, false, "Delete point because of Cancel reservation. Reservation ID - {0}");
		}
		
		// use point operation
		if((data.getCashBack() == null || data.getCashBack() == CashBackStatus.Cancel) 
				&& data.getUsedPoint() > 0) {
			calculateCashBack(data, CashBackStatus.CashBack, "Delete point because of Cash Back Operation. Reservation ID - {0}");
		}
		
		// edit point
		if(data.getCashBack() == CashBackStatus.Update 
				&& data.getUsedPoint() > 0) {
			calculateCashBack(data, CashBackStatus.Update, "Point has been updated by Reservation ID - {0}");
		}
		
		// cancel point
		if(data.getCashBack() == CashBackStatus.Cancel) {
			calculateCashBack(data, CashBackStatus.Cancel, "Point has been add by cancelling Cash Back. Reservation ID - {0}");
		}
		
	}
	
	private void calculateCashBack(Reservation data, CashBackStatus status, String remark) {
		Customer cust = data.getCustomer();
		
		CustomerPoint lastPoint = cust.getValidPoint().orElse(null);
		CustomerPoint point = new CustomerPoint();
		cust.addPoint(point);
		point.setReservation(data);
		point.setRoomNumber(data.getRoomName());
		point.setStayDate(data.getCheckOutDate());
		point.setRemark(remark);
		point.getSercurity().setCreateUser(ctx.getCallerPrincipal().getName());
		point.getSercurity().setModUser(ctx.getCallerPrincipal().getName());
		
		if(status == CashBackStatus.CashBack) {
			data.setCashBack(status);
			point.setAdd(false);
			point.setPoint(data.getUsedPoint());
		}
		
		if(null != lastPoint) {

			int netPoint = lastPoint.getPoint() - data.getUsedPoint();

			if(!(status == CashBackStatus.Update && netPoint == 0)) {
				
				if(status == CashBackStatus.Update) {
					point.setAdd(netPoint > 0);
					point.setPoint(Math.abs(netPoint));
				}
				
				lastPoint.getSercurity().setDelFlag(true);
				lastPoint.getSercurity().setModUser(ctx.getCallerPrincipal().getName());
				point.setLastTotal(lastPoint.getTotalPoint());
			} 

			if(status == CashBackStatus.Cancel && data.getUsedPoint() == 0) {
				data.setCashBack(status);
				point.setAdd(true);
				point.setPoint(lastPoint.getPoint());
			}
		}

		point.calculate();
		
	}

	private void calculatePoints(Reservation data, boolean b, String remark) {
		int statyCount = data.getRooms().size();
		Customer cust = data.getCustomer();
		
		CustomerPoint point = new CustomerPoint();
		point.setRoomNumber(data.getRoomName());
		point.setStayDate(data.getCheckOutDate());
		point.setAdd(b);
		point.setPoint(statyCount);
		point.getSercurity().setCreateUser(ctx.getCallerPrincipal().getName());
		point.getSercurity().setModUser(ctx.getCallerPrincipal().getName());
		
		cust.getValidPoint().ifPresent(p -> {
			p.getSercurity().setDelFlag(true);
			p.getSercurity().setModUser(ctx.getCallerPrincipal().getName());
			point.setLastTotal(p.getTotalPoint());
		});
		
		point.setRemark(remark);
		point.calculate();
		data.setGivePoint(b);
		
		cust.addPoint(point);
	}

	public List<Reservation> search(Searchable search) {
		return reservRepo.find(search);
	}

	public List<Reservation> getStayHistory(Customer cust) {
		List<CustomerReservation> list = custReservRepo.find(new CustomerReservationSearch(cust));
		return list.stream().map(a -> a.getReservation()).collect(Collectors.toList());
	}

	public List<RestaurantService> findCustomerRestaurantHistory(Customer cust) {
		return restRepo.find(new CustomerRestaurantSearch(cust));
	}

	public List<LaundryService> findCustomerLaundryHistory(Customer cust) {
		return laundRepo.find(new CustomerLaundrySearch(cust));
	}

	public long searchCount(Searchable search) {
		return reservRepo.findCount(search);
	}

	public Reservation findById(long id) {
		Reservation res = reservRepo.find(id);
		res.calculate();
		res.getCustomer().getCurrentPoint();
		return res;
	}

	public void save(CustomerPoint p) {
		pointRepo.save(p);
	}

}