package com.opm.hms.service;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.Rate;
import com.opm.hms.repo.RateRepo;

@LocalBean
@Stateless
public class RateService {

	@Inject
	private RateRepo repo;

	public void save(Rate data) {
		repo.save(data);
	}

	public List<Rate> search() {
		return repo.find(null);
	}

}