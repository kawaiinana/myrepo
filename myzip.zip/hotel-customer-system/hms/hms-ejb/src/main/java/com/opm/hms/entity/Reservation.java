package com.opm.hms.entity;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.CascadeType.PERSIST;
import static javax.persistence.FetchType.EAGER;
import static javax.persistence.GenerationType.IDENTITY;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;

import com.opm.hms.repo.LongIdEntity;

@Entity
public class Reservation implements LongIdEntity {

	public enum Currency {
		JPY, USD, MMK
	}
	
	public enum CashBackStatus {CashBack, Cancel, Update}

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	private LocalDate reserveDate;

	private LocalDate checkInDate;

	private LocalDate checkOutDate;

	private String status;

	private double roomCharge;

	private double restaurant;

	private double laundary;

	private double subTotal;

	private double tax;

	private double serviceCharges;

	private double total;

	private String remark;

	private int usedPoint;

	private double discount;

	private boolean givePoint;
	private CashBackStatus cashBack;

	private double paid;
	private Currency currency;

	@ManyToOne
	private Site site;

	private Security security;

	@OneToMany(mappedBy = "reservation", orphanRemoval = true, cascade = { PERSIST, MERGE })
	private List<CustomerReservation> customers;

	@OneToMany(mappedBy = "reservation", orphanRemoval = true, cascade = { PERSIST, MERGE }, fetch = EAGER)
	private List<RoomReservation> rooms;

	public Reservation() {
		security = new Security();
		customers = new ArrayList<>();
		rooms = new ArrayList<>();
	}

	public Customer getCustomer() {

		for (CustomerReservation cr : customers) {
			if (cr.isReservedCustomer()) {
				return cr.getCustomer();
			}
		}
		return null;
	}

	@PrePersist
	public void prePersist() {
		security.setCreation(LocalDateTime.now());
		security.setModification(LocalDateTime.now());
	}

	@PostLoad
	public void postLoad() {
		rooms.forEach(a -> a.getRoom());
		customers.forEach(a -> a.getCustomer());
	}

	public boolean isGivePoint() {
		return givePoint;
	}

	public void setGivePoint(boolean givePoint) {
		this.givePoint = givePoint;
	}

	public void calculate() {
		// room charges
		roomCharge = rooms.stream().mapToDouble(a -> a.getRoomCharge()).sum();

		// Restaurant Services
		restaurant = rooms.stream().flatMap(a -> a.getRestaurants().stream()).mapToDouble(a -> a.getTotal()).sum();

		// Laundry Service
		laundary = rooms.stream().flatMap(a -> a.getLaundries().stream()).mapToDouble(a -> a.getTotal()).sum();

		subTotal = roomCharge + restaurant + laundary;

		tax = subTotal * 0.05;

		serviceCharges = subTotal * 0.05;

		total = subTotal + tax;
		
	}

	public String getRoomName() {
		StringBuffer sb = new StringBuffer();
		List<Room> rooms = getRoomList();
		for (int i = 0; i < rooms.size(); i++) {
			if (i > 0) {
				sb.append(", ");
			}

			sb.append(rooms.get(i).getRoomNumber());
		}
		return sb.toString();
	}

	public List<Customer> getCustomerList() {
		return customers.stream().map(a -> a.getCustomer()).collect(Collectors.toList());
	}

	public List<Room> getRoomList() {
		return rooms.stream().map(a -> a.getRoom()).distinct().collect(Collectors.toList());
	}

	public List<LocalDate> getStayDates() {
		return rooms.stream().map(a -> a.getStayDate()).distinct().collect(Collectors.toList());
	}

	public RoomReservation getRoomReservation(Room room, LocalDate stayDate) {
		return rooms.stream().filter(a -> a.getRoom().equals(room) && a.getStayDate().equals(stayDate)).findAny()
				.orElse(null);
	}

	public List<RestaurantService> getRestaurantServices() {
		return rooms.stream().flatMap(a -> a.getRestaurants().stream()).collect(Collectors.toList());
	}

	public List<LaundryService> getLaundryServices() {
		return rooms.stream().flatMap(a -> a.getLaundries().stream()).collect(Collectors.toList());
	}

	public double getServiceCharges() {
		return serviceCharges;
	}

	public void setServiceCharges(double serviceCharges) {
		this.serviceCharges = serviceCharges;
	}

	public long getId() {
		return id;
	}

	public LocalDate getReserveDate() {
		return reserveDate;
	}

	public CashBackStatus getCashBack() {
		return cashBack;
	}

	public void setCashBack(CashBackStatus cashBack) {
		this.cashBack = cashBack;
	}

	public void setReserveDate(LocalDate reserveDate) {
		this.reserveDate = reserveDate;
	}

	public LocalDate getCheckInDate() {
		return checkInDate;
	}

	public void setCheckInDate(LocalDate checkInDate) {
		this.checkInDate = checkInDate;
	}

	public LocalDate getCheckOutDate() {
		return checkOutDate;
	}

	public void setCheckOutDate(LocalDate checkOutDate) {
		this.checkOutDate = checkOutDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getRoomCharge() {
		return roomCharge;
	}

	public void setRoomCharge(double roomCharge) {
		this.roomCharge = roomCharge;
	}

	public double getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(double restaurant) {
		this.restaurant = restaurant;
	}

	public double getLaundary() {
		return laundary;
	}

	public void setLaundary(double laundary) {
		this.laundary = laundary;
	}

	public double getSubTotal() {
		return subTotal;
	}

	public double getPaid() {
		return paid;
	}

	public void setPaid(double paid) {
		this.paid = paid;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public void setSubTotal(double subTotal) {
		this.subTotal = subTotal;
	}

	public double getTax() {
		return tax;
	}

	public void setTax(double tax) {
		this.tax = tax;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public int getUsedPoint() {
		return usedPoint;
	}

	public void setUsedPoint(int usedPoint) {
		this.usedPoint = usedPoint;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public Site getSite() {
		return site;
	}

	public void setSite(Site site) {
		this.site = site;
	}

	public Security getSecurity() {
		return security;
	}

	public void setSecurity(Security security) {
		this.security = security;
	}

	public List<CustomerReservation> getCustomers() {
		return customers;
	}

	public void addCustomer(CustomerReservation c) {
		c.setReservation(this);
		customers.add(c);
	}

	public void setCustomers(List<CustomerReservation> customers) {
		for (CustomerReservation c : customers) {
			addCustomer(c);
		}
	}

	public List<RoomReservation> getRooms() {
		return rooms;
	}

	public void addRoom(RoomReservation r) {
		r.setReservation(this);
		rooms.add(r);
	}

	public void setRooms(List<RoomReservation> rooms) {
		for (RoomReservation r : rooms) {
			addRoom(r);
		}
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((checkInDate == null) ? 0 : checkInDate.hashCode());
		result = prime * result + ((checkOutDate == null) ? 0 : checkOutDate.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Reservation other = (Reservation) obj;
		if (checkInDate == null) {
			if (other.checkInDate != null)
				return false;
		} else if (!checkInDate.equals(other.checkInDate))
			return false;
		if (checkOutDate == null) {
			if (other.checkOutDate != null)
				return false;
		} else if (!checkOutDate.equals(other.checkOutDate))
			return false;
		if (id != other.id)
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}

}