package com.opm.hms.service.search.Impl;

import java.util.HashMap;
import java.util.Map;

import com.opm.hms.entity.Customer;
import com.opm.hms.service.search.Searchable;

@SuppressWarnings("serial")
public class CustomerReservationSearch implements Searchable {

	private Customer customer;

	public CustomerReservationSearch(Customer customer) {
		super();
		this.customer = customer;
	}

	@Override
	public String where() {
		return "and t.customer.id = :customerId and t.reservation.status <> :status and t.security.delFlag = :delFlag ";
	}
	
	@Override
	public Map<String, Object> params() {
		Map<String, Object> params = new HashMap<>();
		
		// customer id
		params.put("customerId", customer.getId());
		
		// valid flag of reservation
		params.put("delFlag", false);
		
		// status of reservation
		params.put("status", "Cancel");
		
		return params;
	}


}
