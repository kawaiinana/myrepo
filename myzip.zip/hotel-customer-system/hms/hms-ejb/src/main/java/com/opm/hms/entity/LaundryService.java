package com.opm.hms.entity;

import javax.persistence.Entity;
import javax.persistence.PrePersist;

@Entity
public class LaundryService extends HotelService {

	private static final long serialVersionUID = 1L;
	private String type;

	private double unitPrice;

	private int quantity;

	public LaundryService() {
	}

	@PrePersist
	public void prePersist() {
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public int getQuentity() {
		return quantity;
	}

	public void setQuentity(int quentity) {
		this.quantity = quentity;
	}

	public void calculate() {
		super.setTotal(unitPrice * quantity); 
	}

}