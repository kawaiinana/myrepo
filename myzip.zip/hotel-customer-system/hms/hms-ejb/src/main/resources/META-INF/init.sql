insert into userTable(login, name, pass, role, delFlag) values ('admin', 'admin', 'jGl25bVBBBW96Qi9Te4V37Fnqchz/Eu4qB9vKrRIqRg=','Manager',false);
insert into userTable(login, name, pass, role, delFlag) values ('front', 'front', 'LY1pMXesRIlfwCwAnsP2rzLlHrAHg8FwANcFHRZiuTo=','Front', false);

insert into masterdata (category, sortorder, type, value, delflag) values ('Customer', 1, 'Nationality', 'Japan', false);
insert into masterdata (category, sortorder, type, value, delflag) values ('Customer', 2, 'Nationality', 'USA', false);
insert into masterdata (category, sortorder, type, value, delflag) values ('Customer', 3, 'Nationality', 'Singapore', false);
insert into masterdata (category, sortorder, type, value, delflag) values ('Customer', 4, 'Nationality', 'Myanmar', false);

insert into masterdata (category, sortorder, type, value, delflag) values ('Reservation', 1, 'Status', 'Reserved', false);
insert into masterdata (category, sortorder, type, value, delflag) values ('Reservation', 2, 'Status', 'Cancel', false);
insert into masterdata (category, sortorder, type, value, delflag) values ('Reservation', 3, 'Status', 'Check In', false);
insert into masterdata (category, sortorder, type, value, delflag) values ('Reservation', 4, 'Status', 'Check Out', false);

insert into masterdata (category, sortorder, type, value, delflag) values ('Laundry', 1, 'Type', 'Shirt', false);
insert into masterdata (category, sortorder, type, value, delflag) values ('Laundry', 2, 'Type', 'Pants', false);
insert into masterdata (category, sortorder, type, value, delflag) values ('Laundry', 3, 'Type', 'Suit', false);
insert into masterdata (category, sortorder, type, value, delflag) values ('Laundry', 4, 'Type', 'Underware', false);

insert into roomtype (roomtype, bedcount) values ('Single', 1);
insert into roomtype (roomtype, bedcount) values ('Twin', 2);
insert into roomtype (roomtype, bedcount) values ('Delux', 2);

insert into room (roomtype_id, roomnumber, delflag) values (1, 'S101', false);
insert into room (roomtype_id, roomnumber, delflag) values (1, 'S102', false);
insert into room (roomtype_id, roomnumber, delflag) values (1, 'S103', false);
insert into room (roomtype_id, roomnumber, delflag) values (1, 'S104', false);
insert into room (roomtype_id, roomnumber, delflag) values (2, 'T101', false);
insert into room (roomtype_id, roomnumber, delflag) values (2, 'T102', false);
insert into room (roomtype_id, roomnumber, delflag) values (2, 'T103', false);
insert into room (roomtype_id, roomnumber, delflag) values (2, 'T104', false);
insert into room (roomtype_id, roomnumber, delflag) values (3, 'D101', false);
insert into room (roomtype_id, roomnumber, delflag) values (3, 'D102', false);
insert into room (roomtype_id, roomnumber, delflag) values (3, 'D103', false);
insert into room (roomtype_id, roomnumber, delflag) values (3, 'D104', false);

insert into site (name, url, cashback, delflag) values ('Operating Partners', 'http://www.operating-partners.com', true, false);
insert into site (name, url, cashback, delflag) values ('Agoda', 'http://www.agoda.com', false, false);
insert into site (name, url, cashback, delflag) values ('Others', '', false, false);

