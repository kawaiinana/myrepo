package com.opm.shop.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

@SuppressWarnings("serial")
@Entity
public class Address implements Serializable {

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	@NotBlank(message = "Please enter address")
	@Lob
	private String addr;

	@NotBlank(message = "Please enter postcode")
	@Pattern(regexp = "\\d{5,5}", message = "Postal code must be 5 digits!")
	private String postalCode;

	@Column(name = "primary_address")
	private boolean primary;

	@Pattern(regexp = "\\d{6,12}", message = "Phone number must be digit and between 6 and 12 digits")
	private String phone;

	@ManyToOne
	@NotNull(message = "Please select a city!")
	private City city;

	@ManyToOne
	private Member member;
	
	@Column(name = "del_flag")
	private boolean deleteFlag;
	
	@PrePersist
	private void prePersist() {
		deleteFlag = false;
	}
	
	public Address() {
	}

	public String getAddressStr() {
		if(city != null && addr != null)
			return addr.concat(", ").concat(city.getName()).concat(", ").concat(city.getState().getName());
		return "";
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public boolean isPrimary() {
		return primary;
	}

	public void setPrimary(boolean primary) {
		this.primary = primary;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	public String getAddr() {
		return addr;
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public boolean isDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}	
}