package com.opm.shop.repo;


import java.util.List;

import javax.persistence.TypedQuery;

import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.entity.dto.ItemCountDto;

public class OrderRepo extends AbstractRepository<Order> {

	public OrderRepo() {
		super(Order.class);
	}
	
	public List<ItemCountDto> findOrderCount() {
		String sql = "select new com.opm.shop.entity.dto.ItemCountDto(t.item.id ,count(t.item.id)) from Order t where "
				+ "t.status = :status and t.item.status <> :itemStatus group by t.item.id";

		TypedQuery<ItemCountDto> query =  em.createQuery(sql, ItemCountDto.class);
 		query.setParameter("status", Status.Completed);
 		query.setParameter("itemStatus", com.opm.shop.entity.Item.Status.Ban);
		
		return query.getResultList();
	}
	
}