package com.opm.shop.service.imp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Member;
import com.opm.shop.repo.AccountRepo;
import com.opm.shop.repo.MembereRepo;
import com.opm.shop.service.AccountServiceLocal;

@Stateless
public class AccountService implements AccountServiceLocal {

	@Inject
	private AccountRepo acRepo;

	@Inject
	private MembereRepo memRepo;

	public void create(Member account) {
		memRepo.persit(account);
	}

	public void memberUpdate(Member account) {
		memRepo.update(account);
	}

	public int getAllCount() {
		return (int) memRepo.findCount(null, null);
	}

	public Account findById(int id) {
		return acRepo.findById(id);
	}

	@Override
	public Member findById(long id) {
		return memRepo.findById(id);
	}

	@Override
	public Account findByEmail(String email) {
		Map<String, Object> params = new HashMap<>();
		params.put("email", email);
		List<Account> accounts = acRepo.find("t.email = :email ", params);
		return accounts.size() > 0 ? accounts.get(0) : null;
	}

	@Override
	public void accountUpdate(Account loginUser) {
		acRepo.update(loginUser);
	}

	@Override
	public List<Account> findAllAccounts() {
		return acRepo.findAllUndeleted();
	}

	@Override
	public Account findByFbId(String fb_id) {
		Map<String, Object> params = new HashMap<>();
		params.put("fb_id", fb_id);
		List<Account> accounts = acRepo.find("t.fb_id = :fb_id ", params);
		return accounts.size() > 0 ? accounts.get(0) : null;
	}
}