package com.opm.shop.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opm.shop.entity.Category;
import com.opm.shop.entity.Item.Status;

public class ItemSearchParam {

	private StringBuffer stb;
	private Map<String, Object> params;
	
	public String getWhere() {
		return stb.length() == 4 ? null : stb.toString();
	}
	
	public Map<String, Object> getParams() {
		return params.isEmpty() ? null : params;
	}
	
	private ItemSearchParam(Category category, int brandId, String price, int stateId, String keyword) {
		super();
		stb = new StringBuffer("t.status <> :status ");
		params = new HashMap<>();
		params.put("status", Status.Ban);
		// category
		if (category != null) {

			stb.append("and t.category.id in :idList ");

			List<Integer> idList = new ArrayList<>();
			idList.add(category.getId());

			if (category.getChildren() != null) {
				for (Category second : category.getChildren()) {
					idList.add(second.getId());

					if (second.getChildren() != null) {

						for (Category third : second.getChildren()) {
							idList.add(third.getId());
						}
					}
				}
			}

			params.put("idList", idList);
		}
		
		// brand id
		if(brandId > 0) {
			stb.append("and t.brand.id = :brandId ");
			params.put("brandId",brandId);
		}
		
		// price
		if (null != price && !price.isEmpty()) {
			String[] array = price.split(",");
			double startprice = (null !=array[0] ? Double.parseDouble(array[0]) : 0) ;
			double endprice = (null !=array[1] ? Double.parseDouble(array[1]) : 0) ;
			if (startprice > 0 ) {
				stb.append("and t.price+t.commissionRate >= :startprice ");
				params.put("startprice",startprice);
			}
			
			if (endprice > 0 ) {
				stb.append("and t.price+t.commissionRate <= :endprice ");
				params.put("endprice",endprice);
			}
		}		
		
		// stateId
		if (stateId > 0) {
			stb.append("and t.itemState.id = :stateId ");
			params.put("stateId", stateId);
		}		
		
		// keywords
		if (null != keyword && !keyword.isEmpty()) {
			stb.append("and upper(t.name) like upper(:keyword)");
			params.put("keyword", keyword.concat("%"));
		}		
	}

	public static Builder builder() {
		return new Builder();
	}

	public static class Builder {
		private Category category; 
		private int brandId;
		private String price;
		private int stateId;
		private String keyword;
		
		private Builder() {
		}
		
		public Builder category(Category category) {
			this.category = category;
			return this;
		}
		
		public Builder brandId(int brandId) {
			this.brandId = brandId;
			return this;
		}
		
		public Builder price(String price) {
			this.price = price;
			return this;
		}
		
		public Builder stateId(int stateId) {
			this.stateId = stateId;
			return this;
		}
		
		public Builder keyword(String keyword) {
			this.keyword = keyword;
			return this;
		}
		
		public ItemSearchParam build() {
			return new ItemSearchParam(category, brandId, price, stateId, keyword);
		}
	}
}
