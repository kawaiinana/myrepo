package com.opm.shop.service.imp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;

import com.opm.shop.entity.Category;
import com.opm.shop.repo.CategoryRepo;
import com.opm.shop.service.CategoryServiceLocal;

@Stateless
public class CategoryService implements CategoryServiceLocal {
	@Inject
	private CategoryRepo repo;

	@Inject
	private Event<Category> event;

	@Override
	public void save(Category data) {

		if (isAlreadyExist(data.getName(), data.getId(), data.getId() == 0)) {
			throw new RuntimeException("Category already exist.");
		}

		if (data.getId() == 0) {
			repo.persit(data);
		} else {
			repo.update(data);
		}

		event.fire(data);
	}

	@Override
	public Category findById(int id) {
		return repo.findById(id);
	}

	private boolean isAlreadyExist(String name, int id, boolean isNew) {

		String where = "upper(t.name) = upper(:name)";
		Map<String, Object> params = new HashMap<>();

		if (!isNew) {
			where = "t.id <> :id and ".concat(where);
			params.put("id", id);
		}
		params.put("name", name);

		return !repo.find(where, params).isEmpty();
	}

	@Override
	public List<Category> findAll() {

		return repo.findAllUndeleted();
	}

	@Override
	public List<Category> findParents() {
		Map<String, Object> params = new HashMap<>();
		return repo.find("t.parent is null", params);
	}

	@Override
	public List<Category> find(int categoryId,int start,int limit) {

		StringBuffer stb = new StringBuffer("1=1 ");
		Map<String,Object> params = new HashMap<>();
		
		if( categoryId > 0){
			
			Category category = repo.findById(categoryId);			
			
			if(category != null){

				stb.append("and t.id in :idList ");
				
				List<Integer> idList = new ArrayList<>();
				idList.add(category.getId());
				
				if(category.getChildren() != null) {
					for(Category second : category.getChildren()) {
						idList.add(second.getId());
						
						if(second.getChildren() != null) {
							
							for(Category third : second.getChildren()) {
								idList.add(third.getId());
							}
						}
					}
				}
				
				params.put("idList", idList);
			}
		}
		
		return repo.find(params.size() == 0 ? null : stb.toString(), params.size() == 0 ? null : params,start,limit);
	}

	@Override
	public long findCount(int categoryId) {
		
		StringBuffer stb = new StringBuffer("1=1 ");
		Map<String,Object> params = new HashMap<>();
		
		if( categoryId > 0){
			
			Category category = repo.findById(categoryId);			
			
			if(category != null){

				stb.append("and t.id in :idList ");
				
				List<Integer> idList = new ArrayList<>();
				idList.add(category.getId());
				
				if(category.getChildren() != null) {
					for(Category second : category.getChildren()) {
						idList.add(second.getId());
						
						if(second.getChildren() != null) {
							
							for(Category third : second.getChildren()) {
								idList.add(third.getId());
							}
						}
					}
				}
				
				params.put("idList", idList);
			}
		}
		
		return repo.findCount(params.size() == 0 ? null : stb.toString(), params.size() == 0 ? null : params);
	}

	@Override
	public Category findByName(String name) {
		String where = "upper(t.name) = upper(:name)";
		Map<String, Object> params = new HashMap<>();
		params.put("name", name);

		return repo.find(where, params).get(0);
	}

}