package com.opm.shop.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

@SuppressWarnings("serial")
@Entity
public class Notification implements Serializable {

	public enum Status {
		New,
		Read
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	@ManyToOne
	private Account notiReceiver;

	@ManyToOne
	private Member notiCreator;

	@ManyToOne
	private Order order;

	private String notiURL;
	private String notiString;

	@Enumerated
	private Status status;
	
	private SecurityInfo security;
	
	@Column(name = "del_flag")
	private boolean deleteFlag;

	public Notification() {
		security = new SecurityInfo();
	}

	@PrePersist
	private void prePersist() {
		security.setCreation(new Date());
		security.setModification(new Date());
		deleteFlag = false;
	}

	@PreUpdate
	private void preUpdate() {
		security.setModification(new Date());
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Account getNotiReceiver() {
		return notiReceiver;
	}

	public void setNotiReceiver(Account notiReceiver) {
		this.notiReceiver = notiReceiver;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public String getNotiURL() {
		return notiURL;
	}

	public void setNotiURL(String notiURL) {
		this.notiURL = notiURL;
	}

	public String getNotiString() {
		return notiString;
	}

	public void setNotiString(String notiString) {
		this.notiString = notiString;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Member getNotiCreator() {
		return notiCreator;
	}

	public void setNotiCreator(Member notiCreator) {
		this.notiCreator = notiCreator;
	}

	public boolean isDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}	
}