package com.opm.shop.service.imp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Category;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Item.Status;
import com.opm.shop.entity.dto.ItemCountDto;
import com.opm.shop.repo.CategoryRepo;
import com.opm.shop.repo.ItemRepo;
import com.opm.shop.repo.OrderRepo;
import com.opm.shop.service.ItemServiceLocal;
import com.opm.shop.utils.ItemSearchParam;

@Stateless
public class ItemService implements ItemServiceLocal {

	@Inject
	private ItemRepo repo;
	
	@Inject
	private CategoryRepo crepo;
	
	@Inject
	private OrderRepo orderRepo;

	public void save(Item item) {
		repo.persit(item);
	}

	public void update(Item item) {
		repo.update(item);
	}

	@Override
	public Item findById(long id) {
		return repo.findById(id);
	}


	@Override
	public List<Item> findByMemberId(long id, int start, int limit) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();

		if (0 != id) {
			sb.append("t.owner.id= :id ");
			params.put("id", id);
		}
		
		return repo.find(params.size() == 0 ? null : sb.toString(), params.size() == 0 ? null : params, start, limit);
	}


	@Override
	public long findCount(Category category, int brandId, String price, int stateId, String keyword) {
		ItemSearchParam.Builder builder = ItemSearchParam.builder();
		
		if(null != category) {
			category = crepo.findById(category.getId());
		}

		ItemSearchParam paramHelper = builder.category(category)
			.brandId(brandId)
			.price(price)
			.stateId(stateId)
			.keyword(keyword)
			.build();
		
		return repo.findCount(paramHelper.getWhere(), paramHelper.getParams());
	}

	@Override
	public List<Item> find(Category category, int brandId, String price, int stateId, String keyword,
			int start, int limit) {
		
		ItemSearchParam.Builder builder = ItemSearchParam.builder();
		
		if(null != category) {
			category = crepo.findById(category.getId());
		}
		
		ItemSearchParam paramHelper = builder.category(category)
			.brandId(brandId)
			.price(price)
			.stateId(stateId)
			.keyword(keyword)
			.build();
		
		return repo.find(paramHelper.getWhere(), paramHelper.getParams(), start, limit);
	}

	@Override
	public List<Item> getNewItems() {
		String where="t.status <> :status order by t.security.creation desc ";
		Map<String, Object> params= new HashMap<>();
		params.put("status", Status.Ban);
		return repo.find(where, params, 0, 8);
	}

	@Override
	public List<Item> getBestSellers() {
		
		List<Item> result = new ArrayList<>();
		List<ItemCountDto> list = orderRepo.findOrderCount();
		
		List<Long> itemIdList = list.stream().sorted()
				.limit(8)
				.map(a -> a.getItem())
				.collect(Collectors.toList());
		
		for (Long id : itemIdList) {
			result.add(repo.findById(id));
		}
		
		return result;
	}

}