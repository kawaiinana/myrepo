package com.opm.shop.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@SuppressWarnings("serial")
@Entity
public class Player implements Serializable{

	@Id
	private int id;
	private String playerName;
	private String playerSurName;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getPlayerSurName() {
		return playerSurName;
	}
	public void setPlayerSurName(String playerSurName) {
		this.playerSurName = playerSurName;
	}
	
	
}
