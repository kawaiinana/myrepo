package com.opm.shop.service;



import java.util.List;

import com.opm.shop.entity.Category;

public interface CategoryServiceLocal {
    
    public void save(Category category);

   
    public Category findById(int id);
    
    public Category findByName(String name);
   
    List<Category> findAll();
    
    List<Category> find(int categoryId,int start,int limit);
    
    long findCount(int categoryId);
    
    List<Category> findParents();

}