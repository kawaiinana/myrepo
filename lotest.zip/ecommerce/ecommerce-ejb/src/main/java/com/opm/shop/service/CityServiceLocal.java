package com.opm.shop.service;

import java.util.List;

import javax.ejb.Local;
import com.opm.shop.entity.City;
import com.opm.shop.entity.Country;
import com.opm.shop.entity.State;

@Local
public interface CityServiceLocal {

	public void save(City city);

	public City findById(int id);

	public List<City> find(State state, Country country);

	public List<City> findByState(State state);

	public City findByName(String value);

	// for Paging
	List<City> find(State state, Country country, int start, int limit);

	Long findCount(State state, Country country);

}