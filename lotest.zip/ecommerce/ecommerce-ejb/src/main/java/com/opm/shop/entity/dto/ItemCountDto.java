package com.opm.shop.entity.dto;

public class ItemCountDto implements Comparable<ItemCountDto> {
	
	private long item;
	private long count;
	
	public ItemCountDto(long item, long count) {
		super();
		this.item = item;
		this.count = count;
	}

	public long getItem() {
		return item;
	}
	
	public void setItem(long item) {
		this.item = item;
	}

	public long getCount() {
		return count;
	}
	
	public void setCount(long count) {
		this.count = count;
	}

	@Override
	public int compareTo(ItemCountDto o) {
		Long result = o.getCount() - this.getCount();
		return result.intValue();
	}

}
