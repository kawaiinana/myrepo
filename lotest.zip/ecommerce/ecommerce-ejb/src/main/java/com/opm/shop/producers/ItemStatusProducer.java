package com.opm.shop.producers;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;

import com.opm.shop.entity.Item.Status;

@ApplicationScoped
public class ItemStatusProducer {

	 @Named
	 @Produces
	 private Status[] statuses = new Status[2];
	 
	 @PostConstruct
    private void init() {
       statuses[0]=Status.Available;
       statuses[1]=Status.SoldOut;
    }
}
