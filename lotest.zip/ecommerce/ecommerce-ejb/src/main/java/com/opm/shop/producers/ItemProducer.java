package com.opm.shop.producers;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Item;
import com.opm.shop.service.ItemServiceLocal;

@RequestScoped
public class ItemProducer {

	@Named
	@Produces
	private List<Item> newItems;

	@Named
	@Produces
	private List<Item> bestSellerItems;

	@Inject
	private ItemServiceLocal service;
	
		
	@PostConstruct
	private void init() {
		load(null);
	}

	private void load(@Observes Item data) {
		newItems = service.getNewItems();
		bestSellerItems = service.getBestSellers();
	}
}
