package com.opm.shop.rest.endpoint.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.opm.shop.entity.Order;
import com.opm.shop.service.OrderServiceLocal;

@Path("/orders")
public class OrderEndPoint {
	@Inject
	private OrderServiceLocal service;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response create(Order order) {
		try {
			service.save(order);
			return Response.ok(order).build();
		} catch (Exception e) {
			return Response.status(Status.NOT_IMPLEMENTED).entity("Order can't be posted!").build();
		}
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response update(Order order) {
		service.update(order);
		return Response.ok(order).build();
	}

	@GET
	@Path("{id:\\d+}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response findById(@PathParam("id") String id) {

		Order order = service.findById(Long.valueOf(id));

		if (null != order) {
			return Response.ok(order).build();
		}
		return Response.status(Status.NOT_FOUND).entity("Order not found!").build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAll() {

		List<Order> orderList = service.getAll();

		if (orderList.size() > 0) {
			return Response.ok(orderList).build();
		}
		return Response.status(Status.NOT_FOUND).entity("Orders not found!").build();
	}

	@GET
	@Path("search")
	@Produces(MediaType.APPLICATION_JSON)
	public Response findByStatus(@QueryParam("status") String status, @QueryParam("dateFrom") String dateFrom,
			@QueryParam("dateTo") String dateTo, @QueryParam("buyerId") long buyerId,
			@QueryParam("sellerId") long sellerId, @QueryParam("start") int start) throws ParseException {

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date df = null;
		Date dt = null;
		Order.Status st = null;

		if (!status.isEmpty()) {
			st = Order.Status.valueOf(status);
		}

		if (!dateFrom.isEmpty()) {
			df = sdf.parse(dateFrom);
		}

		if (!dateTo.isEmpty()) {
			dt = sdf.parse(dateTo);
		}

		List<Order> orders = service.findByStatus(st, df, dt, buyerId, sellerId, start, 10);

		return Response.ok(orders).build();

	}
}
