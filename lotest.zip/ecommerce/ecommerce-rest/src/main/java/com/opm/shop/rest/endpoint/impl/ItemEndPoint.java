package com.opm.shop.rest.endpoint.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.inject.Inject;
import javax.inject.Named;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.opm.shop.entity.Item;
import com.opm.shop.entity.Price;
import com.opm.shop.rest.endpoint.ImageData;
import com.opm.shop.rest.endpoint.ItemSearch;
import com.opm.shop.service.ItemServiceLocal;

@Path("/items")
public class ItemEndPoint {

	@Inject
	private ItemServiceLocal service;
	@Named
	@Inject
	private String imgurl;
	@Named
	@Inject
	private String imageFilePath;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response create(Item item) {
		try {
			service.save(item);
			return Response.ok(item).build();
		} catch (Exception e) {
			return Response.status(Status.NOT_IMPLEMENTED).entity("Item can't be posted!").build();
		}
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response update(Item item) {
		service.update(item);
		return Response.ok(item).build();
	}

	@GET
	@Path("{id:\\d+}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response findById(@PathParam("id") long id) {

		Item item = service.findById(id);

		if (item != null) {
			return Response.ok(item).build();
		}
		return Response.status(Status.NOT_FOUND).entity("Item not found!").build();
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("search")
	public Response find(ItemSearch itemSearch, @QueryParam("start") int start) {

		List<Item> allItems = service.find(itemSearch.getCategory(), itemSearch.getBrandId(), itemSearch.getPrice(),
				itemSearch.getStateId(), itemSearch.getKeyword(), start, 10);
		if (allItems.size() > 0) {

			makePrice(allItems);
		}

		return Response.ok(allItems).build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("search")
	public Response findByMemberId(@QueryParam("memberId") long memberId, @QueryParam("start") int start) {

		List<Item> allItems = service.findByMemberId(memberId, start, 10);
		if (allItems.size() > 0) {

			makePrice(allItems);
		}

		return Response.ok(allItems).build();
	}

	@Path("/uploadImage")
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response uploadImage(ImageData imageData) {
		byte[] img = Base64.getDecoder().decode(imageData.getEncodeString());
		String name = String.format("%s%s", new Date().getTime(), imageData.getExtension());
		String path = String.format("%s%s", imageFilePath, name);

		File file = new File(path);

		try (FileOutputStream out = new FileOutputStream(file)) {
			out.write(img);
			return Response.ok(name).build();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return Response.status(Status.NO_CONTENT).entity("Image upload fail!").build();
	}

	private void makePrice(List<Item> allItems) {
		if (allItems.size() > 0) {

			allItems.forEach(item -> {
				Set<Price> prices = item.getPrices();
				double price = prices.stream().filter(p -> p.getRefDate().compareTo(new Date()) <= 0)
						.sorted((a, b) -> b.getRefDate().compareTo(a.getRefDate())).findFirst()
						.map(p -> (Math.round(p.getPrice()))).orElse(null);
				item.setPrice(price);
			});
		}
	}

}
