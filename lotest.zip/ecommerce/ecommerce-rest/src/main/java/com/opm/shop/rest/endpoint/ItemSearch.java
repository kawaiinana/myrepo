package com.opm.shop.rest.endpoint;

import java.io.Serializable;

import com.opm.shop.entity.Category;

@SuppressWarnings("serial")
public class ItemSearch implements Serializable {

	
	private Category category;
	private int brandId;
	private String price;
	private int stateId;
	private String keyword;

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

}
