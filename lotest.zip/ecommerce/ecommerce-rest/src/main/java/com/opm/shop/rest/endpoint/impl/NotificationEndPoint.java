package com.opm.shop.rest.endpoint.impl;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Notification;
import com.opm.shop.service.NotificationServiceLocal;

@Path("/notifications")
public class NotificationEndPoint {
	@Inject
	private NotificationServiceLocal service;

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response create(Notification notification) {
		try {
			service.save(notification);
			return Response.ok(notification).build();
		} catch (Exception e) {
			return Response.status(Status.NOT_IMPLEMENTED).entity("notification upload fail!").build();
		}
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response update(Notification comment) {
		service.update(comment);
		return Response.ok().build();
	}

	/*
	 * @GET
	 * 
	 * @Produces(MediaType.APPLICATION_JSON) public Response
	 * findByNewStatus(long notiCreator){ List<Notification>
	 * newNotiList=service.findByNewStatus(notiCreator); return
	 * Response.ok(newNotiList).build(); }
	 * 
	 * @GET
	 * 
	 * @Produces(MediaType.APPLICATION_JSON) public Response
	 * findByOldStatus(long notiCreator){ List<Notification>
	 * oldNotiList=service.findByOldStatus(notiCreator); return
	 * Response.ok(oldNotiList).build(); }
	 */

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response findAdmin() {
		Account admins = service.findAdmin();
		return Response.ok(admins).build();
	}
}
