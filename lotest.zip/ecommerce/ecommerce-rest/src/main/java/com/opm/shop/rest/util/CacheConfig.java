package com.opm.shop.rest.util;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

@Retention(RUNTIME)
@Target(FIELD)
public @interface CacheConfig {
	boolean isPrivate() default true;
    boolean noCache() default false;
    boolean noStore() default false;
    boolean noTransform() default true;
    boolean mustRevalidate() default true;
    boolean proxyRevalidate() default false;
    int maxAge() default 0;
    int sMaxAge() default 0;
}
