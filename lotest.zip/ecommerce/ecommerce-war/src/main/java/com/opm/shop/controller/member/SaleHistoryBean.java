package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.Account;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.OrderServiceLocal;


@SuppressWarnings("serial")
@Named
@ViewScoped
public class SaleHistoryBean implements Serializable {

	private List<Order> orders;
	private Status status;
	private Date df;
	private Date dt;
	private Order order;
	private Status orderStatus;
	
	//pagination
	private int maxItemSize = 10;
	private Pager pager;
	
	@Inject
	@Named
	private Account loginMember;
	
	@Inject
	private OrderServiceLocal service;

	@PostConstruct
	public void init() {
		searchByStatus(1);
	}

	public void searchByStatus(int currentPage) {
		if (currentPage > 0) {
			Long totalSize = service.findByStatus(status, df, dt, 0, loginMember.getId(), 0,0).stream().count();
			
			if (df != null && dt != null && df.compareTo(dt) > 0) {
				FacesMessage message = new FacesMessage("Min Date must be less than Max Date");
				FacesContext.getCurrentInstance().validationFailed();
				FacesContext.getCurrentInstance().addMessage(null, message);
			}
			if ((currentPage - 1) * maxItemSize <= totalSize) {
				pager = new Pager(totalSize.intValue(), currentPage, maxItemSize);
				orders = service.findByStatus(status, df, dt, 0, loginMember.getId(), (currentPage - 1) * maxItemSize,
						maxItemSize);
			}

		}
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Date getDf() {
		return df;
	}

	public void setDf(Date df) {
		this.df = df;
	}

	public Date getDt() {
		return dt;
	}

	public void setDt(Date dt) {
		this.dt = dt;
	}

	public int getMaxItemSize() {
		return maxItemSize;
	}

	public void setMaxItemSize(int maxItemSize) {
		this.maxItemSize = maxItemSize;
	}

	public Pager getPager() {
		return pager;
	}

	public void setPager(Pager pager) {
		this.pager = pager;
	}

	public Status getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(Status orderStatus) {
		this.orderStatus = orderStatus;
	}
	
}