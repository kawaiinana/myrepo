package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Category;
import com.opm.shop.service.CategoryServiceLocal;

@SuppressWarnings("serial")
public class CategorySelectBean implements Serializable {

	@Named("categories")
	@Inject
	private List<Category> firstCategories;
	private List<Category> secondCategories;
	private List<Category> thirdCategories;	

	private Category first;
	private Category second;
	private Category third;
	
	@Inject
	private CategoryServiceLocal cService;
	
	@PostConstruct
	public void init() {
		firstCategories = new ArrayList<>();
		first = null;
		firstCategories = cService.findParents();
		/*if(firstCategories.size()>0){
			first = firstCategories.get(0);
		}*/
		//changeFirst();
	}	
	
	public void changeFirst() {
		second = null;
		third = null;
		if (first == null) {
			secondCategories = new ArrayList<>();
			thirdCategories = new ArrayList<>();
			
		} else {
			secondCategories = first.getChildren();
			/*if (secondCategories.size() > 0) {
				second = secondCategories.get(0);
			}*/
		}
		//changeSecond();
	}

	public void changeSecond() {
		third = null;
		if(second == null){
			thirdCategories = new ArrayList<>();
			
		}else{
			thirdCategories = second.getChildren();
			/*if(thirdCategories.size() > 0){
				third = thirdCategories.get(0);
			}*/
		}
	}
	
	public Category getSelectedCategory() {
		if(null != third) {
			return third;
		}
		
		if(null != second) {
			return second;
		}

		return first;
	}

	public void setSelectedCategory(Category c){
		if(c.level() == 1){
			first = c;
			changeFirst();
		}
		if(c.level() == 2){
			first = c.getParent();
			changeFirst();
			second = c;
		}
		if(c.level() == 3){
			first =c.getParent().getParent();
			changeFirst();
			second = c.getParent();
			changeSecond();
			third = c;
		}
	}

	public List<Category> getFirstCategories() {
		return firstCategories;
	}

	public void setFirstCategories(List<Category> firstCategories) {
		this.firstCategories = firstCategories;
	}

	public List<Category> getSecondCategories() {
		return secondCategories;
	}

	public void setSecondCategories(List<Category> secondCategories) {
		this.secondCategories = secondCategories;
	}

	public List<Category> getThirdCategories() {
		return thirdCategories;
	}

	public void setThirdCategories(List<Category> thirdCategories) {
		this.thirdCategories = thirdCategories;
	}

	public Category getFirst() {
		return first;
	}

	public void setFirst(Category first) {
		this.first = first;
	}

	public Category getSecond() {
		return second;
	}

	public void setSecond(Category second) {
		this.second = second;
	}

	public Category getThird() {
		return third;
	}

	public void setThird(Category third) {
		this.third = third;
	}
}
