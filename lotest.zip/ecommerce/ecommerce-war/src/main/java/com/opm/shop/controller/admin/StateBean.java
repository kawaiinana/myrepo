package com.opm.shop.controller.admin;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.Country;
import com.opm.shop.entity.State;
import com.opm.shop.service.StateServiceLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class StateBean implements Serializable {

	private List<State> states;
	private Country country;
	private State state;

	@Inject
	private List<Country> countries;

	@Inject
	private StateServiceLocal service;

	// For Paging
	private int maxItemSize = 10;

	private Pager pager;

	@PostConstruct
	private void init() {
		if (countries.size() > 0) {
			country = countries.get(0);
		}
		search(1);
	}

	public String delete(State state) {
		state.setDeleteFlag(true);
		service.save(state);
		return "";
	}

	public void search(int currentPage) {

		if (currentPage > 0) {
			states = service.findByCountry(country);
			System.out.println("BBB " + country + states.size());
			Long totalSize = states.stream().count();
			
			if ((currentPage - 1) * maxItemSize <= totalSize) {
				pager = new Pager(totalSize.intValue(), currentPage, maxItemSize);

				states = service.find(country, (currentPage - 1) * maxItemSize, maxItemSize);
			}
		}
	}

	public List<State> getStates() {
		return states;
	}

	public void setStates(List<State> states) {
		this.states = states;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public List<Country> getCountries() {
		return countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}

	public Pager getPager() {
		return pager;
	}

	public void setPager(Pager pager) {
		this.pager = pager;
	}

}