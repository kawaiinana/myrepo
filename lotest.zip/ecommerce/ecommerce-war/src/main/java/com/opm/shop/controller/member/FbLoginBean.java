package com.opm.shop.controller.member;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Model;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.opm.shop.utils.HashGenerationException;
import com.opm.shop.utils.PasswordGeneratorUtils;

@Model
public class FbLoginBean {

	private String login;

	@Inject
	private Event<String> loginEvent;

	@PostConstruct
	private void init() throws HashGenerationException {
		try {
			ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
			HttpServletRequest req = (HttpServletRequest) ctx.getRequest();
			
			String password = PasswordGeneratorUtils.generateSHA256("fb_id");
			String email = "masoemyatthu@gmail.com";
			req.login("masoemyatthu@gmail.com", "12345678");
			loginEvent.fire(email);

			FacesContext.getCurrentInstance().getExternalContext().redirect("member/member-home.xhtml");

		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

}
