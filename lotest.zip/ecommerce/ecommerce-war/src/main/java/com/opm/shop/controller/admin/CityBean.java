package com.opm.shop.controller.admin;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.City;
import com.opm.shop.entity.Country;
import com.opm.shop.entity.State;
import com.opm.shop.service.CityServiceLocal;
import com.opm.shop.service.StateServiceLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CityBean implements Serializable {

	private List<City> cities;
	private List<State> states;
	private Country country;
	private State state;

	@Inject
	private List<Country> countries;

	@Inject
	private CityServiceLocal service;

	@Inject
	private StateServiceLocal stateService;

	// paging
	private int maxItemSize = 10;
	private Pager pager;

	@PostConstruct
	private void init() {
		country = countries.get(0);
		loadStates();
		state = states.get(0);
		search(1);
	}

	public String delete(City city) {
		city.setDeleteFlag(true);
		service.save(city);
		return "";
	}

	public void loadStates() {
		states = stateService.findByCountry(country);
	}

	public void search(int currentPage) {
		if (currentPage > 0) {
			Long totalSize = service.findCount(state, country);

			if ((currentPage - 1) * maxItemSize <= totalSize) {
				pager = new Pager(totalSize.intValue(), currentPage, maxItemSize);

				cities = service.find(state, country, (currentPage - 1) * maxItemSize, maxItemSize);
			}
		}
	}

	public List<City> getCities() {
		return cities;
	}

	public void setCities(List<City> cities) {
		this.cities = cities;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	public CityServiceLocal getService() {
		return service;
	}

	public void setService(CityServiceLocal service) {
		this.service = service;
	}

	public List<State> getStates() {
		return states;
	}

	public void setStates(List<State> states) {
		this.states = states;
	}

	public List<Country> getCountries() {
		return countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}

	public Pager getPager() {
		return pager;
	}

	public void setPager(Pager pager) {
		this.pager = pager;
	}

}