package com.opm.shop.converters;

import javax.enterprise.context.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.ItemState;
import com.opm.shop.service.ItemStateServiceLocal;

@Named
@RequestScoped
public class ItemStateConverter implements Converter{

	@Inject
	private ItemStateServiceLocal service;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		if(null != value && !value.isEmpty()){
			ItemState s = service.findByName(value);
			return s ;
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if(value != null){
			ItemState i = (ItemState) value;
			return i.getState();
		}
		return null;
	}
}