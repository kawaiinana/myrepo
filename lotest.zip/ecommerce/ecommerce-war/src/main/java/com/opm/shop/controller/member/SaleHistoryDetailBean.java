package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.hibernate.validator.constraints.NotBlank;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Admin;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.AdminServiceLocal;
import com.opm.shop.service.OrderServiceLocal;
import com.opm.shop.service.imp.TakeMoneyFromBuyerService;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class SaleHistoryDetailBean implements Serializable {


	private Order order;
	private List<Admin> admins;
	private Notification noti;
	
	private Date minShippingDate;
	private Date maxShippingDate;
	
	@NotBlank(message="Please Enter remark")
	private String remark;
	@Inject
	@Named
	private Account loginMember;
	private boolean enableAction;

	@Inject
	@Named("loginMember")
	private Member loginMem;
	
	@Inject
	private OrderServiceLocal service;
	
	@Inject
	private Event<Notification> notiEvent;

	@Inject
	private AdminServiceLocal adminService;
	
	@Inject
	private TakeMoneyFromBuyerService moneyService;

	@PostConstruct
	public void init() {
		order = new Order();
		noti = new Notification();
		admins = adminService.findAllAdmins();
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		if (null != str) {
			order = service.findById(Long.parseLong(str));
			enableAction = (order.getStatus() == Status.Pending || order.getStatus() == Status.Processing);
		}
	}
	
	public String confrimPendingAction() {
		
		order.setStatus(Status.Processing);
		order.getSecurity().setModUser(loginMember.getId());
		order.setMinShippingDate(minShippingDate);
		order.setMaxShippingDate(maxShippingDate);
		Date currentDate = new Date();      
        Calendar c = Calendar.getInstance();
        c.setTime(currentDate);      
        c.add(Calendar.MONTH, 1);       
        Date currentDatePlusOne = c.getTime();
        c.setTime(minShippingDate);
        c.add(Calendar.MONTH, 1);  
        Date minDatePlusOne=c.getTime();
		if(minShippingDate.compareTo(currentDatePlusOne)>0){
			FacesMessage message = new FacesMessage("Min Date must be 1 month different with current date");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return "";
		}
		else if(maxShippingDate.compareTo(minDatePlusOne)>0){			
			FacesMessage message = new FacesMessage("Max Date must be 1 month different with Min date");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return "";
		}
		
		else if(minShippingDate.compareTo(maxShippingDate)<=0){
			service.save(order);
			moneyService.getMoney(order);			
			return "/member/sale-history.xhtml?faces-redirect=true";
		}else
		{
			
			FacesMessage message = new FacesMessage("Min Date must be less than Max Date");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return "";
		}
		//invoke Asynchronous method
	}
	
	public String rejectPendingAction() {
		order.setStatus(Status.Reject);
		order.getSecurity().setModUser(loginMember.getId());
		order.setRemark(remark);
		service.save(order);

		changeStatusNoti();
		noti.setNotiString("Your " + order.getItem().getName() + " order was rejected."
				+ "\nClick here to see the Remark.");
		notiEvent.fire(noti);

		return "/member/sale-history.xhtml?faces-redirect=true";
	}

	public String deliverdAction() {
		order.setStatus(Status.ConfirmShipment);
		order.getSecurity().setModUser(loginMember.getId());
		service.save(order);

		changeStatusNoti();
		noti.setNotiString("Your " + order.getItem().getName() + " order had been sent to you. Please confirm item received.");
		notiEvent.fire(noti);

		return "/member/sale-history.xhtml?faces-redirect=true";
	}

	private void changeStatusNoti() {
		noti.setNotiReceiver(order.getBuyer());
		noti.setNotiURL("/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setNotiCreator(loginMem);
	}
	
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getMinShippingDate() {
		return minShippingDate;
	}

	public void setMinShippingDate(Date minShippingDate) {
		this.minShippingDate = minShippingDate;
	}

	public Date getMaxShippingDate() {
		return maxShippingDate;
	}

	public void setMaxShippingDate(Date maxShippingDate) {
		this.maxShippingDate = maxShippingDate;
	}

	public boolean isEnableAction() {
		return enableAction;
	}

	public void setEnableAction(boolean enableAction) {
		this.enableAction = enableAction;
	}

	public String orderCancelAction() {
		return "";
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Account getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Account loginMember) {
		this.loginMember = loginMember;
	}

	public List<Admin> getAdmins() {
		return admins;
	}

	public void setAdmins(List<Admin> admins) {
		this.admins = admins;
	}
}