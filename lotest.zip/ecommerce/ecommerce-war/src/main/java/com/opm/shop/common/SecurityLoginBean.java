package com.opm.shop.common;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Model;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotBlank;

import com.opm.shop.controller.member.FbLoginBean;
import com.opm.shop.entity.Account;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Member.Status;
import com.opm.shop.service.AccountServiceLocal;
import com.opm.shop.utils.PasswordGeneratorUtils;

@Model
@SuppressWarnings("serial")
public class SecurityLoginBean implements Serializable {

	@Size(max = 300)
	@NotBlank(message = "Enter Nick Name")
	private String name;

	@Pattern(regexp = "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\." + "[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@"
			+ "(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?", message = "Enter valid email")
	private String email;

	@Size(min = 8, message = "Enter password of at least 8 digit")
	@Pattern(regexp = "[a-zA-Z0-9]+", message = "Enter password")
	private String password;

	private Member member1;
	private List<Account> accounts;

	@Inject
	private AccountServiceLocal service;

	@Inject
	private Event<String> loginEvent;

	private String fb_id;

	private String image;
	
	private String confirmPassword;
	
	private boolean isSignUpMember;

	@PostConstruct
	private void init() {
		accounts = service.findAllAccounts();
	}

	public String login(boolean isSignUpMember) {

		try {
			ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
			HttpServletRequest req = (HttpServletRequest) ctx.getRequest();

			System.out.println(email + " this is email");
			req.login(email, password);

			loginEvent.fire(email);

			if (req.isUserInRole("Admin")) {
				return "/admin/home?faces-redirect=true";
			}

			if (isSignUpMember) {
				return "/member/my-profile?faces-redirect=true";
			}

			return "/index?faces-redirect=true";

		} catch (Exception e) {
			FacesMessage message = new FacesMessage("Login Error", "Please check your Email and Password!");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}

		return "";
	}

	/*public String loginFb(boolean isSignUpMember) {
		try {
			ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
			HttpServletRequest req = (HttpServletRequest) ctx.getRequest();

			System.out.println(email + " this is email");
			password = PasswordGeneratorUtils.generateSHA256("fb_id");
			
			System.out.println(password + " This is generate password");
			req.login(email, password);

			loginEvent.fire(email);

			if (req.isUserInRole("Admin")) {
				return "/admin/home?faces-redirect=true";
			}

			if (isSignUpMember) {
				return "/member/my-profile?faces-redirect=true";
			}

			return "/index?faces-redirect=true";

		} catch (Exception e) {
			FacesMessage message = new FacesMessage("Login Error", "Please check your Email and Password!");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}

		return "";
	}
*/
	public void checkFbAccount(String fb_id) {
		if (accounts.stream().map(a -> a.getFb_id().equalsIgnoreCase(fb_id)).findAny().isPresent()) {
			System.out.println("i'm go to login fb");
		}else{
			System.out.println("i'm go to fb sign up");
			fBSignUp(confirmPassword);
		}
		
	}

	public String fBSignUp(String confirmPassword) {
		boolean check = false;
		if (password.equals(confirmPassword)) {
			System.out.println(confirmPassword + " : confirm pass");
			System.out.println(fb_id + " this is fb_id");
			if (accounts.stream().filter(a -> a.getFb_id().equalsIgnoreCase(fb_id)).findFirst().isPresent()) {
				System.out.println("I'm herer in if else");
				Member m = new Member();
				m.setFb_id(fb_id);
				m.setNickname(name);
				m.setEmail(email);
				m.setImage(image);
				m.setPassword(confirmPassword);
				m.setStatus(Status.Active);

				service.create(m);

				boolean isSignUpMember = true;

				return login(isSignUpMember);
			}
		} else {
			System.out.println("error");
		}

		return "";
	}

	public String signUp(String confirmPassword) {
		System.out.println(accounts.size() + "This is account list");
		if (!accounts.stream().map(a -> a.getEmail().equals(email)).findFirst().isPresent()) {
			if (password.equals(confirmPassword)) {
				System.out.println("I'm HERE");
				System.out.println(name + " this is name");
				System.out.println(email + " this is email");

				Member m = new Member();
				m.setNickname(name);
				m.setEmail(email);
				m.setStatus(Status.Active);

				service.create(m);

				boolean isSignUpMember = true;
				return login(isSignUpMember);
			} else {
				FacesMessage message = new FacesMessage("Password Error", "This confirm password do not match!");
				FacesContext.getCurrentInstance().addMessage(null, message);
			}
		} else {
			FacesMessage message = new FacesMessage("Account Error", "This account already exist.");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}

		return "";
	}

	public String logout() {
		ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
		ctx.invalidateSession();
		return "/index?faces-redirect=true";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Member getMember() {
		return member1;
	}

	public void setMember(Member member) {
		this.member1 = member;
	}

	public String getFb_id() {
		return fb_id;
	}

	public void setFb_id(String fb_id) {
		this.fb_id = fb_id;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public boolean isSignUpMember() {
		return isSignUpMember;
	}

	public void setSignUpMember(boolean isSignUpMember) {
		this.isSignUpMember = isSignUpMember;
	}

}