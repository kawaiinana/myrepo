package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Item;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class IndexSearchResultBean implements Serializable {

	// search criteria
	@Inject
	private CategorySelectBean categoryBean;
	private int brandId;
	private String price;
	private int stateId;
	private String keyword;
	
	// result list
	private List<Item> items;	
	
	public String search() {
		
		Flash flash = FacesContext.getCurrentInstance().getExternalContext().getFlash();
		flash.put("category", categoryBean.getSelectedCategory());
		flash.put("brandId" ,brandId);
		flash.put("price", price);
		flash.put("stateId", stateId);
		flash.put("keyword", keyword);
		
		return "/product-search-result";
	}
	
	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public CategorySelectBean getCategoryBean() {
		return categoryBean;
	}

	public void setCategoryBean(CategorySelectBean categoryBean) {
		this.categoryBean = categoryBean;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	
}