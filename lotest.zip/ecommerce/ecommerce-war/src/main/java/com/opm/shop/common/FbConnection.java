package com.opm.shop.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;

import javax.faces.bean.ManagedBean;
import javax.net.ssl.HttpsURLConnection;

@ManagedBean
@SuppressWarnings("serial")
public class FbConnection implements Serializable {

	public static final String FB_APP_ID = "110878429545644";
	public static final String FB_APP_SECRET = "299261a87974a2a09c3e38d9adf9414a";
	public static final String REDIRECT_URI = "http://localhost:8080/ecommerce-war/";

	private String accessToken = "";

	public String getFbAuthUrl() {
		String fbLoginUrl = "";
		try {
			fbLoginUrl = "http://www.facebook.com/dialog/oauth?" + "client_id=" + FbConnection.FB_APP_ID
					+ "&redirect_uri=" + URLEncoder.encode(FbConnection.REDIRECT_URI, "UTF-8") + "&scope=email";

		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(fbLoginUrl + " This is getFbAuth Method");
		return fbLoginUrl;
	}

	public String getFbGraphUrl(String code) {
		String fbGraphUrl = "";
		if (code == null) {
			try {
				fbGraphUrl = "https://graph.facebook.com/oauth/access_token?" + "client_id=" + FbConnection.FB_APP_ID
						+ "&redirect_uri=" + URLEncoder.encode(FbConnection.REDIRECT_URI, "UTF-8") + "&client_secret="
						+ FB_APP_SECRET + "&code=" + code;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		System.out.println(fbGraphUrl + " this is fbGraphUrl");
		return fbGraphUrl;
	}

	public String getAccessToken(String code) throws IOException {
		HttpsURLConnection fbConnection = null;
		System.out.println(code + " this is code in get access token ");
		if (" ".equals(accessToken)) {

			URL fbGraphUrl = new URL(getFbGraphUrl(code));
			HttpURLConnection request1 = (HttpURLConnection) fbGraphUrl.openConnection();
			request1.setRequestMethod("GET");
			request1.connect();

			System.out.println(fbGraphUrl + "FbGraphUrl");

			StringBuilder sb = null;
			try {
				System.out.println("in try catch");
				fbConnection = (HttpsURLConnection) fbGraphUrl.openConnection();
				String name = fbConnection.getPermission().getName();
				System.out.println(name + " FB Name");
				BufferedReader reader = new BufferedReader(new InputStreamReader(fbConnection.getInputStream()));
				sb = new StringBuilder();
				String inputLine;
				while ((inputLine = reader.readLine()) != null)
					sb.append(inputLine).append("\n");
			} catch (IOException e) {
				e.printStackTrace();
				throw new RuntimeException("Unable to connect facebook" + e);
			} finally {
				try {
					fbConnection.getInputStream().close();
				} catch (IOException e) {
				}
			}
			accessToken = sb.toString();
			if (accessToken.startsWith("{")) {
				throw new RuntimeException("ERROR: Access Token Invalid: " + accessToken);
			}
		}
		System.out.println(accessToken + " thiis is  access tokennnn");
		return accessToken;
	}

}
