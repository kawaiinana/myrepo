/*package com.opm.shop.common;

import java.io.Serializable;
import java.util.Map;

import javax.enterprise.inject.Model;

@Model
@SuppressWarnings("serial")
public class FbLoginBean implements Serializable {

private String code = "";
	
	public FbLoginBean() {
		// TODO Auto-generated constructor stub
	}
	
	FbConnection fbConnection = new FbConnection();
	//String accessToken = fbConnection.getAccessToken(code);
	FbGraph fbGraph = new FbGraph(accessToken);
	String graph = fbGraph.getFbGraph();
	Map<String, String> fbProfileData = fbGraph.getGraphData(graph);

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public FbConnection getFbConnection() {
		return fbConnection;
	}
	public void setFbConnection(FbConnection fbConnection) {
		this.fbConnection = fbConnection;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public FbGraph getFbGraph() {
		return fbGraph;
	}
	public void setFbGraph(FbGraph fbGraph) {
		this.fbGraph = fbGraph;
	}
	public String getGraph() {
		return graph;
	}
	public void setGraph(String graph) {
		this.graph = graph;
	}
	public Map<String, String> getFbProfileData() {
		return fbProfileData;
	}
	public void setFbProfileData(Map<String, String> fbProfileData) {
		this.fbProfileData = fbProfileData;
	}
	
	
}
*/