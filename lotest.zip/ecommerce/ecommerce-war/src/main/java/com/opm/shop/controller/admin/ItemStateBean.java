package com.opm.shop.controller.admin;

import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.event.Event;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.ItemState;
import com.opm.shop.service.ItemStateServiceLocal;

@Named
@RequestScoped
public class ItemStateBean {

	@Inject
	private List<ItemState> itemStates;

	@Inject
	private Event<ItemState> itemStatesEvent;
	
	@Inject
	private ItemStateServiceLocal service;

	public String delete(ItemState itemState) {
		itemState.setDeleteFlag(true);
		service.update(itemState);
		itemStatesEvent.fire(itemState);
		return "/admin/itemstatelist.xhtml?faces-redirect=true";
	}

	public List<ItemState> getItemStates() {
		return itemStates;
	}

	public void setItemStates(List<ItemState> itemStates) {
		this.itemStates = itemStates;
	}
}