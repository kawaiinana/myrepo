package com.opm.shop.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.faces.bean.ManagedBean;
import javax.net.ssl.HttpsURLConnection;

import org.json.JSONException;
import org.json.JSONObject;

@ManagedBean
@SuppressWarnings("serial")
public class FbGraph implements Serializable {

	private String accessToken;

	public FbGraph() {
	}

	public FbGraph(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getFbGraph() {
		System.out.println(accessToken + " this is accessstoken in FBGRAPH");
		String graph = null;
		if (".".equals(accessToken)) {
		try {
			String g = "https://graph.facebook.com/me?access_token=" + accessToken;
			System.out.println(g + "this is g");

			URL u = new URL(g);
			HttpsURLConnection c = (HttpsURLConnection) u.openConnection();
			BufferedReader reader = new BufferedReader(new InputStreamReader(c.getInputStream()));
			StringBuilder sb = new StringBuilder();
			String inputLine = null;
			try {
				while ((inputLine = reader.readLine()) != null) {
					sb.append(inputLine).append("\n");
				}
			} catch (IOException e) {
			} finally {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			graph = sb.toString();
			System.out.println(graph);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException("ERROR in getting FB graph data. " + e);
		}
		}
		return graph;
	}

	public Map<String, String> getGraphData(String fbGraph) {
		Map<String, String> fbProfile = new HashMap<String, String>();
		try {
			JSONObject json = new JSONObject(fbGraph);
			fbProfile.put("id", json.getString("id"));
			fbProfile.put("first_name", json.getString("first_name"));
			if (json.has("email"))
				fbProfile.put("email", json.getString("email"));
			if (json.has("gender"))
				fbProfile.put("gender", json.getString("gender"));
		} catch (JSONException e) {
			e.printStackTrace();
			throw new RuntimeException("ERROR in parsing FB graph data. " + e);
		}
		System.out.println(fbProfile.get("first_name") + " this is first name");
		return fbProfile;
	}

}
