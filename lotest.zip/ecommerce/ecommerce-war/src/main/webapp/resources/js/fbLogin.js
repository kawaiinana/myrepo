/**
 * 
 */
FB.Event.subscribe('auth.login', function(response) {
	Log.info('auth.login event handler', response);
});
FB.Event.subscribe('auth.logout', function(response) {
	Log.info('auth.logout event handler', response);
});
FB.Event.subscribe('auth.statusChange', function(response) {
	Log.info('auth.statusChange event handler', response);
});
FB.Event.subscribe('auth.authResponseChange', function(response) {
	Log.info('auth.authResponseChange event handler', response);
});

document.getElementById('fb-login-status').onclick = function() {
	FB.getLoginStatus(function(response) {
		Log.info('FB.getLoginStatus callback', response);
	});
};

document.getElementById('fb-login-status-force').onclick = function() {
	FB.getLoginStatus(function(response) {
		Log.info('FB.getLoginStatus force=true callback', response);
	}, true);
};

document.getElementById('fb-get-auth-response').onclick = function() {
	Log.info('FB.getAuthResponse', FB.getAuthResponse());
};

document.getElementById('fb-login').onclick = function() {
	FB.login(function(response) {
		Log.info('FB.login callback', response);
	});
};

document.getElementById('fb-permissions').onclick = function() {
	FB.login(function(response) {
		Log.info('FB.login with permissions callback', response);
	}, {
		scope : 'publish_actions'
	});
};

document.getElementById('fb-logout').onclick = function() {
	FB.logout(function(response) {
		Log.info('FB.logout callback', response);
	});
};