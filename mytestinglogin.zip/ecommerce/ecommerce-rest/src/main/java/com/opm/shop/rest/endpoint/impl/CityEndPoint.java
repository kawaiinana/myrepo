package com.opm.shop.rest.endpoint.impl;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.opm.shop.entity.City;
import com.opm.shop.entity.State;
import com.opm.shop.service.CityServiceLocal;

@Path("/cities")
public class CityEndPoint {

	@Inject
	private CityServiceLocal service;

	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@POST
	public Response findByState(State state) {
		List<City> cities = service.findByState(state);
		return Response.ok(cities).build();
	}

}
