package com.opm.shop.rest.endpoint.impl;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.opm.shop.entity.ItemState;
import com.opm.shop.service.ItemStateServiceLocal;

@Path("/itemStates")
public class ItemStateEndPoint {

	@Inject
	private ItemStateServiceLocal service;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response findAll() {

		List<ItemState> allItemStates = service.getAll();

		return Response.ok(allItemStates).build();
	}
}
