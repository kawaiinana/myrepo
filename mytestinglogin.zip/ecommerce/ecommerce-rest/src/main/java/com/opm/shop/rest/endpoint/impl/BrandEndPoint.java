package com.opm.shop.rest.endpoint.impl;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.opm.shop.entity.Brand;
import com.opm.shop.service.BrandServiceLocal;

@Path("/brands")
public class BrandEndPoint {

	@Inject
	private BrandServiceLocal service;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response findAllUndeleted() {
		List<Brand> listBrand = service.findAllUndeleted();
		return Response.ok(listBrand).build();
	}

}
