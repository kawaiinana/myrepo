package com.opm.shop.rest.endpoint;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ImageData implements Serializable {

	private String encodeString;
	private String extension;

	public String getEncodeString() {
		return encodeString;
	}

	public void setEncodeString(String encodeString) {
		this.encodeString = encodeString;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

}
