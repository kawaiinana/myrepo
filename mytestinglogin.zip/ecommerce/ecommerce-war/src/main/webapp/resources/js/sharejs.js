/**
 * 
 */
window.fbAsyncInit = function() {
	FB.init({
		appId : '1360841670672856',
		autoLogAppEvents : true,
		xfbml : true,
		picture: 'http://192.168.211.111:8080/image//address.jpg', 
		version : 'v2.9'
	});
	FB.AppEvents.logPageView();
};
(function(d, s, id) {
	var js, fjs = d.getElementsByTagName(s)[0];
	if (d.getElementById(id))
		return;
	js = d.createElement(s);
	js.id = id;
	js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.9&appId=1360841670672856";
	fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));