package com.opm.shop.controller.admin;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.Brand;
import com.opm.shop.service.BrandServiceLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class BrandBean implements Serializable {

	private Brand brand;
	private List<Brand> brandsList;

	@Inject
	private BrandServiceLocal service;

	@Inject
	private Event<Brand> brandEvent;
	
	private String brandName;
	
	private int maxItemSize = 10;
	
	private Pager pager;

	@PostConstruct
	private void init() {
		brand = new Brand();
		search(1);
	}

	public String save() {
		if (!brandsList.stream().filter(b -> b.getName().equalsIgnoreCase(brand.getName())).findAny().isPresent()) {
			service.create(brand);
			brandEvent.fire(brand);
			return "/admin/brand.xhtml?faces-redirect=true";
		} else {
			FacesMessage message = new FacesMessage("Name Error", "This Brand name already exist.");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String update() {
		Brand b = new Brand();
		b = service.findByNameAndId(brand.getName(), brand.getId());
		if (b == null) {
			service.update(brand);
			brandEvent.fire(brand);
			return "/admin/brand.xhtml?faces-redirect=true";
		} else {
			FacesMessage message = new FacesMessage("Name Error", "This Brand name already exist.");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String delete(Brand b) {
		b.setDeleteFlag(true);
		service.delete(b);
		brandEvent.fire(brand);
		return "/admin/brand.xhtml?faces-redirect=true";
	}

	public String edit(Brand b) {
		brand = b;
		return "/admin/brand.xhtml?faces-redirect=true";
	}

	public List<Brand> search(int currentPage) {
		if(currentPage > 0) {
			Long totalSize = service.findCount(brandName);
			
			if((currentPage - 1) * maxItemSize <= totalSize) {
				pager = new Pager(totalSize.intValue(), currentPage, maxItemSize);
				
				brandsList = service.find(brandName, (currentPage - 1) * maxItemSize, maxItemSize);
			}
		}
		return brandsList;
	}

	public List<Brand> getBrandsList() {
		return brandsList;
	}

	public void setBrandsList(List<Brand> brandsList) {
		this.brandsList = brandsList;
	}

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public Pager getPager() {
		return pager;
	}

	public void setPager(Pager pager) {
		this.pager = pager;
	}

}
