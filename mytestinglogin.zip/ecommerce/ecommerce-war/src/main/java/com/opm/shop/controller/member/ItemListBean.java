package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.Account;
import com.opm.shop.entity.Category;
import com.opm.shop.entity.Item;
import com.opm.shop.service.ItemServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class ItemListBean implements Serializable {

	private List<Item> items;
	private Account loginUser;
	
	private int maxItemSize = 10;

	private Pager pager;
	@Inject
	private ItemServiceLocal service;

	@Inject
	private CategorySelectBean categoryBean;

	@PostConstruct
	public void init() {
		categoryBean.setFirst(null);
		categoryBean.changeFirst();
		items = new ArrayList<>();
		search(1);
	}

	public void search(int currentPage) {
		items = new ArrayList<>();
		Long totalSize;
		if(currentPage > 0) {
			
			if (null != categoryBean.getSelectedCategory() && categoryBean.getSelectedCategory().getId() != 0) {
				totalSize = service.findCount(categoryBean.getSelectedCategory().getId(), null);
			} else {
				totalSize = service.findCount(0,null);
			}
			
			if((currentPage - 1) * maxItemSize <= totalSize) {
				pager = new Pager(totalSize.intValue(), currentPage, maxItemSize);				
				if (null != categoryBean.getSelectedCategory() && categoryBean.getSelectedCategory().getId() != 0) {
					items = service.find(categoryBean.getSelectedCategory().getId(), null,(currentPage - 1) * maxItemSize, maxItemSize);
				} else {
					items = service.findAll((currentPage - 1) * maxItemSize, maxItemSize);
				}
			}
		}
		
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public List<Item> search(Category category, String keyword) {
		return null;
	}

	public Account getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(Account loginUser) {
		this.loginUser = loginUser;
	}

	public CategorySelectBean getCategoryBean() {
		return categoryBean;
	}

	public void setCategoryBean(CategorySelectBean categoryBean) {
		this.categoryBean = categoryBean;
	}

	public int getMaxItemSize() {
		return maxItemSize;
	}

	public void setMaxItemSize(int maxItemSize) {
		this.maxItemSize = maxItemSize;
	}

	public Pager getPager() {
		return pager;
	}

	public void setPager(Pager pager) {
		this.pager = pager;
	}
	
}