package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Observes;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.Account;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Notification.Status;
import com.opm.shop.service.NotificationServiceLocal;

@SuppressWarnings("serial")
@ViewScoped
@Named
public class NotificationBean implements Serializable {

	private Notification noti;
	private List<Notification> newNotis;
	private List<Notification> oldNotis;
	private long countNoti;
	private Pager nPager;
	private Pager oPager;
	private int maxItemSize = 10;
	private Long totalSize;
	
	@Inject
	@Named
	private Account loginUser;
	
	@Inject
	private NotificationServiceLocal service;

	@PostConstruct
	private void init() {
		search(1,"nNoti","oNoti");
		countNoti = totalSize;
	}
	
	public void search(int currentPage,String nNoti, String oNoti) {
		if(currentPage > 0) {
			
			if(nNoti != null || nNoti != ""){				
				totalSize = service.findCount(loginUser.getId(),"nNoti",null);			
				if((currentPage - 1) * maxItemSize <= totalSize) {
					nPager = new Pager(totalSize.intValue(), currentPage, maxItemSize);					
					newNotis = service.findByNewStatus(loginUser.getId(),(currentPage - 1) * maxItemSize, maxItemSize);		
				}
			}
			if(oNoti != null || oNoti != ""){				
				Long totalSize = service.findCount(loginUser.getId(),null,"oNoti");				
				if((currentPage - 1) * maxItemSize <= totalSize) {
					oPager = new Pager(totalSize.intValue(), currentPage, maxItemSize);					
					oldNotis = service.findByOldStatus(loginUser.getId(),(currentPage - 1) * maxItemSize, maxItemSize);
				}				
			}			
		}
	}

	public void newNoti(@Observes Notification noti) {
		
		noti.setStatus(Status.New);
		service.save(noti);
		search(1, "nNoti", null);
	}

	public String oldNoti(Notification notification) {

		notification.setStatus(Status.Read);
		service.update(notification);
		search(1, null, "oNoti");
		
		return notification.getNotiURL();

	}

	public Notification getNoti() {
		return noti;
	}

	public void setNoti(Notification noti) {
		this.noti = noti;
	}

	public List<Notification> getNewNotis() {
		return newNotis;
	}

	public void setNewNotis(List<Notification> newNotis) {
		this.newNotis = newNotis;
	}

	public List<Notification> getOldNotis() {
		return oldNotis;
	}

	public void setOldNotis(List<Notification> oldNotis) {
		this.oldNotis = oldNotis;
	}

	public long getCountNoti() {
		return countNoti;
	}

	public void setCountNoti(long countNoti) {
		this.countNoti = countNoti;
	}

	public Pager getnPager() {
		return nPager;
	}

	public void setnPager(Pager nPager) {
		this.nPager = nPager;
	}

	public Pager getoPager() {
		return oPager;
	}

	public void setoPager(Pager oPager) {
		this.oPager = oPager;
	}
}