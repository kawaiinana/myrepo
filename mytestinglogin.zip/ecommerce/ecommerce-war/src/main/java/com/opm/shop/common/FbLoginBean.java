package com.opm.shop.common;

import java.io.Serializable;
import java.util.Map;

@SuppressWarnings("serial")
public class FbLoginBean implements Serializable {

	private String code = "";
	FbConnection fbConnection = new FbConnection();
	String accessToken = fbConnection.getAccessToken(code);

	FbGraph fbGraph = new FbGraph(accessToken);
	String graph = fbGraph.getFbGraph();
	Map<String, String> fbProfileData = fbGraph.getGraphData(graph);
	public Map<String, String> getFbProfileData() {
		return fbProfileData;
	}
}
