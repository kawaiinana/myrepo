package com.opm.shop.controller.member;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

import com.opm.shop.common.FbLoginBean;
import com.opm.shop.entity.Player;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class PlayerBean implements Serializable {

	private Player player;
	private String playerName;
	private String playerSurname;
	private FbLoginBean fbLoginBean;

	public PlayerBean() {

	}

	@PostConstruct
	public void init() {
		player = new Player();
		fbLoginBean = new FbLoginBean();
		if (playerName != null) {
			playerName = playerName.toUpperCase();
		}
		if (playerSurname != null) {
			playerSurname = playerSurname.toUpperCase();
		}
	}

	public String toUpperCase() {
		playerName = player.getPlayerName().toUpperCase();
		playerSurname = player.getPlayerSurName().toUpperCase();

		return "my-payment?faces-redirect=true&includeViewParams=true";
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public String getPlayerSurname() {
		return playerSurname;
	}

	public void setPlayerSurname(String playerSurname) {
		this.playerSurname = playerSurname;
	}

	public FbLoginBean getFbLoginBean() {
		return fbLoginBean;
	}

	public void setFbLoginBean(FbLoginBean fbLoginBean) {
		this.fbLoginBean = fbLoginBean;
	}
	
}
