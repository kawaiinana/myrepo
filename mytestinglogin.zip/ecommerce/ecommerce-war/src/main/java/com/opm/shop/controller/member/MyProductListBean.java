package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.service.ItemServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MyProductListBean implements Serializable {

	private Member member;
	private List<Item> items;
	private int categoryId;
	private String keyword;
	private int memberId;

	private int maxItemSize = 9;

	private Pager pager;

	@Named
	@Inject
	private Member loginMember;

	@Inject
	private ItemServiceLocal service;

	@PostConstruct
	private void init() {
		items = new ArrayList<Item>();
		searchById(1, 0);
	}

	public String serchByMember() {
		items = service.findByMemberId(loginMember.getId(), 0, 0);
		return "product-listing.xhtml?faces-redirect=true";
	}

	public void searchById(int currentPage, int id) {
		if (currentPage > 0) {
			Long totalSize = service.findByMemberId(loginMember.getId(), 0, 0).stream().count();
			if ((currentPage - 1) * maxItemSize <= totalSize) {
				pager = new Pager(totalSize.intValue(), currentPage, maxItemSize);
				items.addAll(service.findByMemberId(loginMember.getId(), (currentPage - 1) * maxItemSize, maxItemSize));
			}
		}
	}

	public Member getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Member loginMember) {
		this.loginMember = loginMember;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}

	public int getMaxItemSize() {
		return maxItemSize;
	}

	public void setMaxItemSize(int maxItemSize) {
		this.maxItemSize = maxItemSize;
	}

	public Pager getPager() {
		return pager;
	}

	public void setPager(Pager pager) {
		this.pager = pager;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

}
