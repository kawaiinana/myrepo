package com.opm.shop.controller.member;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ShoppingCartBean implements Serializable{

    /*private void item;

    private void quantity;

    private void size;

    public Orders getOrder() {
        return null;
    }*/
    
    public void clear() {
    }

}