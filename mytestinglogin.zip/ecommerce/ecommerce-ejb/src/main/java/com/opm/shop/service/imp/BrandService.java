package com.opm.shop.service.imp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Brand;
import com.opm.shop.repo.BrandRepo;
import com.opm.shop.service.BrandServiceLocal;

@Stateless
public class BrandService implements BrandServiceLocal {

	@Inject
	private BrandRepo brandRepo;

	@Override
	public void create(Brand brand) {
		if (brand.getId() == 0) {
			brandRepo.persit(brand);
		} else {
			brandRepo.update(brand);
		}
	}

	@Override
	public List<Brand> findAllUndeleted() {

		Map<String, Object> params = new HashMap<>();
		params.put("one", 1);
		return brandRepo.find("1=:one order by t.name asc", params);
	}

	@Override
	public void delete(Brand brand) {
		brandRepo.update(brand);
	}

	@Override
	public List<Brand> search(String brandName) {
		Map<String, Object> params = new HashMap<>();
		params.put("brandName", brandName.concat("%"));
		return brandRepo.find("upper(t.name) like upper(:brandName)", params);
	}

	@Override
	public Brand findByName(String name) {
		Map<String, Object> params = new HashMap<>();
		String where = ("upper(t.name) = upper(:name)");
		params.put("name", name);
		List<Brand> list = brandRepo.find(where, params);
		if (!list.isEmpty()) {
			return list.get(0);
		}
		return null;

	}

	@Override
	public void update(Brand brand) {
		brandRepo.update(brand);
	}

	@Override
	public Brand findByNameAndId(String name, int id) {
		Map<String, Object> params = new HashMap<>();
		String where = ("upper(t.name) = upper(:name) and t.id != :id");
		params.put("name", name);
		params.put("id", id);
		List<Brand> list = brandRepo.find(where, params);
		if (!list.isEmpty()) {
			return list.get(0);
		}
		return null;
	}


	@Override
	public List<Brand> find(String name, int start, int limit) {

		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();

		if (null != name && !name.isEmpty()) {
			sb.append("upper(t.name) like upper(:name)");
			params.put("name", name.concat("%"));
		}

		return brandRepo.find(params.size() == 0 ? null : sb.toString(), params.size() == 0 ? null : params, start,
				limit);

	}

	@Override
	public long findCount(String name) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();

		if (null != name && !name.isEmpty()) {
			sb.append("upper(t.name) like upper(:name)");
			params.put("name", name.concat("%"));
		}
		return brandRepo.findCount(params.size() == 0 ? null : sb.toString(), params.size() == 0 ? null : params);
	}

}
