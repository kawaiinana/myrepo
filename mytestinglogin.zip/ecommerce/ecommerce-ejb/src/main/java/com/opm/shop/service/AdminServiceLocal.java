package com.opm.shop.service;

import java.util.List;

import javax.ejb.Local;

import com.opm.shop.entity.Admin;

@Local
public interface AdminServiceLocal {

	List<Admin> findAllAdmins();

}