package com.opm.shop.service.imp;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Admin;
import com.opm.shop.repo.AdminRepo;
import com.opm.shop.service.AdminServiceLocal;

@Stateless
public class AdminService implements AdminServiceLocal {

	@Inject
	private AdminRepo repo;

	@Override
	public List<Admin> findAllAdmins() {

		return repo.find(null, null);
	}
}
