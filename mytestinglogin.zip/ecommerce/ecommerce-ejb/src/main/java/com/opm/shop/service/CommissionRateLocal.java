package com.opm.shop.service;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import com.opm.shop.entity.CommissionRate;
import com.opm.shop.entity.CommissionRate.RateType;

@Local
public interface CommissionRateLocal {

	void save(CommissionRate comRate);

	CommissionRate findById(int id);
	
	List<CommissionRate> findAll();
	
	void delete(CommissionRate c);
	
	List<CommissionRate> find(RateType type, Date refDate,int start,int limit);
	
	long findCount(RateType type, Date refDate);
	
	boolean isAlreadyExist(double amountFrom,double amountTo, int id, boolean isNew);
	
	double calculateRate(double price);

}
