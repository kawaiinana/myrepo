package com.opm.shop.service.imp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;
import com.opm.shop.entity.City;
import com.opm.shop.entity.Country;
import com.opm.shop.entity.State;
import com.opm.shop.repo.CityRepo;
import com.opm.shop.service.CityServiceLocal;

@Stateless
public class CityService implements CityServiceLocal {

	@Inject
	private CityRepo repo;

	@Override
	public void save(City data) {
		if (data.getId() == 0) {
			repo.persit(data);
		} else {
			repo.update(data);
		}
	}

	@Override
	public City findById(int id) {
		return repo.findById(id);
	}

	@Override
	public List<City> find(State state, Country country) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();

		if (null != state) {
			sb.append("t.state.id = :state ");
			params.put("state", state.getId());
		}

		if (null == state && null != country) {
			sb.append("t.state.country.id = :country");
			params.put("country", country.getId());
		}
		return repo.find(sb.toString().isEmpty() ? null : sb.toString(), params.size() == 0 ? null : params);
	}

	@Override
	public List<City> findByState(State state) {
		if (null != state) {
			String where = "t.state.id = :state";
			Map<String, Object> params = new HashMap<>();
			params.put("state", state.getId());
			return repo.find(where, params);
		}

		return new ArrayList<>();
	}

	@Override
	public City findByName(String value) {
		String where = "upper(t.name) = upper(:value) ";
		Map<String, Object> params = new HashMap<>();
		params.put("value", value);
		List<City> city = repo.find(where, params);
		return city.get(0);
	}

	@Override
	public List<City> find(State state, Country country, int start, int limit) {

		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();

		if (null != state) {
			sb.append("t.state.id = :state ");
			params.put("state", state.getId());
		}

		if (null == state && null != country) {
			sb.append("  t.state.country.id = :country ");
			params.put("country", country.getId());
		}
		
		else if (null != state && null != country) {
			sb.append(" and t.state.country.id = :country ");
			params.put("country", country.getId());
		}


		return repo.find(params.size() == 0 ? null : sb.toString(), params.size() == 0 ? null : params, start, limit);

	}

	@Override
	public Long findCount(State state, Country country) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();

		if (null != state) {
			sb.append(" t.state.id= :state");
			params.put("state", state.getId());
		}

		if ((null != country)&& (null != state)) {
			sb.append(" and t.state.country.id= :country");
			params.put("country", country.getId());
		}

		else if ((null != country) && (null == state)){
			sb.append(" t.state.country.id= :country");
			params.put("country", country.getId());
		}
		
		return repo.findCount(params.size() == 0 ? null : sb.toString(), params.size() == 0 ? null : params);
	}

}
