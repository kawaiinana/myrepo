package com.opm.shop.entity;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.GenerationType.IDENTITY;
import static javax.persistence.TemporalType.TIMESTAMP;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Table;
import javax.persistence.Temporal;

@SuppressWarnings("serial")
@Entity
@Table(name = "order_table")
public class Order implements Serializable {

	public enum Status {
		Processing,
		Pending,
		Break_Down,
		Cash_Transferred,
		ConfirmShipment,
		Completed,
		Received,
		Reject,
		Expired,
		Cancel
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	private String code;
	private double unitPrice;
	private double commissionRate;

	@Temporal(TIMESTAMP)
	private Date orderDate;

	@Temporal(TIMESTAMP)
	private Date minShippingDate;

	@Temporal(TIMESTAMP)
	private Date maxShippingDate;

	@Enumerated(STRING)
	private Status status;

	@Lob
	private String remark;

	@ManyToOne
	private Member buyer;

	@ManyToOne
	private Item item;

	@ManyToOne
	private Address shippingAddress;

	@Embedded
	private SecurityInfo security;

	@Column(name = "del_flag")
	private boolean deleteFlag;
	
	public Order() {
		security = new SecurityInfo();
	}

	@PrePersist
	private void prePersist() {
		security.setCreation(new Date());
		security.setModification(new Date());
		deleteFlag = false;
	}
	
	@PreUpdate
	private void preUpdate() {
		security.setModification(new Date());
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public double getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(double unitPrice) {
		this.unitPrice = unitPrice;
	}

	public double getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(double commissionRate) {
		this.commissionRate = commissionRate;
	}

	public Date getMinShippingDate() {
		return minShippingDate;
	}

	public void setMinShippingDate(Date minShippingDate) {
		this.minShippingDate = minShippingDate;
	}

	public Date getMaxShippingDate() {
		return maxShippingDate;
	}

	public void setMaxShippingDate(Date maxShippingDate) {
		this.maxShippingDate = maxShippingDate;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Member getBuyer() {
		return buyer;
	}

	public void setBuyer(Member buyer) {
		this.buyer = buyer;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Address getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(Address shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public boolean isDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}	
}