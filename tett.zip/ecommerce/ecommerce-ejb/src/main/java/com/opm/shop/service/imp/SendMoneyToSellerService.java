package com.opm.shop.service.imp;

import java.util.Date;
import java.util.List;

import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Admin;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.AdminServiceLocal;
import com.opm.shop.service.NotificationServiceLocal;
import com.opm.shop.service.OrderServiceLocal;

@Stateless
public class SendMoneyToSellerService{


	@Inject
	private AdminServiceLocal adminService;
	
	@Inject
	private OrderServiceLocal orderService;
	
	@Inject
	private NotificationServiceLocal notiService;
	
	Notification noti = new Notification();
	
	@Asynchronous
	public void sendMoney(Order order){
		
		List<Admin> admins = adminService.findAllAdmins();
		
		
		
		try{
			//Money Transaction work here
			
			//Transaction Complete
			order.setStatus(Status.Completed);
			orderService.save(order);
			
			for(int i=0 ; i<3 ; i++){
				if(i == 0){
					orderBreakDownNoti(order);
					noti.setNotiReceiver(order.getBuyer());
					noti.setNotiURL("/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
					noti.setNotiString(order.getItem().getName()+" order was successfully completed.");
					notiService.save(noti);
					noti = new Notification();
				} else if(i == 1){
					orderBreakDownNoti(order);
					noti.setNotiReceiver(order.getItem().getOwner());
					noti.setNotiURL("/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
					noti.setNotiString(order.getItem().getName()+" order was successfully completed.Check your account balance");
					notiService.save(noti);
					noti = new Notification();
				} else{
					for (Admin admin : admins) {
						adminNoti(admin,order);
						noti.setNotiString(order.getItem().getName()+" order was successfully completed. Money was sent to Seller.");
						notiService.save(noti);
						noti = new Notification();
					}
				}
			}
		}catch (Exception e) {
			//TODO
		}
	}
	
	private void adminNoti(Admin admin,Order order){
		noti.setNotiReceiver(admin);
		noti.setNotiURL("/admin/orderhistorydetail.xhtml?faces-redirect=true&id=" + order.getId());
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
	}
	
	 private void orderBreakDownNoti(Order order){
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
	} 
}
