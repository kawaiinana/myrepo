package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Category;
import com.opm.shop.service.CategoryServiceLocal;


@SuppressWarnings("serial")
@Named
@ViewScoped
public class AddItemCategoryBean implements Serializable {

	private List<Category> firstCategories;
	private List<Category> secondCategories;
	private List<Category> thirdCategories;

	private Category first;
	private Category second;
	private Category third;
	
	@Inject
	private CategoryServiceLocal catService;
	
	@PostConstruct
	private void init(){
		
		firstCategories = catService.findParents();
		System.out.println(firstCategories + " This is first Category");
		if (firstCategories.size() > 0 && firstCategories !=null ) {
			first = firstCategories.get(0);
			changeFirst();
		}
	}

	public void changeFirst() {
		System.out.println(first.getName() + " This is first");
		
		if(first != null){
			secondCategories = first.getChildren();
		}else{
			secondCategories = new ArrayList<>();
		}
		
		if(secondCategories.size() > 0){
			second = secondCategories.get(0);
		}else {
			second = null;
		}
		
		System.out.println(secondCategories + " This is second in changeFirst");
		
		changeSecond();
	}

	public void changeSecond() {

		if(second != null){
			thirdCategories = second.getChildren();
		}else{
			thirdCategories = new ArrayList<>();
		}
		
		if(thirdCategories.size() > 0){
			third = thirdCategories.get(0);
		}else {
			third = null;
		}		
	}
	
	public Category getSelectedCategory(){
		if (third != null) {
			return third;
		}if (second != null) {
			return second;
		} 
		
		return third;
	}

	public List<Category> getFirstCategories() {
		return firstCategories;
	}

	public void setFirstCategories(List<Category> firstCategories) {
		this.firstCategories = firstCategories;
	}

	public List<Category> getSecondCategories() {
		return secondCategories;
	}

	public void setSecondCategories(List<Category> secondCategories) {
		this.secondCategories = secondCategories;
	}

	public List<Category> getThirdCategories() {
		return thirdCategories;
	}

	public void setThirdCategories(List<Category> thirdCategories) {
		this.thirdCategories = thirdCategories;
	}

	public Category getFirst() {
		return first;
	}

	public void setFirst(Category first) {
		this.first = first;
	}

	public Category getSecond() {
		return second;
	}

	public void setSecond(Category second) {
		this.second = second;
	}

	public Category getThird() {
		return third;
	}

	public void setThird(Category third) {
		this.third = third;
	}
	
	

}
