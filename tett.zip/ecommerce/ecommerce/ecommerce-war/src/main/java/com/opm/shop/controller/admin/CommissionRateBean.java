package com.opm.shop.controller.admin;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.CommissionRate;
import com.opm.shop.entity.CommissionRate.RateType;
import com.opm.shop.service.CommissionRateLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CommissionRateBean implements Serializable {

	private List<CommissionRate> comRateList;
	private CommissionRate commissionRate;
	
	@Inject
	private CommissionRateLocal service;

	@PostConstruct
	public void init() {
		commissionRate = new CommissionRate();
		try {
			comRateList = service.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String addRate() {
		try {
			service.save(commissionRate);
			comRateList.add(commissionRate);
			commissionRate = new CommissionRate();
			return "/admin/commission-rate.xhtml?faces-redirect=true";

		} catch (RuntimeException e) {
			FacesMessage message = new FacesMessage("AmountError", e.getCause().getMessage());
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String delete(CommissionRate c) {
		c.setDeleteFlag(true);
		service.delete(c);
		return "/admin/commission-rate.xhtml?faces-redirect=true";
	}

	public String update(CommissionRate c) {
		commissionRate = c;
		return "/admin/commission-rate.xhtml?faces-redirect=true";
	}

	public List<CommissionRate> search(RateType type, Date refDate) {
		if (refDate != null || type != null) {
			return comRateList = service.find(type, refDate);
		}
		return null;
	}

	public List<CommissionRate> getComRateList() {
		return comRateList;
	}

	public void setComRateList(List<CommissionRate> comRateList) {
		this.comRateList = comRateList;
	}

	public CommissionRate getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(CommissionRate commissionRate) {
		this.commissionRate = commissionRate;
	}
}
