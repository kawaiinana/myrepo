package com.opm.shop.controller.member;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.service.OrderServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class OrderDetailBean implements Serializable {

	private Order order;
	private Notification noti;
	
	@Named
	@Inject
	private Account loginUser;

	@Inject
	private OrderServiceLocal service ;
	
	@PostConstruct
	public void init() {
		order = new Order();
		noti = new Notification();
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		if(null != str){
			order = service.findById(Long.parseLong(str));			
		}	
	}
	
	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Notification getNoti() {
		return noti;
	}

	public void setNoti(Notification noti) {
		this.noti = noti;
	}
}