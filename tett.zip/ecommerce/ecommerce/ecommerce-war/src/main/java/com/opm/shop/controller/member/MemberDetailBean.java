package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Address;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Member.Status;
import com.opm.shop.service.ItemServiceLocal;
import com.opm.shop.service.MemberServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MemberDetailBean implements Serializable {

	private List<Item> items;
	private Address member;
	private Member mem;
	
	@Inject
	private MemberServiceLocal service;
	
	@Inject
	private ItemServiceLocal itemService;

	@PostConstruct
	public void init() {
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		mem = service.findById(Long.parseLong(str));
		member = service.findByMember(Long.parseLong(str));
		items=itemService.findByMemberId(Long.parseLong(str));
	}
	
	public void ban() {
		mem.setStatus(Status.Ban);
		service.update(mem);
	}

	public String buy() {
		return "";
	}

	public Address getMember() {
		return member;
	}

	public void setMember(Address address) {
		this.member = address;
	}

	public Member getMem() {
		return mem;
	}

	public void setMem(Member mem) {
		this.mem = mem;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}
}