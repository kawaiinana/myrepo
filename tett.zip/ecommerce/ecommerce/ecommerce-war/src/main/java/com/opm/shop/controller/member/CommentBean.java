package com.opm.shop.controller.member;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CommentBean implements Serializable {

	@PostConstruct
	public void init() {

	}

}
