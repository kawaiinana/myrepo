package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Address;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.entity.State;
import com.opm.shop.service.ItemServiceLocal;
import com.opm.shop.service.OrderServiceLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CheckOutBean implements Serializable {

	private Address address;
	private Item item;
	private Notification noti;
	private List<Order> orders;
	private Order order;

	@Named
	@Inject
	private Member loginMember;

	@Inject
	private AddressBean addressBean;

	@Inject
	private ItemDetailBean itemDetailBean;

	@Inject
	private ItemServiceLocal itemService;

	@Inject
	private OrderServiceLocal orderService;
	
	@Inject
	private Event<Notification> notiEvent;

	@PostConstruct
	public void init() {
		item = new Item();
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		item = itemService.findById(Long.parseLong(str));
		order = new Order();

	}

	public String save() {
		boolean flg = false;
		String returnState = "";
		Set<State> set = item.getState();
		List<State> list = new ArrayList<>(set);
		for (int i = 0; i < list.size(); i++) {
			if (null != addressBean.getState() && list.get(i).getName().equals(addressBean.getState().getName())) {
				flg = true;
				order.setStatus(Status.Pending);
				order.setBuyer(loginMember);
				order.setOrderDate(new Date());
				order.setItem(item);
				//add price and commission rate
				order.setUnitPrice(item.getPrice());
				order.setCommissionRate(item.getCommissionRate());
				orderService.save(order);
				
				for (int j = 0; j < 2; j++) {
					
					addStatusNoti();
					if (j == 0) {
						noti.setNotiReceiver(loginMember);
						noti.setNotiURL("/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
						noti.setNotiString("You have started " + order.getItem().getName()
								+ " order. Please wait for Owner Confirm.");
					} else {
						noti.setNotiReceiver(order.getItem().getOwner());
						noti.setNotiURL("/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
						noti.setNotiString(order.getBuyer().getNickname() + " starts " + order.getItem().getName()
								+ " order. Please confirm.");
					}
					
					notiEvent.fire(noti);
				}
				returnState = "/member/purchase-history?faces-redirect=true";
			}
		}
		if(null == addressBean.getState()){
			FacesMessage message = new FacesMessage("Empty Address", "Please Fill Shipping Address!");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}else if(!flg){
			FacesMessage message = new FacesMessage("Not-Match", "You can't buy this item because of target area");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return returnState;
	}

	private void addStatusNoti() {
		noti = new Notification();
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setNotiCreator(loginMember);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
	}
	
	public Item getItem() {
		return item;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Member getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Member loginMember) {
		this.loginMember = loginMember;
	}

	public AddressBean getAddressBean() {
		return addressBean;
	}

	public void setAddressBean(AddressBean addressBean) {
		this.addressBean = addressBean;
	}

	public ItemDetailBean getItemDetailBean() {
		return itemDetailBean;
	}

	public void setItemDetailBean(ItemDetailBean itemDetailBean) {
		this.itemDetailBean = itemDetailBean;
	}

}