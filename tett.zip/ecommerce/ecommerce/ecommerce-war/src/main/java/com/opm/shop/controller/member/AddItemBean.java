package com.opm.shop.controller.member;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.flow.FlowScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.Part;

import com.opm.shop.entity.Country;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Price;
import com.opm.shop.entity.State;
import com.opm.shop.service.CommissionRateLocal;
import com.opm.shop.service.ItemServiceLocal;
import com.opm.shop.service.StateServiceLocal;

@SuppressWarnings("serial")
@Named
@FlowScoped("product")
public class AddItemBean implements Serializable {

	private Item item;
	private Price price;
	private Set<State> selectedState;
	private Set<Country> selectedCountry;
	private List<State> stateList;
	private Part file;
	private String path;
	private Set<Price> prices;

	@Named
	@Inject
	private String imageFilePath;

	@Named
	@Inject
	private Member loginMember;

	@Inject
	private CategorySelectBean categoryBean;

	@Inject
	private ItemServiceLocal service;

	@Inject
	private CommissionRateLocal commissionService;

	@Inject
	private StateServiceLocal stateService;

	@PostConstruct
	public void init() {
		String itemId = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		item = new Item();
		prices = new LinkedHashSet<>();
		stateList = new ArrayList<>();
		selectedState = new LinkedHashSet<>();
		selectedCountry = new LinkedHashSet<>();
		price = new Price();

		if (itemId != null) {
			item = service.findById(Long.parseLong(itemId));
			updateData();
		}
	}

	public String save() {

		item.setState(selectedState);
		item.setCountry(selectedCountry);

		// add prices
		price.setPrice(item.getPrice());
		price.setRefDate(new Date());
		prices.add(price);
		item.setPrices(prices);

		item.setOwner(loginMember);

		item.getSecurity().setModUser(loginMember.getId());

		if (item.getId() > 0) {

			service.update(item);
		} else {
			item.getSecurity().setCreateUser(loginMember.getId());
			service.save(item);
		}
		return "/member/product-listing";
	}

	public void updateData() {
		if (item.getCategory() != null)
			categoryBean.setSelectedCategory(item.getCategory());
		if (item.getCountry() != null)
			selectedCountry.addAll(item.getCountry());
		if (selectedCountry != null)
			changeCountry();
		if (item.getState() != null)
			selectedState.addAll(item.getState());
	}

	public void calRate() {
		double rate = commissionService.calculateRate(item.getPrice());
		item.setCommissionRate(rate);
	}

	public void changeCountry() {
		stateList.clear();

		for (Country c : selectedCountry) {
			stateList.addAll(stateService.findByCountry(c));
		}
	}

	public void upload() {
		try {
			if (null != file) {
				String fileName = file.getSubmittedFileName();
				String[] array = fileName.split("\\.");
				String extension = array[array.length - 1];
				path = String.format("%d.%s", new Date().getTime(), extension);
				file.write(imageFilePath.concat(path));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		item.addImage(path);
	}

	public String addCoverImage(String coverImage) {
		item.setCoverImage(coverImage);
		return "";
	}

	public String removeImage(String img) {
		if (img.equals(item.getCoverImage())) {
			item.setCoverImage("");
		}
		item.removeImage(img);
		return "";
	}

	public String goToProductStep3() {
		// add category
		item.setCategory(categoryBean.getSelectedCategory());
		return "product-step3";
	}

	public String imgUploadChk() {
		if (item.getImage().isEmpty()) {
			FacesMessage message = new FacesMessage("Please choose an image!");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return "";
		}
		if (item.getCoverImage().isEmpty() || item.getCoverImage() == null) {
			FacesMessage message = new FacesMessage("Please set cover image!");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return "";
		}
		return "product-step2";
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Price getPrice() {
		return price;
	}

	public void setPrice(Price price) {
		this.price = price;
	}

	public Set<State> getSelectedState() {
		return selectedState;
	}

	public void setSelectedState(Set<State> selectedState) {
		this.selectedState = selectedState;
	}

	public Set<Country> getSelectedCountry() {
		return selectedCountry;
	}

	public void setSelectedCountry(Set<Country> selectedCountry) {
		this.selectedCountry = selectedCountry;
	}

	public Part getFile() {
		return file;
	}

	public void setFile(Part file) {
		this.file = file;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getImageFilePath() {
		return imageFilePath;
	}

	public void setImageFilePath(String imageFilePath) {
		this.imageFilePath = imageFilePath;
	}

	public CategorySelectBean getCategoryBean() {
		return categoryBean;
	}

	public void setCategoryBean(CategorySelectBean categoryBean) {
		this.categoryBean = categoryBean;
	}

	public List<State> getStateList() {
		return stateList;
	}

	public void setStateList(List<State> stateList) {
		this.stateList = stateList;
	}
}
