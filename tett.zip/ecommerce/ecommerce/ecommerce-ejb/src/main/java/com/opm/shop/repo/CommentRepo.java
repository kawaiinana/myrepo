package com.opm.shop.repo;

import com.opm.shop.entity.Comment;

public class CommentRepo extends AbstractRepository<Comment>{

	public CommentRepo() {
		super(Comment.class);
		
	}
}
