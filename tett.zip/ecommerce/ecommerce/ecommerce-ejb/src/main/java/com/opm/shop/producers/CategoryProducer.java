package com.opm.shop.producers;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Category;
import com.opm.shop.service.CategoryServiceLocal;

@ApplicationScoped
public class CategoryProducer {

	@Named
	@Produces
	private List<Category> categories;

	@Named
	@Produces
	private List<Category> allCategories;

	@Inject
	private CategoryServiceLocal service;

	@PostConstruct
	private void init() {
		load(null);
	}

	public List<Category> getAllCategories() {
		return allCategories;
	}
	
	public List<Category> getCategories() {
		return categories;
	}
	
	private void load(@Observes Category data) {
		categories = service.findParents();
		allCategories = service.findAll();
	}
}
