package com.opm.shop.service;

import java.util.List;

import javax.ejb.Local;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Notification;

@Local
public interface NotificationServiceLocal {

	void save(Notification noti);

	List<Notification> findByNewStatus(long notiCreator);

	void update(Notification comment);

	List<Notification> findByOldStatus(long notiCreator);

	Account findAdmin();

}
