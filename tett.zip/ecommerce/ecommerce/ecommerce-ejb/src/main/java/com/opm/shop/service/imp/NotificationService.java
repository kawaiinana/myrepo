package com.opm.shop.service.imp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Notification.Status;
import com.opm.shop.repo.AccountRepo;
import com.opm.shop.repo.NotificationRepo;
import com.opm.shop.service.NotificationServiceLocal;

@Stateless
public class NotificationService implements NotificationServiceLocal {

	@Inject
	private NotificationRepo repo;
	
	@Inject
	private AccountRepo accountRepo;

	@Override
	public void save(Notification noti) {
		repo.persit(noti);
	}
	
	@Override
	public void update(Notification noti) {
		repo.update(noti);
	}

	@Override
	public List<Notification> findByNewStatus(long notiCreator) {
		Map<String, Object> params = new HashMap<>();
		params.put("status", Status.New);
		params.put("notiCreator", notiCreator);
		return repo.find("t.status = :status and t.notiReceiver.id = :notiCreator ", params);
	}

	@Override
	public List<Notification> findByOldStatus(long notiCreator) {
		Map<String, Object> params = new HashMap<>();
		params.put("status", Status.Read);
		params.put("notiCreator", notiCreator);
		return repo.find("t.status = :status and t.notiReceiver.id = :notiCreator ", params);
	}

	@Override
	public Account findAdmin() {
		Map<String, Object> params = new HashMap<>();
		params.put("role", "Admin");		
		List<Account> admins = accountRepo.find("t.roles = :role ", params);
		
		return admins.get(0);
	}

}
