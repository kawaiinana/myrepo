package com.opm.shop.converters;

import java.util.Date;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Named;

import com.opm.shop.entity.Price;

@Named
@RequestScoped
public class PriceConverter implements Converter{
	
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		
		if(null != value && (value instanceof Set)) {
			@SuppressWarnings("unchecked")
			Set<Price> set = (Set<Price>) value;
			return set.stream().filter(p -> p.getRefDate().compareTo(new Date()) <= 0)
				.sorted((a,b) -> b.getRefDate().compareTo(a.getRefDate()))
				.findFirst()
				.map(p -> String.valueOf(p.getPrice()))
				.orElse(null);
		}

		return null;
	}

}
