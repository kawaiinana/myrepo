package com.opm.shop.converters;

import javax.enterprise.context.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.City;
import com.opm.shop.service.CityServiceLocal;


@Named
@RequestScoped
public class CityConverter implements Converter{

	@Inject
	private CityServiceLocal service;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		
		if(!value.equals("-- Select City --")){
			City city = service.findByName(value);
			return city;
		}
		return null;
		
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		// TODO Auto-generated method stub
				if(null != value){
					City c = (City) value;
					return c.getName();
				}
				return null;
			}

}


