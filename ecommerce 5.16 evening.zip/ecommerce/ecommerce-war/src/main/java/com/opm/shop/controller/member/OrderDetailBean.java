package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.OrderServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class OrderDetailBean implements Serializable {

	private Order order;

	@Named
	@Inject
	private Account loginUser;

	private Notification noti;
	
	@Inject
	private OrderServiceLocal service ;
	
	@Inject
	private Event<Notification> notiEvent;
	
	@PostConstruct
	public void init() {

		order = new Order();
		noti = new Notification();

		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");

		if(null != str){
			order = service.findById(Long.parseLong(str));			
		}	
	}
	
	public String allowDelivery() {
		
		order.setStatus(Status.Allow_Delivery);
		order.getSecurity().setModUser(loginUser.getId());
		service.save(order);
		
		noti.setNotiReceiver(order.getItem().getOwner());
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
		noti.setNotiURL("/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
		noti.setNotiString("Cash was received.Please send the item.");
		notiEvent.fire(noti);

		return "/admin/orderhistory.xhtml?faces-redirect=true";
	}
	
	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Notification getNoti() {
		return noti;
	}

	public void setNoti(Notification noti) {
		this.noti = noti;
	}

}