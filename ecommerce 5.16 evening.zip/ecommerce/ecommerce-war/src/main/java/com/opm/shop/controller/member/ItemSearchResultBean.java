package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.service.ItemServiceLocal;

@Named
@RequestScoped
@SuppressWarnings("serial")
public class ItemSearchResultBean implements Serializable {

	private List<Item> items;
	private int categoryId;
	private String keyword;
	private String catId;


	private Member member;

	
	@Inject
	private ItemServiceLocal service;

	@PostConstruct
	public void init() {
		keyword = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("keyword");
		catId =  FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		
		if (keyword == null)
			keyword = "";
			
		if(catId == null)
			catId = "";
		else categoryId = Integer.parseInt(catId);		
		items = service.find(categoryId, keyword);


	}

	public String search() {
		return "/product-search-result.xhtml?faces-redirect=true&keyword="+keyword+"&id="+categoryId;
	}
	
	public String searchBycategoryId(int id){
		
		items = service.find(id, keyword);
		return "";
	}
	
	public String serchByMember(){	
		
		items=service.findByMemberId(member.getId());
		return "/member/product-listing.xhtml?faces-redirect=true";
	}
	
	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

}