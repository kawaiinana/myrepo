package com.opm.shop.converters;

import javax.enterprise.context.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Brand;
import com.opm.shop.service.BrandServiceLocal;

@Named
@RequestScoped
public class BrandConverter implements Converter{

	@Inject
	private BrandServiceLocal service;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		if(null != value && !value.isEmpty()){
			Brand b = service.findByName(value);
			return b;
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if(null != value){
			Brand b = (Brand) value;
			return b.getName();
		}
		return null;
	}
}
