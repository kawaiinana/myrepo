package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Observes;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Notification.Status;
import com.opm.shop.service.NotificationServiceLocal;

@SuppressWarnings("serial")
@ViewScoped
@Named
public class NotificationBean implements Serializable {

	@Inject
	@Named
	private Account loginUser;
	
	private Notification noti;
	private List<Notification> newNotis;
	private List<Notification> oldNotis;

	@Inject
	private NotificationServiceLocal service;

	private long countNoti;

	@PostConstruct
	private void init() {
		newNotis = service.findByNewStatus(loginUser.getId());
		oldNotis = service.findByOldStatus(loginUser.getId());
		countNoti = newNotis.stream().count();
	}

	public void newNoti(@Observes Notification noti) {
		service.save(noti);
		newNotis = service.findByNewStatus(loginUser.getId());
	}

	public void oldComment(Notification noti) {

		noti.setStatus(Status.Read);
		service.update(noti);
		oldNotis = service.findByOldStatus(loginUser.getId());

	}

	public Notification getNoti() {
		return noti;
	}

	public void setNoti(Notification noti) {
		this.noti = noti;
	}

	public List<Notification> getNewNotis() {
		return newNotis;
	}

	public void setNewNotis(List<Notification> newNotis) {
		this.newNotis = newNotis;
	}

	public List<Notification> getOldNotis() {
		return oldNotis;
	}

	public void setOldNotis(List<Notification> oldNotis) {
		this.oldNotis = oldNotis;
	}

	public long getCountNoti() {
		return countNoti;
	}

	public void setCountNoti(long countNoti) {
		this.countNoti = countNoti;
	}

}