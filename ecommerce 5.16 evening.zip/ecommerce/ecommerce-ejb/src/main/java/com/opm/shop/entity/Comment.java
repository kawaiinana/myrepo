package com.opm.shop.entity;

import static javax.persistence.GenerationType.IDENTITY;
import static javax.persistence.TemporalType.TIMESTAMP;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;

@SuppressWarnings("serial")
@Entity
public class Comment implements Serializable {

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	@Lob
	private String comment;

	@Temporal(TIMESTAMP)
	private Date creation;

	@ManyToOne
	private Order order;
	
	@ManyToOne
	private Member owner;

	@ManyToOne
	private Item item;
	
	@PrePersist
	private void prePersist() {
		creation = new Date();
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Date getCreation() {
		return creation;
	}

	public void setCreation(Date creation) {
		this.creation = creation;
	}

	public Member getOwner() {
		return owner;
	}

	public void setOwner(Member owner) {
		this.owner = owner;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}
}
