package com.opm.shop.service.imp;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Category;
import com.opm.shop.entity.Item;
import com.opm.shop.repo.CategoryRepo;
import com.opm.shop.repo.ItemRepo;
import com.opm.shop.service.ItemServiceLocal;

@Stateless
public class ItemService implements ItemServiceLocal {

	@Inject
	private ItemRepo repo;
	
	@Inject
	private CategoryRepo crepo;
	
	public void save(Item item) {
		repo.persit(item);
	}

	public void update(Item item) {
		repo.update(item);
	}

	@Override
	public Item findById(long id) {
		return repo.findById(id);
	}
	
	@Override
	public List<Item> find(int categoryId, String keyword) {
		StringBuffer stb = new StringBuffer("1=1 ");
		Map<String,Object> params = new HashMap<>();
		
		if( categoryId > 0){
			
			Category category = crepo.findById(categoryId);			
			
			if(category != null){

				stb.append("and t.category.id in :idList ");
				
				List<Integer> idList = new ArrayList<>();
				idList.add(category.getId());
				
				if(category.getChildren() != null) {
					for(Category second : category.getChildren()) {
						idList.add(second.getId());
						
						if(second.getChildren() != null) {
							
							for(Category third : second.getChildren()) {
								idList.add(third.getId());
							}
						}
					}
				}
				
				params.put("idList", idList);
			}
			
			
		}
		
		if ( null!= keyword && !keyword.isEmpty()) {
			stb.append("and upper(t.name) like upper(:keyword)");
			params.put("keyword",keyword.concat("%"));
		}
		
		return repo.find(params.size() == 0? null: stb.toString(),params.size() == 0? null: params);
		
	}

	@Override
	public List<Item> findByMemberId(long id) {
		
		String where="t.owner.id= :id ";
		Map<String, Object> params= new HashMap<>();
		params.put("id", id);
		return repo.find(where, params);
	}

}