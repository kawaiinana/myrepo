package com.opm.shop.service.imp; 

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Comment;
import com.opm.shop.repo.CommentRepo;
import com.opm.shop.service.CommentServiceLocal;

@Stateless
public class CommentService implements CommentServiceLocal{
	
	@Inject
	private CommentRepo repo;

	@Override
	public void save(Comment comment) {
		if(comment.getId() == 0) {
			repo.persit(comment);
		} else {
			repo.update(comment);
		}
		
	}

	@Override
	public Comment findById(int id) {
		
		return repo.findById(id);
	}

	@Override
	public List<Comment> findByOrderId(long id) {
		String where = "t.order.id = :id ";
		Map<String, Object> params = new HashMap<>();
		params.put("id", id);
		return repo.find(where, params);
	}

	@Override
	public void update(Comment comment) {
		repo.update(comment);
	}

	@Override
	public void delete(long comment) {
		repo.delete(repo.findById(comment));
	}

}
