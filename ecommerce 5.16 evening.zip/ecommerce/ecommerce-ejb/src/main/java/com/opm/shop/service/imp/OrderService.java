package com.opm.shop.service.imp;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.repo.OrderRepo;
import com.opm.shop.service.OrderServiceLocal;

@Stateless
public class OrderService implements OrderServiceLocal {

	@Inject
	private OrderRepo repo;

	public void save(Order order) {
		if (order.getId() == 0) {
			repo.persit(order);
		} else {
			repo.update(order);
		}
	}

	@Override
	public void update(Order order) {
		repo.update(order);
	}

	@Override
	public Order findById(long id) {
		return repo.findById(id);
	}

	@Override
	public List<Order> getAll() {
		return repo.find(null, null);
	}

	@Override
	public List<Order> findByStatus(Status status, Date df, Date dt,long buyerId,long sellerId) {

		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		if (null != status) {
			sb.append("t.status= :status ");
			params.put("status", status);
		}

		if (null != df) {
			if (!params.isEmpty()) {
				sb.append("and ");
			}
			sb.append("t.orderDate >= :dateFrom ");
			params.put("dateFrom", df);
		}

		if (null != dt) {
			if (!params.isEmpty()) {
				sb.append("and ");
			}
			sb.append("t.orderDate <= :dateTo ");
			params.put("dateTo", dt);
		}
		if (0 != buyerId) {
			if (!params.isEmpty()) {
				sb.append("and ");
			}
			sb.append("t.buyer.id = :buyerId ");
			params.put("buyerId", buyerId);
		}
		if (0 != sellerId) {
			if (!params.isEmpty()) {
				sb.append("and ");
			}
			sb.append("t.item.owner.id = :sellerId ");
			params.put("sellerId", sellerId);
		}
		return repo.find(params.size() == 0 ? null : sb.toString(), params.size() == 0 ? null : params);	
	}	
}