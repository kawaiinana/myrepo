package com.opm.hms.controller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.MasterData;
import com.opm.hms.entity.User;
import com.opm.hms.service.MasterDataService;
import com.opm.hms.utils.producer.MasterDataProducer;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class MasterDataBean implements Serializable {

	private String title;

	private MasterData data;

	private List<MasterData> list;

	@Inject
	private Event<MasterData> event;

	@Inject
	private MasterDataService service;
	
	@Inject
	@Named
	private User loginUser;
	
	@Inject
	private MasterDataProducer master;
	
	private List<String> types;
	
	private boolean showPopup;
	
	@PostConstruct
	public void init() {
		types = new ArrayList<>();
		types.addAll(master.getMasterTypes("Customer"));
		search();
	}

	public void addNew() {
		title = "Add New Master Data";
		this.data = new MasterData();
		types.clear();
		types.addAll(master.getMasterTypes("Customer"));
		this.data.getSecurity().setCreateUser(loginUser.getLogin());
		this.data.getSecurity().setModUser(loginUser.getLogin());
		showPopup = true;
	}

	public void edit(MasterData masterData) {
		title = "Edit Master Data";
		this.data = masterData;
		types.clear();
		types.addAll(master.getMasterTypes("Customer"));
		this.data.getSecurity().setModUser(loginUser.getLogin());
		showPopup = true;
	}
	
	public void changeCategory() {
		types.clear();
		types.addAll(master.getMasterTypes(data.getCategory()));
	}

	public String save() {
		service.save(data);
		event.fire(data);
		return "/admin/masterdata?faces-redirect=true";
	}

	public List<String> getTypes() {
		return types;
	}

	public void setTypes(List<String> types) {
		this.types = types;
	}

	public void search() {
		list = service.search();
	}

	public MasterData getData() {
		return data;
	}

	public void setData(MasterData data) {
		this.data = data;
	}

	public List<MasterData> getList() {
		return list;
	}

	public void setList(List<MasterData> list) {
		this.list = list;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public boolean isShowPopup() {
		return showPopup;
	}

	public void setShowPopup(boolean showPopup) {
		this.showPopup = showPopup;
	}

}