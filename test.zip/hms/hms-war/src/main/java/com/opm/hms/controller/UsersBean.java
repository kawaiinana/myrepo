package com.opm.hms.controller;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.User;
import com.opm.hms.service.UserService;
import com.opm.hms.service.search.Impl.UserSearch;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class UsersBean implements Serializable {

	private User data;

	private String title;

	private List<User> list;

	@Inject
	private UserService service;

	@Inject
	private UserSearch search;

	@Inject
	@Named
	private User loginUser;

	private boolean showPopup;

	@PostConstruct
	public void init() {
		data = new User();
		search();
	}

	public void addNew() {
		title = "Add New User";
		this.data = new User();
		this.data.getSecurity().setCreateUser(loginUser.getLogin());
		this.data.getSecurity().setModUser(loginUser.getLogin());
		showPopup = true;
	}

	public String save() {
		this.data.getSecurity().setModUser(loginUser.getLogin());
		service.save(data);
		return "/admin/users?faces-redirect=true";
	}
	
	public void edit(User user) {
		title = "Edit User";
		this.data = user;
		showPopup = true;
	}

	public void search() {
		list = service.search(search);
	}

	public User getData() {
		return data;
	}

	public void setData(User data) {
		this.data = data;
	}

	public List<User> getList() {
		return list;
	}

	public void setList(List<User> list) {
		this.list = list;
	}

	public UserSearch getSearch() {
		return search;
	}

	public void setSearch(UserSearch search) {
		this.search = search;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public boolean isShowPopup() {
		return showPopup;
	}

	public void setShowPopup(boolean showPopup) {
		this.showPopup = showPopup;
	}

}