package com.opm.hms.controller;

import java.io.Serializable;
import java.time.LocalDate;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Customer;
import com.opm.hms.entity.CustomerReservation;
import com.opm.hms.entity.LaundryService;
import com.opm.hms.entity.Reservation;
import com.opm.hms.entity.RestaurantService;
import com.opm.hms.entity.Room;
import com.opm.hms.entity.RoomReservation;
import com.opm.hms.service.ReservationService;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class ReservationBean implements Serializable{

	@Inject
	private ReservationService service;

	private Reservation data;
	
	private RestaurantService restaurant;
	private Room restaurantCallRoom;
	private LocalDate restaurantCallDate;
	
	private LaundryService laundry;
	private Room laundryCallRoom;
	private LocalDate laundryCallDate;
	
	private CustomerReservation customer;
	
	private boolean showPopup;
	@Inject
	private CustomerSearchBean oldCustomerSearch;
	
	@PostConstruct
	public void init() {
		
		restaurant = new RestaurantService();
		laundry = new LaundryService();
		customer = new CustomerReservation();
		customer.setCustomer(new Customer());
		
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		
		if(null != str && !str.isEmpty()) {
			long id = Long.parseLong(str);
			data = service.findById(id);
		} else {
			data = new Reservation();
		}
	}

	public void searchOldCustomer() {
		oldCustomerSearch.clearSearch();
		showPopup = true;
	}
	
	public void selectCustomer() {
		oldCustomerSearch.getSelectedCustomers().forEach(a -> {
			CustomerReservation cr = new CustomerReservation();
			cr.setCustomer(a);
			
			if(data.getCustomers().size() == 0) {
				cr.setReservedCustomer(true);
			}
			
			data.addCustomer(cr);
		});
		
		showPopup = false;
	}
	
	public String save() {
		service.save(data);
		return "/front/reservation-list";
	}
	
	public void addCustomer() {
		
		customer.setReservation(this.data);
		this.data.addCustomer(customer);
		
		customer = new CustomerReservation();
		customer.setCustomer(new Customer());
	}
	
	public void removeCustomer(CustomerReservation cust) {
		this.data.getCustomers().remove(cust);
	}
	
	public void addRestaurantService() {
		
		RoomReservation roomReservation = data.getRoomReservation(restaurantCallRoom, restaurantCallDate);
		
		restaurant.setReservation(roomReservation);
		roomReservation.addRestaurant(restaurant);
		
		restaurant = new RestaurantService();
		this.data.calculate();
		
	}
	
	public void removeRestaurant(RestaurantService s) {
		s.getReservation().getRestaurants().remove(s);
		this.data.calculate();
	}
	
	public void addLaundryService() {

		RoomReservation roomReservation = data.getRoomReservation(laundryCallRoom, laundryCallDate);
		laundry.setReservation(roomReservation);
		roomReservation.addLaundry(laundry);
		
		laundry = new LaundryService();
		
		this.data.calculate();
	}
	
	public void removeLaundry(LaundryService l) {
		l.getReservation().getLaundries().remove(l);
		this.data.calculate();
	}
	
	public void setPrice() {
		laundry.calculate();
	}
	
	public void setRoomCharge() {
		
	}

	public ReservationService getService() {
		return service;
	}

	public void setService(ReservationService service) {
		this.service = service;
	}

	public Reservation getData() {
		return data;
	}

	public void setData(Reservation data) {
		this.data = data;
	}

	public RestaurantService getRestaurant() {
		return restaurant;
	}

	public void setRestaurant(RestaurantService restaurant) {
		this.restaurant = restaurant;
	}

	public Room getRestaurantCallRoom() {
		return restaurantCallRoom;
	}

	public void setRestaurantCallRoom(Room restaurantCallRoom) {
		this.restaurantCallRoom = restaurantCallRoom;
	}

	public LocalDate getRestaurantCallDate() {
		return restaurantCallDate;
	}

	public void setRestaurantCallDate(LocalDate restaurantCallDate) {
		this.restaurantCallDate = restaurantCallDate;
	}

	public LaundryService getLaundry() {
		return laundry;
	}

	public void setLaundry(LaundryService laundry) {
		this.laundry = laundry;
	}

	public Room getLaundryCallRoom() {
		return laundryCallRoom;
	}

	public void setLaundryCallRoom(Room laundryCallRoom) {
		this.laundryCallRoom = laundryCallRoom;
	}

	public LocalDate getLaundryCallDate() {
		return laundryCallDate;
	}

	public void setLaundryCallDate(LocalDate laundryCallDate) {
		this.laundryCallDate = laundryCallDate;
	}

	public CustomerReservation getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerReservation customer) {
		this.customer = customer;
	}

	public boolean isShowPopup() {
		return showPopup;
	}

	public void setShowPopup(boolean showPopup) {
		this.showPopup = showPopup;
	}

	public CustomerSearchBean getOldCustomerSearch() {
		return oldCustomerSearch;
	}

	public void setOldCustomerSearch(CustomerSearchBean oldCustomerSearch) {
		this.oldCustomerSearch = oldCustomerSearch;
	}

}