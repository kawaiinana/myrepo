package com.opm.hms.utils;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Page implements Serializable{
	
	private int pageNumber;
	private String pageName;
	private boolean current;

	public Page(int pageNumber, String pageName, boolean current) {
		super();
		this.pageNumber = pageNumber;
		this.pageName = pageName;
		this.current = current;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public boolean isCurrent() {
		return current;
	}

	public void setCurrent(boolean current) {
		this.current = current;
	}
}
