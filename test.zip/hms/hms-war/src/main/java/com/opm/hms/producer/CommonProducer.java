package com.opm.hms.producer;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.MasterData;
import com.opm.hms.entity.RestaurantService.Type;
import com.opm.hms.entity.Customer.Gender;
import com.opm.hms.utils.producer.MasterDataProducer;

@ApplicationScoped
public class CommonProducer {

	@Inject
	private MasterDataProducer masterData;
	
	@Named
	@Produces
	public Gender[] getGenders() {
		return Gender.values();
	}
	
	@Named
	@Produces
	public Type[] getRestaurantTypes() {
		return Type.values();
	}

    @Named
    @Produces
    public List<MasterData> getCustomerNationalities() {
    	return masterData.get("Customer", "Nationality");
    }

    @Named
    @Produces
    public List<MasterData> getReservationStatuses() {
    	return masterData.get("Reservation", "Status");
    }
    
    @Named
    @Produces
    public List<MasterData> getLaundryTypes() {
    	return masterData.get("Laundry", "Type");
    }
}
