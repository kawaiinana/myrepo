package com.opm.hms.converter;

import java.util.List;

import javax.enterprise.inject.Model;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Site;

@Model
public class SiteConverter implements Converter {

	@Named
	@Inject
	private List<Site> sites;

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		
		try {
			if(null != value && !value.isEmpty()) {
				long id = Long.valueOf(value);
				
				for (Site site : sites) {
					if(site.getId() == id) {
						return site;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		
		if(null != value) {
			Site site = (Site) value;
			return String.valueOf(site.getId());
		}
		
		return null;
	}

}
