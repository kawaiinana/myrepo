package com.opm.hms.entity;

import javax.persistence.Entity;

@Entity
public class RestaurantService extends HotelService {

	private static final long serialVersionUID = 1L;
	private Type type;

	public enum Type {
		Lunch, Dinner
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

}