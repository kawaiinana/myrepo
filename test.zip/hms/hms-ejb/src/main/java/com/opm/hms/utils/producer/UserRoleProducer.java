package com.opm.hms.utils.producer;

import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;

import com.opm.hms.entity.User;

@ApplicationScoped
public class UserRoleProducer {

	@Named
	@Produces
	private List<String> userRoles;
	
	private User user;
	
	@PostConstruct
	public void init() {
		userRoles = Arrays.asList(user.getRole().name());
	}
}
