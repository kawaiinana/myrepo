package com.opm.hms.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.Customer;
import com.opm.hms.entity.CustomerPoint;
import com.opm.hms.entity.CustomerReservation;
import com.opm.hms.entity.LaundryService;
import com.opm.hms.entity.Reservation;
import com.opm.hms.entity.RestaurantService;
import com.opm.hms.repo.CustomerRepo;
import com.opm.hms.repo.CustomerReservationRepo;
import com.opm.hms.repo.LaundryServiceRepo;
import com.opm.hms.repo.ReservationRepo;
import com.opm.hms.repo.RestaurantServiceRepo;
import com.opm.hms.service.search.Searchable;
import com.opm.hms.service.search.Impl.CustomerLaundrySearch;
import com.opm.hms.service.search.Impl.CustomerReservationSearch;
import com.opm.hms.service.search.Impl.CustomerRestaurantSearch;

@LocalBean
@Stateless
public class ReservationService {

	@Inject
	private ReservationRepo reservRepo;

	@Inject
	private RestaurantServiceRepo restRepo;

	@Inject
	private LaundryServiceRepo laundRepo;

	@Inject
	private CustomerReservationRepo custReservRepo;

	@Inject
	private CustomerRepo custRepo;

	@Resource
	private SessionContext ctx;

	public void save(Reservation data) {
		// old customer
		data.getCustomers().forEach(a -> {
			if (a.getCustomer().getId() > 0) {
				a.setCustomer(custRepo.find(a.getCustomer().getId()));
			}
		});

		// reservation
		reservRepo.save(data);

		data.getSecurity().setModUser(ctx.getCallerPrincipal().getName());

		// point calculation
		if (data.getSite().isCashBack() && !data.isGivePoint()) {
			int statyCount = data.getRooms().size();
			Customer cust = data.getCustomer();

			CustomerPoint point = new CustomerPoint();
			point.setAdd(true);
			point.setPoint(statyCount);
			point.getSercurity().setCreateUser(ctx.getCallerPrincipal().getName());
			point.getSercurity().setModUser(ctx.getCallerPrincipal().getName());

			cust.getValidPoint().ifPresent(p -> {
				p.getSercurity().setDelFlag(true);
				p.getSercurity().setModUser(ctx.getCallerPrincipal().getName());
				point.setLastTotal(p.getTotalPoint());
			});

			point.setRemark(String.format("Add point by Reservation ID is %d", data.getId()));
			point.calculate();
			data.setGivePoint(true);

			cust.addPoint(point);
		}

		if (data.getSite().isCashBack() && data.isGivePoint() && data.getStatus().equals("Cancel")) {
			int statyCount = data.getRooms().size();
			Customer cust = data.getCustomer();

			CustomerPoint point = new CustomerPoint();

			cust.getValidPoint().ifPresent(p -> {
				p.getSercurity().setDelFlag(true);
				p.getSercurity().setModUser(ctx.getCallerPrincipal().getName());

				point.setAdd(false);
				point.setPoint(statyCount);
				point.setLastTotal(p.getTotalPoint());
				point.calculate();

				point.setRemark(String.format("Delete point because of Cancel reservation. Reservation ID is %d",
						data.getId()));
				point.getSercurity().setCreateUser(ctx.getCallerPrincipal().getName());
				point.getSercurity().setModUser(ctx.getCallerPrincipal().getName());

				cust.addPoint(point);
			});

		}
	}

	public List<Reservation> search(Searchable search) {
		return reservRepo.find(search);
	}

	public List<Reservation> getStayHistory(Customer cust) {
		List<CustomerReservation> list = custReservRepo.find(new CustomerReservationSearch(cust));
		return list.stream().map(a -> a.getReservation()).collect(Collectors.toList());
	}

	public List<RestaurantService> findCustomerRestaurantHistory(Customer cust) {
		return restRepo.find(new CustomerRestaurantSearch(cust));
	}

	public List<LaundryService> findCustomerLaundryHistory(Customer cust) {
		return laundRepo.find(new CustomerLaundrySearch(cust));
	}

	public long searchCount(Searchable search) {
		return reservRepo.findCount(search);
	}

	public Reservation findById(long id) {
		Reservation res = reservRepo.find(id);
		res.calculate();
		return res;
	}

}