package com.opm.hms.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;

import com.opm.hms.repo.LongIdEntity;
import javax.persistence.OneToMany;
import static javax.persistence.CascadeType.PERSIST;
import static javax.persistence.CascadeType.MERGE;

@Entity
public class Customer implements LongIdEntity, Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	private String firstName;

	private String lastName;

	private String passport;

	private LocalDate dob;

	private String nationality;

	private String email;

	private String phone;

	private Gender gender;

	private Security security;

	// point
	@OneToMany(mappedBy = "customer", cascade = { PERSIST, MERGE }, orphanRemoval = true)
	private List<CustomerPoint> points;
	
	// stay history
	@OneToMany(mappedBy = "customer", orphanRemoval = true)
	private List<CustomerReservation> reservations;
	
	public Customer() {
		security = new Security();
		points = new ArrayList<>();
		reservations = new ArrayList<>();
	}

	@PrePersist
	public void prePersist() {
		security.setCreation(LocalDateTime.now());
		security.setModification(LocalDateTime.now());
	}
	
	public String getName() {
		return String.format("%s %s", firstName, lastName);
	}

	public long getId() {
		return id;
	}

	public enum Gender {
		Male, Female
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPassport() {
		return passport;
	}

	public void setPassport(String passport) {
		this.passport = passport;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public Security getSecurity() {
		return security;
	}

	public void setSecurity(Security security) {
		this.security = security;
	}

	public void setId(long id) {
		this.id = id;
	}

	public List<CustomerPoint> getPoints() {
		return points;
	}

	public void setPoints(List<CustomerPoint> points) {
		this.points = points;
	}

	public List<CustomerReservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<CustomerReservation> reservations) {
		this.reservations = reservations;
	}

	public int currentPoint() {
		return points.stream()
				.filter(a -> !a.getSercurity().isDelFlag())
				.sorted((a,b) -> (int)(a.getId() - b.getId()))
				.findFirst()
				.map(a -> a.getTotalPoint()).orElse(0);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((nationality == null) ? 0 : nationality.hashCode());
		result = prime * result + ((passport == null) ? 0 : passport.hashCode());
		result = prime * result + ((phone == null) ? 0 : phone.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (gender != other.gender)
			return false;
		if (id != other.id)
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (nationality == null) {
			if (other.nationality != null)
				return false;
		} else if (!nationality.equals(other.nationality))
			return false;
		if (passport == null) {
			if (other.passport != null)
				return false;
		} else if (!passport.equals(other.passport))
			return false;
		if (phone == null) {
			if (other.phone != null)
				return false;
		} else if (!phone.equals(other.phone))
			return false;
		return true;
	}

	public int stayCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public LocalDate lastStayDate() {
		// TODO Auto-generated method stub
		return null;
	}

	public Optional<CustomerPoint> getValidPoint() {
		return points.stream().filter(a -> !a.getSercurity().isDelFlag()).findAny();
	}

	public void addPoint(CustomerPoint customerPoint) {
		customerPoint.setCustomer(this);
		points.add(customerPoint);
	}

}