package com.opm.hms.repo;

import com.opm.hms.entity.Reservation;

public class ReservationRepo extends AbstractRepository<Reservation> {

    public ReservationRepo() {
    	super(Reservation.class);
    }

}