package com.opm.hms.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.opm.hms.repo.LongIdEntity;
import com.opm.hms.utils.HmsApplicationException;

import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

@Entity
public class CustomerPoint implements LongIdEntity, Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	private LocalDate stayDate;

	private String roomNumber;

	private int point;
	private int lastTotal;
	private int totalPoint;
	private boolean add;
	private Security sercurity;
	private String remark;
	
	@ManyToOne
	private Customer customer;

	public CustomerPoint() {
		sercurity = new Security();
	}
	
	@PrePersist
	private void prePersist() {
		sercurity.setCreation(LocalDateTime.now());
		sercurity.setModification(LocalDateTime.now());
	}
	
	@PreUpdate
	private void preUpdate() {
		sercurity.setModification(LocalDateTime.now());
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public int getLastTotal() {
		return lastTotal;
	}

	public void setLastTotal(int lastTotal) {
		this.lastTotal = lastTotal;
	}

	public boolean isAdd() {
		return add;
	}

	public void setAdd(boolean add) {
		this.add = add;
	}

	public Security getSercurity() {
		return sercurity;
	}

	public void setSercurity(Security sercurity) {
		this.sercurity = sercurity;
	}

	public long getId() {
		return id;
	}

	public LocalDate getStayDate() {
		return stayDate;
	}

	public void setStayDate(LocalDate stayDate) {
		this.stayDate = stayDate;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public int getTotalPoint() {
		return totalPoint;
	}

	public void setTotalPoint(int totalPoint) {
		this.totalPoint = totalPoint;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void calculate() {
		totalPoint = add ? lastTotal + point : lastTotal - point;
		
		if(totalPoint < 0) {
			throw new HmsApplicationException(String.format("Customer only have %d but want to use %d", lastTotal, point));
		}
	}
}