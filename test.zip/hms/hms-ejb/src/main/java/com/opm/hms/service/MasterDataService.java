package com.opm.hms.service;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.MasterData;
import com.opm.hms.repo.MasterDataRepo;

@LocalBean
@Stateless
public class MasterDataService {

	@Inject
	private MasterDataRepo repo;

	public void save(MasterData data) {
		repo.save(data);
	}

	public List<MasterData> search() {
		return repo.find(null);
	}

}