package com.opm.hms.utils.producer;

import java.util.List;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.Room;
import com.opm.hms.service.RoomService;

@ApplicationScoped
public class RoomProducer {

	@Named
	@Produces
	private List<Room> rooms;

	@Inject
	private RoomService service;
	
	@PostConstruct
	public void init() {
		load(null);
	}

	public void load(@Observes Room data) {
		rooms = service.search();
	}
	
	public List<Room> findValidRoom() {
		return rooms.stream().filter(a -> !a.getSecurity().isDelFlag()).collect(Collectors.toList());
	}

}