package com.opm.hms.repo;

import com.opm.hms.entity.User;

public class UserRepo extends AbstractRepository<User> {

	public UserRepo() {
		super(User.class);
	}

}