package com.opm.hms.entity;

import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import com.opm.hms.repo.StringIdEntity;
import com.opm.hms.utils.PasswordUtils;
import javax.persistence.Enumerated;
import static javax.persistence.EnumType.STRING;
import javax.persistence.Table;

@Entity
@Table(name = "UserTable")
public class User implements StringIdEntity, Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	private String login;

	private String name;

	private String pass;

	@Enumerated(STRING)
	private Role role;

	private Security security;

	public User() {
		security = new Security();
	}

	@PrePersist
	public void prePersist() {
		try {
			this.setPass(PasswordUtils.encript("password"));
			security.setCreation(LocalDateTime.now());
			security.setModification(LocalDateTime.now());
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}

	@PreUpdate
	public void preUpdate()
	{
		security.setModification(LocalDateTime.now());
	}
	
	public String getId() {
		return login;
	}

	public enum Role {
		Manager, Front, Customer
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public Security getSecurity() {
		return security;
	}

	public void setSecurity(Security security) {
		this.security = security;
	}

}