package com.opm.hms.repo;

import com.opm.hms.entity.RestaurantService;

public class RestaurantServiceRepo extends AbstractRepository<RestaurantService> {

    public RestaurantServiceRepo() {
    	super(RestaurantService.class);
    }

}