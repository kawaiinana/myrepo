package com.opm.hms.repo;

import com.opm.hms.entity.RoomReservation;

public class RoomReservationRepo extends AbstractRepository<RoomReservation> {

    public RoomReservationRepo() {
    	super(RoomReservation.class);
    }

}