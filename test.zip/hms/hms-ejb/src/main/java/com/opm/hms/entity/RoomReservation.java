package com.opm.hms.entity;

import static javax.persistence.CascadeType.MERGE;
import static javax.persistence.CascadeType.PERSIST;
import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Transient;

import com.opm.hms.repo.LongIdEntity;

@Entity
public class RoomReservation implements LongIdEntity, Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	private LocalDate stayDate;

	private double roomCharge;

	@ManyToOne
	private Reservation reservation;

	@ManyToOne
	private Room room;
	
	@Transient
	private List<LaundryService> laundries;
	@Transient
	private List<RestaurantService> restaurants;
	
	@OneToMany(mappedBy = "reservation", orphanRemoval = true, cascade = { PERSIST, MERGE })
	private List<HotelService> allServices;
	
	@PreUpdate
	@PrePersist
	private void prePersist() {
		allServices.clear();
		allServices.addAll(laundries);
		allServices.addAll(restaurants);
	}
	
	@PostLoad
	private void postLoad() {
		laundries.addAll(allServices.stream().filter(a -> a instanceof LaundryService).map(a -> (LaundryService)a).distinct().collect(Collectors.toList()));
		restaurants.addAll(allServices.stream().filter(a -> a instanceof RestaurantService).map(a -> (RestaurantService)a).distinct().collect(Collectors.toList()));
	}
	
	public double getDailyTotal() {
		return roomCharge + allServices.stream().mapToDouble(a -> a.getTotal()).sum();
	}

	public List<HotelService> getAllServices() {
		return allServices;
	}

	public void setAllServices(List<HotelService> allServices) {
		this.allServices = allServices;
	}

	public RoomReservation() {
		laundries = new ArrayList<>();
		restaurants = new ArrayList<>();
		allServices = new ArrayList<>();
	}

	public void addRestaurant(RestaurantService res) {
		res.setReservation(this);
		restaurants.add(res);
		allServices.add(res);
	}

	public void addLaundry(LaundryService lau) {
		lau.setReservation(this);
		laundries.add(lau);
		allServices.add(lau);
	}

	public List<LaundryService> getLaundries() {
		return laundries;
	}

	public void setLaundries(List<LaundryService> laundries) {
		this.laundries = laundries;
		
		for(LaundryService l : laundries) {
			l.setReservation(this);
		}
	}

	public List<RestaurantService> getRestaurants() {
		return restaurants;
	}

	public void setRestaurants(List<RestaurantService> restaurants) {
		this.restaurants = restaurants;
		
		for(RestaurantService r : restaurants) {
			r.setReservation(this);
		}
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDate getStayDate() {
		return stayDate;
	}

	public void setStayDate(LocalDate stayDate) {
		this.stayDate = stayDate;
	}

	public double getRoomCharge() {
		return roomCharge;
	}

	public void setRoomCharge(double roomCharge) {
		this.roomCharge = roomCharge;
	}

	public Reservation getReservation() {
		return reservation;
	}

	public void setReservation(Reservation reservation) {
		this.reservation = reservation;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((room == null) ? 0 : room.hashCode());
		long temp;
		temp = Double.doubleToLongBits(roomCharge);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((stayDate == null) ? 0 : stayDate.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoomReservation other = (RoomReservation) obj;
		if (id != other.id)
			return false;
		if (room == null) {
			if (other.room != null)
				return false;
		} else if (!room.equals(other.room))
			return false;
		if (Double.doubleToLongBits(roomCharge) != Double.doubleToLongBits(other.roomCharge))
			return false;
		if (stayDate == null) {
			if (other.stayDate != null)
				return false;
		} else if (!stayDate.equals(other.stayDate))
			return false;
		return true;
	}

}