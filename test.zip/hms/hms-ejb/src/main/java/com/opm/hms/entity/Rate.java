package com.opm.hms.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.validation.constraints.NotNull;

import com.opm.hms.repo.LongIdEntity;

@Entity
@Cacheable
public class Rate implements LongIdEntity, Serializable {

	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	@NotNull(message = "Yen must not be empty!")
	private double yen;

	@NotNull(message = "Kyat must not be empty!")
	private double kyat;

	private LocalDate refDate;

	private Security security;

	public Rate() {
		security = new Security();
	}

	@PrePersist
	public void prePersist() {
		security.setCreation(LocalDateTime.now());
		security.setModification(LocalDateTime.now());
	}

	@PreUpdate
	public void preUpdate() {
		security.setModification(LocalDateTime.now());
	}

	public long getId() {
		return id;
	}

	public double getYen() {
		return yen;
	}

	public void setYen(double yen) {
		this.yen = yen;
	}

	public double getKyat() {
		return kyat;
	}

	public void setKyat(double kyat) {
		this.kyat = kyat;
	}

	public LocalDate getRefDate() {
		return refDate;
	}

	public void setRefDate(LocalDate refDate) {
		this.refDate = refDate;
	}

	public Security getSecurity() {
		return security;
	}

	public void setSecurity(Security security) {
		this.security = security;
	}

}