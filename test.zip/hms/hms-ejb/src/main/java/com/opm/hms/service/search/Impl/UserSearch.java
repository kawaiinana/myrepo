package com.opm.hms.service.search.Impl;

import java.util.HashMap;
import java.util.Map;

import com.opm.hms.entity.User.Role;
import com.opm.hms.service.search.Searchable;

@SuppressWarnings("serial")
public class UserSearch implements Searchable {

    private Role role;

    private String name;

    public String where() {
    	
    	StringBuffer sb = new StringBuffer();
    	
    	if(null != role){
    		sb.append("and t.role = :role ");
    	}
    	
    	if(null != name){
    		sb.append("and upper(t.name) like upper(:name) ");
    	}
    	
        return sb.toString();
    }

    public Map<String, Object> params() {
        
    	Map<String, Object> params = new HashMap<>();
    	
    	if(null != role){
        	params.put("role", role);
    	}
    	
    	if(null != name){
        	params.put("name", name.concat("%"));
    	}
    	
        return params;
    }

}