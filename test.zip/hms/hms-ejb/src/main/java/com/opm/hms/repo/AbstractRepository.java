package com.opm.hms.repo;

import java.util.List;
import java.util.Map;

import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.opm.hms.service.search.Joinable;
import com.opm.hms.service.search.PageEnable;
import com.opm.hms.service.search.Searchable;
import com.opm.hms.service.search.Sortable;

public abstract class AbstractRepository<T> {

	private Class<T> type;
	
	public static final String SELECT = "select distinct t from %s t ";

	private static final String SELECT_COUNT = "select count(distinct t) from %s t ";
	
	public AbstractRepository(Class<T> type) {
		super();
		this.type = type;
	}

	@Inject
	private EntityManager em;

	protected EntityManager getEntityManager() {
		return em;
	}

	public void save(T t) {
		if(t instanceof LongIdEntity) {
			LongIdEntity entity = (LongIdEntity) t;
			if(entity.getId() > 0) {
				em.merge(entity);
			} else {
				em.persist(t);
			}
		} else if(t instanceof StringIdEntity) {
			StringIdEntity entity = (StringIdEntity) t;
			String id = entity.getId();
			
			if(null != find(id)) {
				em.merge(entity);
			} else {
				em.persist(entity);
			}
		}
	}

	public T find(Object id) {
		return em.find(type, id);
	}
	
	public List<T> find(String queryName, Map<String, Object> params) {
		
		TypedQuery<T> query = em.createNamedQuery(queryName, type);
		
		for(String key : params.keySet()) {
			query.setParameter(key, params.get(key));
		}
		return query.getResultList();
	}

    public List<T> find(Searchable search) {
    	StringBuffer sb = new StringBuffer(String.format(SELECT, type.getSimpleName()));
		if(search != null) {

			if(search instanceof Joinable) {
				Joinable joinable = (Joinable) search;
				sb.append(joinable.join());
			}

			if (search.where() != null && !search.where().isEmpty()) {
				sb.append("where 1 = 1 ");
				sb.append(search.where());
			}

			if(search instanceof Sortable) {
				Sortable sort = (Sortable) search;
				sb.append("order by ").append(sort.orderBy());
			}
			
		}

		TypedQuery<T> q = em.createQuery(sb.toString(), type);

		if(search != null) {
			if (null != search.params()) {
				for (String key : search.params().keySet()) {
					q.setParameter(key, search.params().get(key));
				}
			}
			
			if (search instanceof PageEnable) {
				PageEnable pageEnable = (PageEnable) search;
				
				if (pageEnable.start() > 0) {
					q.setFirstResult(pageEnable.start());
				} 

				if (pageEnable.limit() > 0 ) {
					q.setMaxResults(pageEnable.limit());
				}
			}
			
		}

		return q.getResultList();
	}

    public long findCount(Searchable search) {
    	StringBuffer sb = new StringBuffer(String.format(SELECT_COUNT, type.getSimpleName()));
		if(search != null) {

			if(search instanceof Joinable) {
				Joinable joinable = (Joinable) search;
				sb.append(joinable.join());
			}

			if (search.where() != null && !search.where().isEmpty()) {
				sb.append("where 1 = 1 ");
				sb.append(search.where());
			}
		}

		TypedQuery<Long> q = em.createQuery(sb.toString(), Long.class);

		if(search != null) {
			if (null != search.params()) {
				for (String key : search.params().keySet()) {
					q.setParameter(key, search.params().get(key));
				}
			}
		}

		return q.getSingleResult();
	}
}