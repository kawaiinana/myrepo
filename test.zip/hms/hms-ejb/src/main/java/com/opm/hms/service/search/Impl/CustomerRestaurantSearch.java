package com.opm.hms.service.search.Impl;

import java.util.HashMap;
import java.util.Map;

import com.opm.hms.entity.Customer;
import com.opm.hms.service.search.Joinable;
import com.opm.hms.service.search.Searchable;

@SuppressWarnings("serial")
public class CustomerRestaurantSearch implements Searchable, Joinable {

	private Customer cust;

	public CustomerRestaurantSearch(Customer cust) {
		super();
		this.cust = cust;
	}

	@Override
	public String join() {
		return "join t.reservation.reservation.customers cr ";
	}

	@Override
	public String where() {
		return "and cr.customer.id = :customerId and t.reservation.reservation.status = :status and t.reservation.reservation.security.delFlag = :delFlag ";
	}

	@Override
	public Map<String, Object> params() {
		
		Map<String, Object> params = new HashMap<>();
		
		// customer id
		params.put("customerId", cust.getId());
		
		// valid flag of reservation
		params.put("delFlag", false);
		
		// status of reservation
		params.put("status", "Cancel");
		
		return params;
	}

}
