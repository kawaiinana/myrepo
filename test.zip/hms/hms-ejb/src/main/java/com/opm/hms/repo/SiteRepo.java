package com.opm.hms.repo;

import com.opm.hms.entity.Site;

public class SiteRepo extends AbstractRepository<Site> {

	public SiteRepo() {
		super(Site.class);
	}

}