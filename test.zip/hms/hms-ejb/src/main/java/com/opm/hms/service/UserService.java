package com.opm.hms.service;

import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.User;
import com.opm.hms.repo.UserRepo;
import com.opm.hms.service.search.Searchable;

@LocalBean
@Stateless
public class UserService {

	@Inject
	private UserRepo repo;

	public List<User> search(Searchable search) {
		return repo.find(search);
	}

	public void save(User data) {
		repo.save(data);
	}

	public User search(String loginId) {
		return repo.find(loginId);
	}

}