package com.opm.hms.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.Customer;
import com.opm.hms.entity.LaundryService;
import com.opm.hms.entity.RestaurantService;
import com.opm.hms.entity.RestaurantService.Type;
import com.opm.hms.repo.CustomerRepo;
import com.opm.hms.service.search.Searchable;
import com.opm.hms.service.vo.CustomerListVO;
import com.opm.hms.service.vo.CustomerVO;

@LocalBean
@Stateless
public class CustomerService {

	@Inject
	private CustomerRepo custRepo;

	@Inject
	private ReservationService reservService;

	public void save(CustomerVO data) {
		custRepo.save(data.getCustomer());
	}

	public List<CustomerListVO> search(Searchable search) {
		return custRepo.find(search).stream()
				.map(this::getListViewObject)
				.collect(Collectors.toList());
	}

	public CustomerVO search(long id) {
		return getViewObject(custRepo.find(id));
	}
	
	private CustomerVO getViewObject(Customer cust) {
		CustomerVO result = new CustomerVO();
		// customer
		result.setCustomer(cust);
		// point
		result.setPoint(cust.currentPoint());
		
		// stay count
		result.setStayCount(cust.stayCount());
		
		// stay history
		result.setStayHistory(reservService.getStayHistory(cust));
		
		List<RestaurantService> restaurantHistory = reservService.findCustomerRestaurantHistory(cust);
		List<RestaurantService> lunchHistory = restaurantHistory.stream().filter(a -> a.getType().equals(Type.Lunch))
				.collect(Collectors.toList());
		
		// lunch count
		result.setLunchCount(lunchHistory.size());
		// lunch paid
		result.setLunchPaid(lunchHistory.stream().mapToDouble(a -> a.getTotal()).sum());
		
		List<RestaurantService> dinnerHistory = restaurantHistory.stream().filter(a -> a.getType().equals(Type.Dinner))
				.collect(Collectors.toList());

		// dinner count
		result.setDinnerCount(dinnerHistory.size());
		// dinner paid
		result.setDinnerPaid(dinnerHistory.stream().mapToDouble(a -> a.getTotal()).sum());
		
		// laundry paid
		List<LaundryService> laundryHistory = reservService.findCustomerLaundryHistory(cust);
		result.setLaundaryPaid(laundryHistory.stream().mapToDouble(a -> a.getTotal()).sum());
		
		return result;
	}
	
	private CustomerListVO getListViewObject(Customer customer) {
		CustomerListVO result = new CustomerListVO();
		
		// customer
		result.setCustomer(customer);
		
		// last stay date
		result.setLastStayDate(customer.lastStayDate());
		
		// set point
		result.setPoint(customer.currentPoint());
		
		return result;
	}

	public long searchCount(Searchable search) {
		return custRepo.findCount(search);
	}

}