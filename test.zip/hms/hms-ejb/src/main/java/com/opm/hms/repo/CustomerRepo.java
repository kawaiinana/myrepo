package com.opm.hms.repo;

import com.opm.hms.entity.Customer;

public class CustomerRepo extends AbstractRepository<Customer> {

	public CustomerRepo() {
		super(Customer.class);
	}

}