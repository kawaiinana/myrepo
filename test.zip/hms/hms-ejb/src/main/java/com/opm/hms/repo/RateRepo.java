package com.opm.hms.repo;

import com.opm.hms.entity.Rate;

public class RateRepo extends AbstractRepository<Rate> {

    public RateRepo() {
    	super(Rate.class);
    }

}