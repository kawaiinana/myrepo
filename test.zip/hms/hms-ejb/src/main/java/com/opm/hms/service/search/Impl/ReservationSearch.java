package com.opm.hms.service.search.Impl;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

import com.opm.hms.service.search.Joinable;
import com.opm.hms.service.search.PageEnable;
import com.opm.hms.service.search.Searchable;
import com.opm.hms.service.search.Sortable;

@SuppressWarnings("serial")
public class ReservationSearch implements Searchable, PageEnable, Sortable, Joinable {

	private LocalDate dateFrom;

	private LocalDate dateTo;

	private String roomNumber;

	private String name;

	private String status;

	private int start;
	private int limit;

	public void setStart(int start) {
		this.start = start;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public ReservationSearch() {
	}

	@Override
	public String where() {

		StringBuffer sb = new StringBuffer();

		// dateFrom
		if (null != dateFrom) {
			sb.append("and t.reserveDate >= :dateFrom ");
		}

		// dateTo
		if (null != dateTo) {
			sb.append("and t.reserveDate  <= :dateTo ");
		}

		// roomNumber
		if (null != roomNumber) {
			sb.append("and upper(rr.room.roomNumber) like upper(:roomNumber) ");
		}

		// name
		if (null != name) {
			sb.append("and (upper(cr.customer.firstName) like upper(:name) or upper(cr.customer.lastName) like upper(:name)) ");
		}

		// status
		if (null != status) {
			sb.append("and t.status = :status ");
		}

		return sb.toString();
	}

	@Override
	public Map<String, Object> params() {

		Map<String, Object> params = new HashMap<>();

		// dateFrom
		if (null != dateFrom) {
			params.put("dateFrom", dateFrom);
		}

		// dateFrom
		if (null != dateTo) {
			params.put("dateTo", dateTo);
		}

		// firstName
		if (null != roomNumber) {
			params.put("roomNumber", "%".concat(roomNumber).concat("%"));
		}

		// firstName
		if (null != name) {
			params.put("firstName", "%".concat(name).concat("%"));
		}

		// lastName
		if (null != status) {
			params.put("status", status);
		}

		return params;

	}

	@Override
	public int start() {
		return start;
	}

	@Override
	public int limit() {
		return limit;
	}

	@Override
	public String orderBy() {
		return "t.reserveDate desc ";
	}

	@Override
	public String join() {
		return "join t.customers cr join t.rooms rr ";
	}

	public LocalDate getDateFrom() {
		return dateFrom;
	}

	public void setDateFrom(LocalDate dateFrom) {
		this.dateFrom = dateFrom;
	}

	public LocalDate getDateTo() {
		return dateTo;
	}

	public void setDateTo(LocalDate dateTo) {
		this.dateTo = dateTo;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getStart() {
		return start;
	}

	public int getLimit() {
		return limit;
	}
}