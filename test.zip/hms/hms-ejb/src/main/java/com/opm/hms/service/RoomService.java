package com.opm.hms.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.hms.entity.Room;
import com.opm.hms.entity.RoomReservation;
import com.opm.hms.repo.RoomRepo;
import com.opm.hms.repo.RoomReservationRepo;
import com.opm.hms.service.search.Searchable;
import com.opm.hms.service.vo.RoomStateVO;
import com.opm.hms.utils.producer.RoomProducer;

@LocalBean
@Stateless
public class RoomService {

	@Inject
	private RoomRepo repo;

	@Inject
	private RoomReservationRepo roomReserveRepo;

	@Inject
	private RoomProducer roomsResource;
	
	@Inject
	private RoomRepo roomRepo;

	public void save(Room data) {
		repo.save(data);
	}

	public List<Room> search() {
		return repo.find(null);
	}

	public Room findByRoomNumber(String roomNumber) {

		@SuppressWarnings("serial")
		List<Room> room = repo.find(new Searchable() {

			@Override
			public String where() {
				return "and upper(t.roomNumber) = upper(:roomNumber) ";
			}

			@Override
			public Map<String, Object> params() {
				Map<String, Object> params = new HashMap<>();
				params.put("roomNumber", roomNumber);
				return params;
			}
		});

		if (room.size() > 0)
			return room.get(0);

		return null;
	}
	
	public Map<Room, List<RoomStateVO>> findAvialableRoom(LocalDate checkInDate, LocalDate checkOutDate,
			boolean onlyFree) {

		Map<Room, List<RoomStateVO>> result = new LinkedHashMap<>();
		List<Room> rooms = getRooms(checkInDate, checkOutDate, onlyFree);

		for (Room room : rooms) {
			LocalDate refDate = checkInDate.minusDays(2);
			LocalDate targetDate = checkOutDate.plusDays(2);

			List<RoomStateVO> voList = new ArrayList<>();
			result.put(room, voList);
			
			while (refDate.compareTo(targetDate) <= 0) {
				
				RoomInfoSearch search = new RoomInfoSearch(room, refDate);
				List<RoomReservation> list = roomReserveRepo.find(search);
				
				RoomStateVO vo = new RoomStateVO();
				vo.setRoom(room);
				
				if(!list.isEmpty()) {
					RoomReservation rr = list.get(0);
					vo.setContact(rr.getReservation().getCustomer().getName());
					vo.setStatus(rr.getReservation().getStatus());
					vo.setTotalAmount(rr.getReservation().getTotal());
				}
				voList.add(vo);
				
				refDate = refDate.plusDays(1);
			}
		}

		return result;
	}
	
	public Map<Room, List<RoomStateVO>> findRoomData(LocalDate dateFrom, LocalDate dateTo) {

		Map<Room, List<RoomStateVO>> result = new LinkedHashMap<>();
		List<Room> rooms = getRooms(dateFrom, dateTo, false);

		for (Room room : rooms) {
			LocalDate refDate = dateFrom;

			List<RoomStateVO> voList = new ArrayList<>();
			result.put(room, voList);
			
			while (refDate.compareTo(dateTo) <= 0) {
				
				RoomInfoSearch search = new RoomInfoSearch(room, refDate);
				List<RoomReservation> list = roomReserveRepo.find(search);
				
				RoomStateVO vo = new RoomStateVO();
				vo.setRoom(room);
				
				if(!list.isEmpty()) {
					RoomReservation rr = list.get(0);
					vo.setContact(rr.getReservation().getCustomer().getName());
					vo.setStatus(rr.getReservation().getStatus());
					vo.setTotalAmount(rr.getDailyTotal());
				}
				voList.add(vo);
				
				refDate = refDate.plusDays(1);
			}
		}

		return result;
	}	

	private List<Room> getRooms(LocalDate checkInDate, LocalDate checkOutDate, boolean onlyFree) {
		
		if(!onlyFree) {
			return roomsResource.findValidRoom();
		}
		
		// find only free room
		Map<String, Object> params = new HashMap<>();
		params.put("dateFrom", checkInDate);
		params.put("dateTo", checkOutDate);
		
		return roomRepo.find("Room.getAvialableRoom", params);
	}

	@SuppressWarnings("serial")
	class RoomInfoSearch implements Searchable {

		private Room room;
		private LocalDate refDate;

		public RoomInfoSearch(Room room, LocalDate refDate) {
			super();
			this.room = room;
			this.refDate = refDate;
		}

		@Override
		public String where() {
			return "and t.room.id = :roomId and t.stayDate = :refDate and t.reservation.security.delFlag = false";
		}

		@Override
		public Map<String, Object> params() {
			Map<String, Object> params = new LinkedHashMap<>();
			params.put("roomId", room.getId());
			params.put("refDate", refDate);
			return params;
		}

	}	
}