package com.opm.hms.utils.producer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.hms.entity.MasterData;
import com.opm.hms.service.MasterDataService;

@ApplicationScoped
public class MasterDataProducer {

	@Named
	@Produces
    private List<MasterData> masterDatas;
	
	private Map<String, List<String>> masterCategory; 

    @Inject
    private MasterDataService service;
    
    @PostConstruct
    public void init() {
    	load(null);
    	masterCategory = new LinkedHashMap<>();
    	
    	masterCategory.put("Customer", new ArrayList<>());
    	masterCategory.get("Customer").add("Nationality");
    	masterCategory.put("Reservation", new ArrayList<>());
    	masterCategory.get("Reservation").add("Status");
    	masterCategory.put("Laundry", new ArrayList<>());
    	masterCategory.get("Laundry").add("Type");
    	
    }
    
    @Named
    @Produces
    public List<String> getCategories() {
    	return new ArrayList<>(masterCategory.keySet());
    }
    
    public List<String> getMasterTypes(String key) {
    	return masterCategory.get(key);
    }

    public void load(@Observes MasterData data) {
    	masterDatas = service.search();
    }

    public List<MasterData> get(String category, String type) {
        return masterDatas.stream().filter(a -> a.getCategory().equals(category) && a.getType().equals(type)).collect(Collectors.toList());
    }
    
}