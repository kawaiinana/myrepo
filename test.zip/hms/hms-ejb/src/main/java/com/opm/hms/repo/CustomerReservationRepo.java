package com.opm.hms.repo;

import com.opm.hms.entity.CustomerReservation;

public class CustomerReservationRepo extends AbstractRepository<CustomerReservation> {

	public CustomerReservationRepo() {
		super(CustomerReservation.class);
	}

}