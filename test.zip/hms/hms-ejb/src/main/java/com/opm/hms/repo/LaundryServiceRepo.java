package com.opm.hms.repo;

import com.opm.hms.entity.LaundryService;

public class LaundryServiceRepo extends AbstractRepository<LaundryService> {

	public LaundryServiceRepo() {
		super(LaundryService.class);
	}

}