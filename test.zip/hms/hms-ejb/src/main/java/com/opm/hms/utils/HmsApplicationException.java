package com.opm.hms.utils;

import javax.ejb.ApplicationException;

@ApplicationException(rollback=true)
@SuppressWarnings("serial")
public class HmsApplicationException extends RuntimeException{

	public HmsApplicationException(String message) {
		super(message);
	}

}
