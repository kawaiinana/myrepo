package com.opm.hms.repo;

public interface LongIdEntity {

    public long getId();

}