package com.opm.hms.repo;

/**
 * 
 */
public interface StringIdEntity {

    /**
     * @return
     */
    public String getId();

}