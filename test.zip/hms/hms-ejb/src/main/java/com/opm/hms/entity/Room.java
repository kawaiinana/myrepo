package com.opm.hms.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Transient;

import com.opm.hms.repo.LongIdEntity;
import javax.persistence.ManyToOne;

@Entity
@Cacheable
@NamedQuery(name="Room.getAvialableRoom", query="select r from Room r left join r.reservations rs "
		+ "where r.security.delFlag = false "
		+ "and r.id not in (select rs.room.id from RoomReservation rs where rs.stayDate between :dateFrom and :dateTo)")
public class Room implements LongIdEntity, Serializable {

	private static final long serialVersionUID = 1L;
	@Transient
	private boolean select;
	
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	private String roomNumber;

	@ManyToOne
	private RoomType roomType;

	private Security security;
	
	@OneToMany(mappedBy = "room")
	private List<RoomReservation> reservations;

	public Room() {
		security = new Security();
	}

	@PrePersist
	public void prePersist() {
		security.setCreation(LocalDateTime.now());
		security.setModification(LocalDateTime.now());
	}
	
	@PreUpdate
	private void preUpdate() {
		security.setModification(LocalDateTime.now());
	}

	public List<RoomReservation> getReservations() {
		return reservations;
	}

	public void setReservations(List<RoomReservation> reservations) {
		this.reservations = reservations;
	}

	public long getId() {
		return id;
	}

	public String getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(String roomNumber) {
		this.roomNumber = roomNumber;
	}

	public RoomType getRoomType() {
		return roomType;
	}

	public void setRoomType(RoomType roomType) {
		this.roomType = roomType;
	}

	public Security getSecurity() {
		return security;
	}

	public void setSecurity(Security security) {
		this.security = security;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isSelect() {
		return select;
	}

	public void setSelect(boolean select) {
		this.select = select;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((roomNumber == null) ? 0 : roomNumber.hashCode());
		result = prime * result + ((roomType == null) ? 0 : roomType.hashCode());
		result = prime * result + ((security == null) ? 0 : security.hashCode());
		result = prime * result + (select ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Room other = (Room) obj;
		if (id != other.id)
			return false;
		if (roomNumber == null) {
			if (other.roomNumber != null)
				return false;
		} else if (!roomNumber.equals(other.roomNumber))
			return false;
		if (roomType == null) {
			if (other.roomType != null)
				return false;
		} else if (!roomType.equals(other.roomType))
			return false;
		if (security == null) {
			if (other.security != null)
				return false;
		} else if (!security.equals(other.security))
			return false;
		if (select != other.select)
			return false;
		return true;
	}

}