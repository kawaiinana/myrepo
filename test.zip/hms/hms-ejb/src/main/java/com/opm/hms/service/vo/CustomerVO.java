package com.opm.hms.service.vo;

import java.util.List;
import java.util.stream.Collectors;

import com.opm.hms.entity.Customer;
import com.opm.hms.entity.Reservation;

public class CustomerVO {

	private int stayCount;

	private double stayPaid;

	private int lunchCount;

	private double lunchPaid;

	private int dinnerCount;

	private double dinnerPaid;

	private double laundaryPaid;

	private int point;

	private Customer customer;

	private List<Reservation> stayHistory;

	public CustomerVO() {
		customer = new Customer();
	}

	public int getStayCount() {
		return stayCount;
	}

	public void setStayCount(int stayCount) {
		this.stayCount = stayCount;
	}

	public double getStayPaid() {
		return stayPaid;
	}

	public void setStayPaid(double stayPaid) {
		this.stayPaid = stayPaid;
	}

	public int getLunchCount() {
		return lunchCount;
	}

	public void setLunchCount(int lunchCount) {
		this.lunchCount = lunchCount;
	}

	public double getLunchPaid() {
		return lunchPaid;
	}

	public void setLunchPaid(double lunchPaid) {
		this.lunchPaid = lunchPaid;
	}

	public int getDinnerCount() {
		return dinnerCount;
	}

	public void setDinnerCount(int dinnerCount) {
		this.dinnerCount = dinnerCount;
	}

	public double getDinnerPaid() {
		return dinnerPaid;
	}

	public void setDinnerPaid(double dinnerPaid) {
		this.dinnerPaid = dinnerPaid;
	}

	public double getLaundaryPaid() {
		return laundaryPaid;
	}

	public void setLaundaryPaid(double laundaryPaid) {
		this.laundaryPaid = laundaryPaid;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Reservation> getStayHistory() {
		return stayHistory.stream().filter(a -> !a.getStatus().equals("Cancel")).collect(Collectors.toList());
	}

	public void setStayHistory(List<Reservation> stayHistory) {
		this.stayHistory = stayHistory;
	}

}