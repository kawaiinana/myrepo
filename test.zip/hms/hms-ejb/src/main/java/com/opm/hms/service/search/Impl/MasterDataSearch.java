package com.opm.hms.service.search.Impl;

import java.util.HashMap;
import java.util.Map;

import com.opm.hms.service.search.Searchable;
import com.opm.hms.service.search.Sortable;

@SuppressWarnings("serial")
public class MasterDataSearch implements Searchable, Sortable {

	private String type;

	private String category;

	public MasterDataSearch() {
	}

	@Override
	public String where() {

		StringBuffer sb = new StringBuffer();

		// type
		if (null != type) {
			sb.append("and upper(t.type) like upper(:type) ");
		}

		// category
		if (null != category) {
			sb.append("and upper(t.category) like upper(:category) ");
		}

		return sb.toString();
	}

	@Override
	public Map<String, Object> params() {

		Map<String, Object> params = new HashMap<>();

		// type
		if (null != type) {
			params.put("type", "%".concat(type).concat("%"));
		}

		// category
		if (null != category) {
			params.put("category", "%".concat(category).concat("%"));
		}

		return params;
	}

	@Override
	public String orderBy() {

		return "";
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}