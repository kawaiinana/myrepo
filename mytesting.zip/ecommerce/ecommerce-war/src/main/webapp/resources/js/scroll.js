/**
 * 
 */
$(document).ready(
		function() {
			$contentLoadTriggered = false;
			$("#content-box")
					.scroll(
							function() {
								if ($("#content-box").scrollTop() >= ($(
										"#content-wrapper").height() - $(
										"#content-box").height())
										&& $contentLoadTriggered == false) {
									$contentLoadTriggered = true;
									$.get("infinitContentServlet", function(
											data) {
										$("#content-wrapper").append(data);
										$contentLoadTriggered = false;
									});
								}

							});
		});
