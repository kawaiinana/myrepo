package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Category;
import com.opm.shop.entity.Item;
import com.opm.shop.service.ItemServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class ItemListBean implements Serializable {

	private List<Item> items;
	private Account loginUser ;

	@Inject
	private ItemServiceLocal service;

	@Inject
	private CategorySelectBean categoryBean;

	@PostConstruct
	public void init() {
		items = new ArrayList<>();
		search();
	}

	public void search() {
		items.clear();
		if(null != categoryBean.getSelectedCategory() && categoryBean.getSelectedCategory().getId() != 0){
			items = service.find(categoryBean.getSelectedCategory().getId(), null);
		}		
	}
	
	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public List<Item> search(Category category, String keyword) {
		return null;
	}

	public Account getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(Account loginUser) {
		this.loginUser = loginUser;
	}

	public CategorySelectBean getCategoryBean() {
		return categoryBean;
	}

	public void setCategoryBean(CategorySelectBean categoryBean) {
		this.categoryBean = categoryBean;
	}
	
}