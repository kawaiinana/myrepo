package com.opm.shop.controller.admin;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.DataListingSupport;
import com.opm.shop.entity.State;
import com.opm.shop.service.StateServiceLocal;

@Named
@RequestScoped
@SuppressWarnings("serial")
public class StatePaginationBean extends DataListingSupport<State> {
	
	@Inject
	private StateServiceLocal service;
	
	public StatePaginationBean() {
		
		setSortField("name");
		setRowsPerPage(10);
		System.out.println(getRowsPerPage() + " this is row per pages");
	}

	@Override
	protected void populateCountAndData() {
		setRecordCount((int)service.findAll().stream().count());
		System.out.println(getRecordCount() + " this is record count");
		//setData(new ListDataModel<>(result.getResult()));
	}

}
