package com.opm.shop.controller.admin;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.model.DataModel;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.common.PaginationHelper;
import com.opm.shop.controller.member.ItemListBean;
import com.opm.shop.entity.Item;

@Named
@RequestScoped
public class ItemPaginationBean {
	
	@Inject
	private ItemListBean itemBean;
	
	private int pageSize;
	private int[] page;
	private List<Item> itemList;
	private PaginationHelper pagination;
	private int selectedItemIndex;

	private DataModel<Item> dtmd = null;

	@PostConstruct
	public void postConstruct() {

		page = new int[] { 5, 10, 15, 20, 30, 50 };
		pageSize = 10;
	}
	
	public int getSize() {
        return itemList.size();
    }

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int[] getPage() {
		return page;
	}

	public void setPage(int[] page) {
		this.page = page;
	}

	public void setPagination(PaginationHelper pagination) {
		this.pagination = pagination;
	}

	public int getSelectedItemIndex() {
		return selectedItemIndex;
	}

	public void setSelectedItemIndex(int selectedItemIndex) {
		this.selectedItemIndex = selectedItemIndex;
	}

	public DataModel<Item> getDtmd() {
		return dtmd;
	}

	public void setDtmd(DataModel<Item> dtmd) {
		this.dtmd = dtmd;
	}

	public List<Item> getItemList() {
		if (this.itemList == null) {
            this.itemList = itemBean.getItems();
        }
		return itemList;
	}

	public void setItemList(List<Item> itemList) {
		this.itemList = itemList;
	}

}
