package com.opm.shop.service;

import java.util.List;

import javax.ejb.Local;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Member;

@Local
public interface AccountServiceLocal {

	void create(Member account);

	void memberUpdate(Member account);

	void accountUpdate(Account loginUser);
	
	int getAllCount();

	Member findById(long id);

	Account findByEmail(String email);

	List<Account> findAllAccounts();

}