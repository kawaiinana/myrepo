package com.opm.shop.service.imp;

import java.util.Date;
import java.util.List;

import javax.ejb.Asynchronous;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Admin;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.AdminServiceLocal;
import com.opm.shop.service.NotificationServiceLocal;
import com.opm.shop.service.OrderServiceLocal;

@Stateless
public class TakeMoneyFromBuyerService {
	
	@Inject
	private AdminServiceLocal adminService;
	
	@Inject
	private OrderServiceLocal orderService;
	
	@Inject
	private NotificationServiceLocal notiService;
	
	Notification noti = new Notification();
	
	@Asynchronous
	public void getMoney(Order order){
		
		List<Admin> admins = adminService.findAllAdmins();
		
		try{
			//Money Transaction work here
			
			//Transaction Complete
			order.setStatus(Status.Cash_Transferred);
			orderService.save(order);
			
			for(int i=0 ; i<3 ; i++){
				if(i == 0){
					orderBreakDownNoti(order);
					noti.setNotiReceiver(order.getBuyer());
					noti.setNotiURL("/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
					noti.setNotiString("Order was confirm and System received your money.");
					notiService.save(noti);
					noti = new Notification();
				} else if(i == 1){
					orderBreakDownNoti(order);
					noti.setNotiReceiver(order.getItem().getOwner());
					noti.setNotiURL("/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
					noti.setNotiString("Order was confirm. Please send item to seller");
					notiService.save(noti);
					noti = new Notification();
				} else{
					for (Admin admin : admins) {
						adminNoti(admin,order);
						noti.setNotiString(order.getItem().getName()+" order was confirm and the System received money from Buyer.");
						notiService.save(noti);
						noti = new Notification();
					}
				}
			}
		}catch (Exception e) {
			//Transaction unComplete
			order.setStatus(Status.Break_Down);
			orderService.save(order);
			
			for(int i=0 ; i<3 ; i++){
				if(i == 0){
					orderBreakDownNoti(order);
					noti.setNotiReceiver(order.getBuyer());
					noti.setNotiURL("/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
					noti.setNotiString("Insufficient Balance in your account.Order break down");
					notiService.save(noti);
					noti = new Notification();
				} else if(i == 1){
					orderBreakDownNoti(order);
					noti.setNotiReceiver(order.getItem().getOwner());
					noti.setNotiURL("/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
					noti.setNotiString("Due to insufficient balance of Buyer, the order break down");
					notiService.save(noti);
					noti = new Notification();
				} else{
					for (Admin admin : admins) {
						adminNoti(admin,order);
						noti.setNotiString("Order break down due to insufficient balance of Buyer.");
						notiService.save(noti);
						noti = new Notification();
					}
				}
			} 
		}
	}
	
	private void adminNoti(Admin admin,Order order){
		noti.setNotiReceiver(admin);
		noti.setNotiURL("/admin/orderhistorydetail.xhtml?faces-redirect=true&id=" + order.getId());
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
	}
	
	 private void orderBreakDownNoti(Order order){
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
	} 
}
