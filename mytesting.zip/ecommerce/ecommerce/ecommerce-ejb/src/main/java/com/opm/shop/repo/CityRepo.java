package com.opm.shop.repo;

import com.opm.shop.entity.City;

public class CityRepo extends AbstractRepository<City> {

	public CityRepo() {
		super(City.class);
	}
}