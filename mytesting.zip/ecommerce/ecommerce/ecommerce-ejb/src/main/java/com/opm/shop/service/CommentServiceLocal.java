package com.opm.shop.service;

import java.util.List;

import javax.ejb.Local;

import com.opm.shop.entity.Comment;

@Local
public interface CommentServiceLocal {

	public void save(Comment comment);

	public Comment findById(int id);
	
	public List<Comment> findByOrderId(long id);

	public void update(Comment comment);

	public void delete(long comment);

}
