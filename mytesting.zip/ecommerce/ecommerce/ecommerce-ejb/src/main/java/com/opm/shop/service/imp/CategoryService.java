package com.opm.shop.service.imp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.enterprise.event.Event;
import javax.inject.Inject;

import com.opm.shop.entity.Category;
import com.opm.shop.repo.CategoryRepo;
import com.opm.shop.service.CategoryServiceLocal;

@Stateless
public class CategoryService implements CategoryServiceLocal {
	@Inject
	private CategoryRepo repo;

	@Inject
	private Event<Category> event;

	@Override
	public void save(Category data) {

		if(isAlreadyExist(data.getName(), data.getId(), data.getId() == 0)) {
			throw new RuntimeException("Category already exist.");
		}
		
		if (data.getId() == 0) {
			repo.persit(data);
		} else {
			repo.update(data);
		}
		
		event.fire(data);
	}

	@Override
	public Category findById(int id) {
		return repo.findById(id);
	}

	private boolean isAlreadyExist(String name, int id, boolean isNew) {
		
		String where = "t.name = :name and t.deleteFlag = false";
		Map<String, Object> params = new HashMap<>();

		if(!isNew) {
			where = "t.id <> :id and ".concat(where);
			params.put("id", id);
		}
		params.put("name", name);
				
		return !repo.find(where, params).isEmpty();
	}

	@Override
	public List<Category> findAll() {
		Map<String, Object> params = new HashMap<>();
		params.put("del", false);
		return repo.find("t.deleteFlag = :del", params);
	}

	@Override
	public List<Category> findParents() {
		Map<String, Object> params = new HashMap<>();
		params.put("del", false);
		return repo.find("t.parent is null and t.deleteFlag = :del", params);
	}


}