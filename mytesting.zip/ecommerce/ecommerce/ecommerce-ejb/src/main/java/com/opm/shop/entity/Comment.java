package com.opm.shop.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;

import com.opm.shop.entity.SecurityInfo.Valid;

@SuppressWarnings("serial")
@Entity
public class Comment implements Serializable {

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	@Lob
	private String comment;

	@Embedded
	private SecurityInfo security;

	@ManyToOne
	private Order order;
	
	@ManyToOne
	private Member owner;

	@ManyToOne
	private Item item;
	
	public Comment() {
		security = new SecurityInfo();
	}
	
	@PrePersist
	private void prePersist() {
		security.setCreation(new Date());
		security.setModification(new Date());
		security.setValid(Valid.ON);
	}

	@PreUpdate
	private void preUpdate() {
		security.setModification(new Date());
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Member getOwner() {
		return owner;
	}

	public void setOwner(Member owner) {
		this.owner = owner;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}
	
}
