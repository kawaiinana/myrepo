package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.service.ItemServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MyProductListBean implements Serializable {

	private Member member;
	private List<Item> items;
	
	@Named
	@Inject
	private Member loginMember;

	@Inject
	private ItemServiceLocal service;

	@PostConstruct
	private void init() {
		serchByMember();
	}

	public String serchByMember() {
		items = service.findByMemberId(loginMember.getId());
		return "/member/product-listing.xhtml";
	}

	public Member getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Member loginMember) {
		this.loginMember = loginMember;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}
}
