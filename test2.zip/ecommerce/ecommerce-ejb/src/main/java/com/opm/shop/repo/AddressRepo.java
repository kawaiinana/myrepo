package com.opm.shop.repo;

import com.opm.shop.entity.Address;

public class AddressRepo extends AbstractRepository<Address> {

	public AddressRepo() {
		super(Address.class);
	}

    
}