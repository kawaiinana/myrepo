package com.opm.shop.producers;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Brand;
import com.opm.shop.service.BrandServiceLocal;

@ApplicationScoped
public class BrandProducer {

    public BrandProducer() {
    }

    @Named
    @Produces
    private List<Brand> brands;
    
    @Inject
    private BrandServiceLocal service;
    
    @PostConstruct
	private void init() {
		load(null);
	}

    private void load(@Observes Brand data) {
    	brands = service.findAllUndeleted();
    }
 }