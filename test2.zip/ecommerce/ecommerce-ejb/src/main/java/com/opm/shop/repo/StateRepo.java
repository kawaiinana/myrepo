package com.opm.shop.repo;

import com.opm.shop.entity.State;

public class StateRepo extends AbstractRepository<State> {

	public StateRepo() {
		super(State.class);
	}

}