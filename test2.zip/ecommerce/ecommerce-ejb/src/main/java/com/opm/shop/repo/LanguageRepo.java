package com.opm.shop.repo;

import com.opm.shop.entity.Language;

public class LanguageRepo extends AbstractRepository<Language> {

	public LanguageRepo() {
		super(Language.class);
	}

}