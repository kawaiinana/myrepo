package com.opm.shop.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Enumerated;

@SuppressWarnings("serial")
@Entity
public class Notification implements Serializable {

	public Notification() {
		security = new SecurityInfo();
	}

	public enum Status {New, Read}
	
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;
	
	@ManyToOne
	private Account notiReceiver;
	
	@ManyToOne
	private Order order;
	
	private String notiURL;
	
	private String notiString;
	
	@ManyToOne
	private Member notiCreator;
	
	private SecurityInfo security;
	
	@Enumerated
	private Status status;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Account getNotiReceiver() {
		return notiReceiver;
	}

	public void setNotiReceiver(Account notiReceiver) {
		this.notiReceiver = notiReceiver;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public String getNotiURL() {
		return notiURL;
	}

	public void setNotiURL(String notiURL) {
		this.notiURL = notiURL;
	}

	public String getNotiString() {
		return notiString;
	}

	public void setNotiString(String notiString) {
		this.notiString = notiString;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Member getNotiCreator() {
		return notiCreator;
	}

	public void setNotiCreator(Member notiCreator) {
		this.notiCreator = notiCreator;
	}

}