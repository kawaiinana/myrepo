package com.opm.shop.service;



import java.util.List;

import com.opm.shop.entity.Category;

public interface CategoryServiceLocal {
    
    public void save(Category category);

   
    public Category findById(int id);
   
    List<Category> findAll();
    List<Category> findParents();

}