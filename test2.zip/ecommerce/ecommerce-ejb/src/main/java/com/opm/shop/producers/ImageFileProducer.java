package com.opm.shop.producers;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;

@ApplicationScoped
public class ImageFileProducer {

	@Named
	@Produces
	private String imgUrl;

	@Named
	@Produces
	private String imageFilePath;

	@PostConstruct
	private void init() {
		imgUrl=System.getProperty("ecommerce-war.image_url");
		imageFilePath=System.getProperty("ecommerce-war.img_file_path");
	}
}
