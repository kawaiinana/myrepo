package com.opm.shop.controller.member;

import java.io.IOException;
import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.Part;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Member;
import com.opm.shop.service.AccountServiceLocal;
import com.opm.shop.service.AddressServiceLocal;
import com.opm.shop.service.MemberServiceLocal;
import com.opm.shop.utils.PasswordUtils;

@SuppressWarnings("serial")
@ViewScoped
@Named
public class ProfileBean implements Serializable {

	@Inject
	@Named
	private Member loginMember;

	private Part file;
	private String path;

	@Named
	@Inject
	private String imageFilePath;
	
	private boolean agree=true;
	
	@Inject
	private AddressServiceLocal addService;

	@Inject
	@Named
	private Account loginUser;

	@NotNull
	@Pattern(regexp = "[a-zA-Z0-9]+",message="Must enter password")
	private String curPassword;
	
	@NotNull
	@Pattern(regexp = "[a-zA-Z0-9]+",message="Must enter new password")
	private String newPassword;

	@Inject
	private MemberServiceLocal memService;

	@Inject
	private AccountServiceLocal accService;
	
	
	@PostConstruct
	private void init(){
		
	}

	public void upload() {
		
		System.out.println("File In Start Upload"+file);

		try {
			if (null != file) {
				String fileName = file.getSubmittedFileName();
				System.out.println(fileName);
				String[] array = fileName.split("\\.");
				String extension = array[array.length - 1];
				path = String.format("%d.%s", new Date().getTime(), extension);
				file.write(imageFilePath.concat(path));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		loginMember.setImage(path);
		memService.update(loginMember);

		System.out.println("Path in end upload=" + path);
		System.out.println("File in end upload="+file);

	}
	public String updateProfile() {
		if (agree == true) {
			memService.update(loginMember);
			System.out.println("Member Name=" + addService.findByLoginMember(loginMember.getId()));
			if (addService.findByLoginMember(loginMember.getId()) == null) {
				return "/member/my-address?faces-redirect=true";
			} else
				return "/member/member-home?faces-redirect=true";

		}
		FacesMessage message = new FacesMessage("agree", "Please check term and service");
		FacesContext.getCurrentInstance().addMessage(null, message);

		return null;
	}

	public String updateAccount(String confirmPassword) {
		
		String currentPassword = new String();
		try {
			currentPassword = PasswordUtils.encript(curPassword);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		if ((loginUser.getPassword().equals(currentPassword)) && (newPassword.equals(confirmPassword))) {
			loginUser.setPassword(newPassword);
			accService.accountUpdate(loginUser);
			return "/member/my-account-setting?faces-redirect=true";
		}
		return "";
	}
	
	public boolean isAgree() {
		return agree;
	}
	public void setAgree(boolean agree) {
		this.agree = agree;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	public String getImageFilePath() {
		return imageFilePath;
	}

	public void setImageFilePath(String imageFilePath) {
		this.imageFilePath = imageFilePath;
	}

	public String getCurPassword() {
		return curPassword;
	}

	public void setCurPassword(String curPassword) {
		this.curPassword = curPassword;
	}
	
	public Member getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Member loginMember) {
		this.loginMember = loginMember;
	}

	public Part getFile() {
		return file;
	}

	public void setFile(Part file) {
		this.file = file;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
}
