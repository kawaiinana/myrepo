package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.NotificationServiceLocal;
import com.opm.shop.service.OrderServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class SaleHistoryDetailBean implements Serializable {

	public SaleHistoryDetailBean() {
	}

	@Inject
	private OrderServiceLocal service;
	private Order order;
	@Inject
	@Named
	private Account loginMember;
	private boolean enableAction;

	@Inject
	@Named("loginMember")
	private Member loginMem;

	private Notification noti;

	@Inject
	private NotificationServiceLocal notiService;

	@PostConstruct
	public void init() {
		order = new Order();
		noti = new Notification();
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		if (null != str) {
			order = service.findById(Long.parseLong(str));
			enableAction = (order.getStatus() == Status.Pending || order.getStatus() == Status.Processing);
		}
	}

	public String confrimPendingAction() {
		order.setStatus(Status.Processing);
		order.getSecurity().setModUser(loginMember.getId());
		service.save(order);

		addStatusNoti();
		noti.setNotiString(
				"Your " + order.getItem().getName() + " order was confirmed by item owner.\nPlease pay for this order.");

		notiService.save(noti);

		return "/member/sale-history.xhtml?faces-redirect=true";
	}
	
	public String rejectPendingAction() {
		order.setStatus(Status.Reject);
		order.getSecurity().setModUser(loginMember.getId());
		service.save(order);

		addStatusNoti();
		noti.setNotiString("Your " + order.getItem().getName() + " order was rejected."
				+ "\nClick here to see the Remark.");

		notiService.save(noti);

		return "/member/sale-history.xhtml?faces-redirect=true";
	}

	public String deliverdAction() {
		order.setStatus(Status.ConfirmShipment);
		order.getSecurity().setModUser(loginMember.getId());
		service.save(order);

		addStatusNoti();
		noti.setNotiString("Your " + order.getItem().getName() + " order had been sent to you.");

		notiService.save(noti);

		return "/member/sale-history.xhtml?faces-redirect=true";
	}

	public void addStatusNoti() {

		noti.setNotiReceiver(order.getBuyer());
		noti.setNotiURL("/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setNotiCreator(loginMem);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
	}

	public boolean isEnableAction() {
		return enableAction;
	}

	public void setEnableAction(boolean enableAction) {
		this.enableAction = enableAction;
	}

	public String orderCancelAction() {
		return "";
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Account getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Account loginMember) {
		this.loginMember = loginMember;
	}

}