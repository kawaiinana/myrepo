package com.opm.shop.controller.member;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.flow.FlowScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.Part;

import com.opm.shop.controller.admin.BrandBean;
import com.opm.shop.entity.Account;
import com.opm.shop.entity.CommissionRate;
import com.opm.shop.entity.CommissionRate.RateType;
import com.opm.shop.entity.Country;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Item.Status;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Price;
import com.opm.shop.entity.State;
import com.opm.shop.service.CategoryServiceLocal;
import com.opm.shop.service.CommissionRateLocal;
import com.opm.shop.service.CountryServiceLocal;
import com.opm.shop.service.ItemServiceLocal;
import com.opm.shop.service.StateServiceLocal;

@SuppressWarnings("serial")
@Named
@FlowScoped("product")
public class AddItemBean implements Serializable {

	public AddItemBean() {
	}
	
	private Part file;
	private String path;

	@Named
	@Inject
	private String imageFilePath;
	
	private List<String> images;	

	@Inject
	private CommissionRate commissionRate;

	@Inject
	private ItemServiceLocal service;	
	
	@Inject
	private CategoryServiceLocal categoryService;	
	
	@Inject
	private StateServiceLocal stateService;
	
	@Inject
	private CountryServiceLocal countryService;
	
	@Inject
	private CommissionRateLocal commissionService;

	@Inject
	private ItemListBean itemListBean;
	
	@Inject
	private BrandBean brandBean;

	private Set<State> selectedState;
	
	private Set<Country> selectedCountry;

	private Set<Price> prices; 
	
	private Price price;
	
	private Item item;
	
	private List<State> states;
	
	private List<Country> countries;

	private double rate;	
	
	@Named
	@Inject
	private Account loginUser;	
	
	@Named
	@Inject
	private Member loginMember;	
	
	@PostConstruct
	public void init() {
		item = new Item();
		selectedState = new LinkedHashSet<>();
		selectedCountry = new LinkedHashSet<>();
		prices = new LinkedHashSet<>();
		states = stateService.getAll();
		countries = countryService.getAll();
		price = new Price();
		rate = 0.0;		
	}

	public void calRate() {
		
		commissionRate = commissionService.findByItemPrice(item.getPrice());
		
		if(commissionRate != null){
			if(commissionRate.getType() == RateType.Fix){
				rate = commissionRate.getRate();				
			}else{
				rate = (item.getPrice() * commissionRate.getRate()) / 100;
			}
		}else{
			rate = 0.0;			
		}
	}
	
	public void upload() {
		
		try {
			if (null != file) {
				String fileName = file.getSubmittedFileName();
				String[] array = fileName.split("\\.");
				String extension = array[array.length - 1];
				path = String.format("%d.%s", new Date().getTime(), extension);
				file.write(imageFilePath.concat(path));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		images.add(path);
		//item.setImage(images);
	}

	public String save() {
		try{
			
			//add prices
			price.setPrice(item.getPrice());
			price.setRefDate(new Date());
			prices.add(price);
			item.setPrices(prices);
			item.setOwner(loginMember);
			item.setCommissionRate(rate);
			
			//add category
			if(itemListBean.getThird() != null){			
				item.setCategory(categoryService.findById(itemListBean.getThird().getId()));
				System.out.println(item.getCategory().getName()+"third category ******************");
			}else if(itemListBean.getSecond() != null){
				item.setCategory(categoryService.findById(itemListBean.getSecond().getId()));
				System.out.println(item.getCategory().getName()+"second category ******************");
			}else if(itemListBean.getFirst() != null){
				item.setCategory(categoryService.findById(itemListBean.getFirst().getId()));
				System.out.println(item.getCategory().getName()+"first category ******************");
			}
			
			item.setStatus(Status.Available);
			item.setState(selectedState);
			item.setCountry(selectedCountry);
			System.out.println(item.getId());
			System.out.println(item.getName());
			System.out.println(item.getDescription());
			System.out.println(item.getColor());
			System.out.println(item.getSize());
			System.out.println(item.getPrice());
			System.out.println(selectedCountry.stream().collect(Collectors.toList()));
			System.out.println(selectedState.stream().collect(Collectors.toList()));
			//System.out.println(getPrices());
			service.save(item);
			
			item = new Item();
			return "/member/product-listing.xhtml?faces-redirect=true";
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return "";
	}
	
	public String productLink(){
		
		return "product-step2";
	}
	
	public Part getFile() {
		return file;
	}

	public void setFile(Part file) {
		this.file = file;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getImageFilePath() {
		return imageFilePath;
	}

	public void setImageFilePath(String imageFilePath) {
		this.imageFilePath = imageFilePath;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public Account getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(Account loginUser) {
		this.loginUser = loginUser;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public CommissionRate getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(CommissionRate commissionRate) {
		this.commissionRate = commissionRate;
	}

	public ItemListBean getItemListBean() {
		return itemListBean;
	}

	public void setItemListBean(ItemListBean itemListBean) {
		this.itemListBean = itemListBean;
	}

	public BrandBean getBrandBean() {
		return brandBean;
	}

	public void setBrandBean(BrandBean brandBean) {
		this.brandBean = brandBean;
	}

	public Set<State> getSelectedState() {
		return selectedState;
	}

	public void setSelectedState(Set<State> selectedState) {
		this.selectedState = selectedState;
	}

	public Set<Country> getSelectedCountry() {
		return selectedCountry;
	}

	public void setSelectedCountry(Set<Country> selectedCountry) {
		this.selectedCountry = selectedCountry;
	}

	public Set<Price> getPrices() {
		return prices;
	}

	public void setPrices(Set<Price> prices) {
		this.prices = prices;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public List<State> getStates() {
		return states;
	}

	public void setStates(List<State> states) {
		this.states = states;
	}

	public List<Country> getCountries() {
		return countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}

	
	
}
