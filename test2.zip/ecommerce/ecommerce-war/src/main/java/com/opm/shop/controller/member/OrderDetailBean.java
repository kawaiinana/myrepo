package com.opm.shop.controller.member;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.OrderServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class OrderDetailBean implements Serializable {

	private Order order;

	@Named
	@Inject
	private Account loginUser;

	@Inject
	private OrderServiceLocal service ;

	
	@PostConstruct
	public void init() {

		order = new Order();

		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");

		if(null != str){
			order = service.findById(Long.parseLong(str));			
		}	
	}
	
	public String allowDelivery() {
		
		order.setStatus(Status.Allow_Delivery);
		order.getSecurity().setModUser(loginUser.getId());
		service.save(order);		

		return "/admin/orderhistory.xhtml?faces-redirect=true";
	}
	
	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

}