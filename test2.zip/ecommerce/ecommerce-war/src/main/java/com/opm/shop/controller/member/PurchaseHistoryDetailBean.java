package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Admin;
import com.opm.shop.entity.Comment;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.AdminServiceLocal;
import com.opm.shop.service.CommentServiceLocal;
import com.opm.shop.service.NotificationServiceLocal;
import com.opm.shop.service.OrderServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class PurchaseHistoryDetailBean implements Serializable {

	public PurchaseHistoryDetailBean() {
	}

	@Inject
	private OrderServiceLocal service;

	private Order order;

	private Notification noti;

	@Inject
	@Named
	private Account loginMember;

	@Named("loginMember")
	@Inject
	private Member loginMem;
	
	@Inject
	private CommentServiceLocal commentService;

	@Inject
	private NotificationServiceLocal notiService;

	@Inject
	private AdminServiceLocal adminService;

	@Inject
	private Event<Comment> notiEvent;
	
	private boolean enableAction;

	private Comment comment;

	private List<Comment> comments;

	private List<Admin> admins;

	@PostConstruct
	public void init() {
		noti = new Notification();
		order = new Order();
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		comment = new Comment();
		admins = adminService.findAllAdmins();

		if (null != str) {
			order = service.findById(Long.parseLong(str));
			enableAction = order.getStatus() == Status.ConfirmShipment;
			comments = commentService.findByOrderId(Long.parseLong(str));
		}

	}

	public String addComment(boolean isSellerComment) {
		comment.setOrder(order);
		comment.setOwner(loginMem);

		commentService.save(comment);

		addCommentNoti(isSellerComment);
		notiEvent.fire(comment);

		if (!isSellerComment) {
			return "/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		} else {
			return "/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		}
	}

	public void addCommentNoti(boolean isSellerComment) {
		if (isSellerComment) {
			noti.setNotiReceiver(order.getBuyer());
			noti.setNotiURL("/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
		} else {
			noti.setNotiReceiver(order.getItem().getOwner());
			noti.setNotiURL("/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
		}
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
		noti.setNotiCreator(loginMem);
		noti.setNotiString(order.getItem().getName() + " order has a new comment.");

		notiService.save(noti);

	}

	public String deleteComment(long commentId, boolean isSellerComment) {
		commentService.delete(commentId);

		if (!isSellerComment) {
			return "/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		} else {
			return "/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		}
	}

	public String updateComment(Comment comment, boolean isSellerComment) {
		commentService.update(comment);
		if (!isSellerComment) {
			return "/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		} else {
			return "/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		}
	}

	public String confrimShippmentAction() {

		order.setStatus(Status.Completed);
		order.getSecurity().setModUser(loginMember.getId());
		service.save(order);

		addStatusNoti();
		noti.setNotiString(order.getItem().getName() + " order was successfully delivered to  "
				+ order.getBuyer().getNickname() + ".");

		notiService.save(noti);

		return "/member/purchase-history.xhtml?faces-redirect=true";
	}

	public String buyerPaidAction() {

		order.setStatus(Status.Paid);
		order.getSecurity().setModUser(loginMember.getId());
		service.save(order);

		for (Admin admin : admins) {

			noti.setNotiReceiver(admin);
			noti.setNotiURL("/admin/orderhistorydetail.xhtml?faces-redirect=true&id=" + order.getId());
			noti.getSecurity().setCreation(new Date());
			noti.setOrder(order);
			noti.setNotiCreator(loginMem);
			noti.setStatus(com.opm.shop.entity.Notification.Status.New);
			noti.setNotiString(order.getBuyer().getNickname() + " had paid for " + order.getItem().getName()
					+ " order at about " + new Date() + ".\nPlease check.");
			notiService.save(noti);
		}

		return "/member/purchase-history.xhtml?faces-redirect=true";
	}

	public void addStatusNoti() {

		noti.setNotiReceiver(order.getItem().getOwner());
		noti.setNotiURL("/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setNotiCreator(loginMem);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
	}

	public boolean isEnableAction() {
		return enableAction;
	}

	public void setEnableAction(boolean enableAction) {
		this.enableAction = enableAction;
	}

	public String orderCancelAction() {
		return "";
	}

	public Order getOrder() {
		return order;
	}

	public Member getLoginMem() {
		return loginMem;
	}

	public void setLoginMem(Member loginMem) {
		this.loginMem = loginMem;
	}

	public Comment getComment() {
		return comment;
	}

	public void setComment(Comment comment) {
		this.comment = comment;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Account getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Account loginMember) {
		this.loginMember = loginMember;
	}

	public Notification getNoti() {
		return noti;
	}

	public void setNoti(Notification noti) {
		this.noti = noti;
	}

}