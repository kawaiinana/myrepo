package com.opm.shop.controller.admin;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Country;
import com.opm.shop.service.CountryServiceLocal;

@SuppressWarnings("serial")
@Named
@RequestScoped
public class CountryBean implements Serializable{

	@Inject
	private List<Country> countries;
	private Country country;

	@Inject
	private CountryServiceLocal service;
	
	@PostConstruct
	public void init() {
		countries=service.getAll();
	}

	public String delete(Country country) {
		country.setDeleteFlag(true);
		service.save(country);
		return "";
	}

	public List<Country> getCountries() {
		return countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

}