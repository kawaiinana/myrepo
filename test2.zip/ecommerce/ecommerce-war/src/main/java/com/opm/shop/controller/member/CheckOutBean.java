package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Address;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.entity.SecurityInfo;
import com.opm.shop.entity.State;
import com.opm.shop.service.ItemServiceLocal;
import com.opm.shop.service.OrderServiceLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CheckOutBean implements Serializable {

	public CheckOutBean() {
	}

	private Address address;

	private Item item;

	@Named
	@Inject
	private Member loginMember;

	@Inject
	private AddressBean addressBean;

	private SecurityInfo security;

	@Inject
	private ItemDetailBean itemDetailBean;

	@Inject
	private ItemServiceLocal itemService;

	@Inject
	private OrderServiceLocal orderService;

	private List<Order> orders;

	private Order order;

	@PostConstruct
	public void init() {

		item = new Item();
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		item = itemService.findById(Long.parseLong(str));
		security = new SecurityInfo();
		order = new Order();

	}

	public String save() {

		String returnState = "";
		Set<State> set = item.getState();
		List<State> list = new ArrayList<>(set);
		for (int i = 0; i < list.size(); i++) {
			System.out.println("For address matching =" + list.get(i).getName().equals(addressBean.getState().getName()));
			if (list.get(i).getName().equals(addressBean.getState().getName())) {
				order.setStatus(Status.Pending);
				security.setCreateUser(loginMember.getId());
				order.setSecurity(security);
				order.setBuyer(loginMember);
				order.setOrderDate(new Date());
				order.setItem(item);
				orderService.save(order);
				returnState = "/member/purchase-history?faces-redirect=true";
			}
		}
		FacesMessage message = new FacesMessage("Not-Match", "You can't buy this item because of target area");
		FacesContext.getCurrentInstance().addMessage(null, message);
		return returnState;
	}

	public Item getItem() {
		return item;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Member getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Member loginMember) {
		this.loginMember = loginMember;
	}

	public AddressBean getAddressBean() {
		return addressBean;
	}

	public void setAddressBean(AddressBean addressBean) {
		this.addressBean = addressBean;
	}

	public ItemDetailBean getItemDetailBean() {
		return itemDetailBean;
	}

	public void setItemDetailBean(ItemDetailBean itemDetailBean) {
		this.itemDetailBean = itemDetailBean;
	}

}