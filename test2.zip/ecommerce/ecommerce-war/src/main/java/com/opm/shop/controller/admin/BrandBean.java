package com.opm.shop.controller.admin;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Brand;
import com.opm.shop.service.BrandServiceLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class BrandBean implements Serializable {

	@Inject
	private BrandServiceLocal service;

	
	private List<Brand> brandsList;
	private Brand brand;

	@PostConstruct
	private void init() {

		brandsList = service.findAllUndeleted();
		brand = new Brand();
	}

	public String save() {
		
		if(!brandsList.stream().filter(b -> b.getName().equals(brand.getName())).findAny().isPresent()){
			service.create(brand);
			return "/admin/brand.xhtml?faces-redirect=true";
		}
		else{
			FacesMessage message = new FacesMessage("Name Error", "This Brand name already exist.");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
			
		return "";
		
	}
	
	public String update() {
		Brand b = new Brand();
		b = service.findByNameAndId(brand.getName(),brand.getId());
		if( b == null){
			service.update(brand);
			return "/admin/brand.xhtml?faces-redirect=true";
		}
		else{
			
			FacesMessage message = new FacesMessage("Name Error", "This Brand name already exist.");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
			
		return "";
		
	}


	public String delete(Brand b) {

		b.setDeleteFlag(true);
		service.delete(b);
		
		return "/admin/brand.xhtml?faces-redirect=true";
	}

	public String edit(Brand b) {

		brand = b;

		return "/admin/brand.xhtml?faces-redirect=true";
	}

	public void search(String brandName) {

		if (brandName != null && !brandName.isEmpty()) {
			brandsList = service.search(brandName);
		}else{
			brandsList = service.findAllUndeleted();
		}
		
	}

	public List<Brand> getBrandsList() {
		return brandsList;
	}

	public void setBrandsList(List<Brand> brandsList) {
		this.brandsList = brandsList;
	}

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}
}
