package com.opm.shop.service.imp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Address;
import com.opm.shop.repo.AddressRepo;
import com.opm.shop.service.AddressServiceLocal;

@Stateless
public class AddressService implements AddressServiceLocal {

	@Inject
	private AddressRepo repo;
	
	@Override
	public void save(Address address){
		repo.persit(address);
	}

	@Override
	public void update(Address address) {
		repo.update(address);
	}

	@Override
	public List<Address> findAllAddress() {
		return repo.find(null, null);
	}

	@Override
	public Address findByLoginMember(long id) {
		
		String where = "t.member.id = :id ";
		Map<String, Object> params = new HashMap<>();
		params.put("id", id);
		
		List<Address> addr= repo.find(where, params);
		
		if(addr.size() >= 0){
			return addr.get(0);
		}
		
		return null;
		
//		repo.find(null, null);
	}
}
