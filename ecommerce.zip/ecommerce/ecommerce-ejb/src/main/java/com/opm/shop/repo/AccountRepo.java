package com.opm.shop.repo;

import com.opm.shop.entity.Account;

public class AccountRepo extends AbstractRepository<Account> {

	public AccountRepo() {
		super(Account.class);
	}
    

}