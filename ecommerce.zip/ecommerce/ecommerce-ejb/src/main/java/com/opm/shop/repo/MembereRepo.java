package com.opm.shop.repo;

import com.opm.shop.entity.Member;

public class MembereRepo extends AbstractRepository<Member> {

	public MembereRepo() {
		super(Member.class);
	}

}