package com.opm.shop.producers;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Member;
import com.opm.shop.service.AccountServiceLocal;
import com.opm.shop.service.MemberServiceLocal;

@SuppressWarnings("serial")
@SessionScoped
public class LoginUserProducer implements Serializable {

	@Named
	@Produces
	private Account loginUser;
	
	@Named
	@Produces
	private Member loginMember;
	
	@Inject
	private AccountServiceLocal accService;
	
	@Inject
	private MemberServiceLocal memService;
	
	public void load(@Observes String email) {
		loginUser = accService.findByEmail(email);
		long id = loginUser.getId();
		loginMember = memService.findById(id);
	}
	
}
