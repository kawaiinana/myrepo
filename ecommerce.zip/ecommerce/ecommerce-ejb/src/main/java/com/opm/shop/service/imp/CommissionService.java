package com.opm.shop.service.imp;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.CommissionRate;
import com.opm.shop.entity.CommissionRate.RateType;
import com.opm.shop.repo.CommissionRateRepo;
import com.opm.shop.service.CommissionRateLocal;

@Stateless
public class CommissionService implements CommissionRateLocal {

	@Inject
	private CommissionRateRepo repo;

	@Override
	public void save(CommissionRate comRate) {
		if (isAlreadyExist(comRate.getAmountFrom(), comRate.getId(), comRate.getId() == 0)) {
			throw new RuntimeException("Amount already exist.");
		}
		if (comRate.getId() == 0) {
			repo.persit(comRate);
		} else {
			repo.update(comRate);
		}

	}

	@Override
	public CommissionRate findById(int id) {
		return repo.findById(id);
	}

	@Override
	public List<CommissionRate> findAll() {
		return repo.findAllUndeleted();
	}

	@Override
	public void delete(CommissionRate c) {
		repo.update(c);
	}

	@Override
	public List<CommissionRate> find(RateType type, Date refDate) {
		StringBuffer sb = new StringBuffer("t.deleteFlag = false ");
		Map<String, Object> params = new HashMap<>();

		if (null != type) {
			sb.append("and t.type = :type ");
			params.put("type", type);
		}

		if (null != refDate) {
			sb.append("and t.refDate = :refDate");
			params.put("refDate", refDate);
		}

		return repo.find(sb.toString(), params);
	}

	@Override
	public boolean isAlreadyExist(double amountFrom, int id, boolean isNew) {
		String where = "t.amountFrom = :amountFrom and t.deleteFlag = false";
		Map<String, Object> params = new HashMap<>();

		if (!isNew) {
			where = "t.id <> :id and ".concat(where);
			params.put("id", id);
		}
		params.put("amountFrom", amountFrom);

		return !repo.find(where, params).isEmpty();
	}

	@Override
	public List<CommissionRate> calculateRate(double amountFrom, double amountTo, double rate) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		if (amountFrom != 0 || amountTo != 0 || rate != 0) {
			sb.append("t.amountFrom = :amountFrom and ");
			params.put("amountFrom", amountFrom);

			sb.append("t.amountTo = :amountTo and ");
			params.put("amountTo", amountTo);

			sb.append("t.rate = :rate");
			params.put("rate", rate);

		}
		return repo.find(sb.toString(), params);
	}

}
