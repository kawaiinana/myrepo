package com.opm.shop.service.imp;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.entity.SecurityInfo;
import com.opm.shop.entity.SecurityInfo.Valid;
import com.opm.shop.repo.NotificationRepo;
import com.opm.shop.repo.OrderRepo;
import com.opm.shop.service.OrderServiceLocal;

@Stateless
public class OrderService implements OrderServiceLocal {

	@Inject
	private OrderRepo repo;
	@Inject
	private NotificationRepo notiRepo;

	public void save(Order order) {
		if (order.getId() == 0) {
			repo.persit(order);
		} else {
			repo.update(order);
		}
		List<Notification> notiList = getNotificationByAction(order);
		for (Notification notification : notiList) {
			notiRepo.persit(notification);
		}
	}

	private List<Notification> getNotificationByAction(Order order) {
		List<Notification> list = new ArrayList<>();
		Notification noti = new Notification();
		SecurityInfo securitytInfo = new SecurityInfo();
		switch (order.getStatus()) {
		case Pending:
			// Notify Buyer
			noti.setTitle("Order " + order.getStatus().toString());
			noti.setDescription("Your order no [" + order.getId() + "] is now " + order.getStatus().toString());
			noti.setNotiURL("/member/purchase-history-detail.xhtml?id=" + order.getId());
			securitytInfo.setCreateUser(order.getSecurity().getCreateUser());
			securitytInfo.setCreation(new Date());
			securitytInfo.setValid(Valid.ON);
			noti.setSecurity(securitytInfo);
			list.add(noti);
			// Notify Seller
			noti = new Notification();
			noti.setTitle("Sale " + order.getStatus().toString());
			noti.setDescription("You have sale order no [" + order.getId() + "] is waiting to confirm.");
			noti.setNotiURL("/member/sale-history-detail.xhtml?id=" + order.getId());
			securitytInfo = new SecurityInfo();
			securitytInfo.setCreateUser(order.getSecurity().getCreateUser());
			securitytInfo.setCreation(new Date());
			securitytInfo.setValid(Valid.ON);
			noti.setSecurity(securitytInfo);
			list.add(noti);
			break;
		case Processing:
			// Notify Buyer
			noti.setTitle("Order " + order.getStatus().toString());
			noti.setDescription("Your order no [" + order.getId() + "] is now " + order.getStatus().toString());
			noti.setNotiURL("/member/purchase-history-detail.xhtml?id=" + order.getId());
			securitytInfo.setCreateUser(order.getSecurity().getCreateUser());
			securitytInfo.setCreation(new Date());
			securitytInfo.setValid(Valid.ON);
			noti.setSecurity(securitytInfo);
			list.add(noti);
			break;
		case ConfirmShipment:
			// Notify Buyer
			noti.setTitle("Order Shippment Confirm");
			noti.setDescription("Your order no [" + order.getId() + "] is now delivered. Please confirm shippment.");
			noti.setNotiURL("/member/purchase-history-detail.xhtml?id=" + order.getId());
			securitytInfo.setCreateUser(order.getSecurity().getCreateUser());
			securitytInfo.setCreation(new Date());
			securitytInfo.setValid(Valid.ON);
			noti.setSecurity(securitytInfo);
			list.add(noti);
			break;
		case Completed:
			// Notify Buyer
			noti.setTitle("Order " + order.getStatus().toString());
			noti.setDescription("Your order no [" + order.getId() + "] is now " + order.getStatus().toString());
			noti.setNotiURL("/member/purchase-history-detail.xhtml?id=" + order.getId());
			securitytInfo.setCreateUser(order.getSecurity().getCreateUser());
			securitytInfo.setCreation(new Date());
			securitytInfo.setValid(Valid.ON);
			noti.setSecurity(securitytInfo);
			list.add(noti);
			// Notify Seller
			noti = new Notification();
			noti.setTitle("Sale " + order.getStatus().toString());
			noti.setDescription("Your sale order no [" + order.getId() + "] is now completed.");
			noti.setNotiURL("/member/sale-history-detail.xhtml?id=" + order.getId());
			securitytInfo = new SecurityInfo();
			securitytInfo.setCreateUser(order.getSecurity().getCreateUser());
			securitytInfo.setCreation(new Date());
			securitytInfo.setValid(Valid.ON);
			noti.setSecurity(securitytInfo);
			list.add(noti);
			break;
		case Reject:
			// Notify Buyer
			noti.setTitle("Order " + order.getStatus().toString());
			noti.setDescription("Your order no [" + order.getId() + "] is " + order.getStatus().toString());
			noti.setNotiURL("/member/purchase-history-detail.xhtml?id=" + order.getId());
			securitytInfo.setCreateUser(order.getSecurity().getCreateUser());
			securitytInfo.setCreation(new Date());
			securitytInfo.setValid(Valid.ON);
			noti.setSecurity(securitytInfo);
			list.add(noti);
			break;
		case Expired:
			// Notify Buyer
			noti.setTitle("Order " + order.getStatus().toString());
			noti.setDescription("Your order no [" + order.getId() + "] is " + order.getStatus().toString());
			noti.setNotiURL("/member/purchase-history-detail.xhtml?id=" + order.getId());
			securitytInfo.setCreateUser(order.getSecurity().getCreateUser());
			securitytInfo.setCreation(new Date());
			securitytInfo.setValid(Valid.ON);
			noti.setSecurity(securitytInfo);
			list.add(noti);
			// Notify Seller
			noti = new Notification();
			noti.setTitle("Sale " + order.getStatus().toString());
			noti.setDescription("Your sale order no [" + order.getId() + "] is " + order.getStatus().toString());
			noti.setNotiURL("/member/sale-history-detail.xhtml?id=" + order.getId());
			securitytInfo = new SecurityInfo();
			securitytInfo.setCreateUser(order.getSecurity().getCreateUser());
			securitytInfo.setCreation(new Date());
			securitytInfo.setValid(Valid.ON);
			noti.setSecurity(securitytInfo);
			list.add(noti);
			break;
		}

		return list;
	}

	public void update(Order order) {
		repo.update(order);
	}

	public Order findById(long id) {
		return repo.findById(id);
	}

	@Override
	public List<Order> getAll() {
		return repo.find(null, null);
	}

	@Override
	public List<Order> findByStatus(Status status, Date dateFrom, Date dateTo) {
		return findOrderByParam(status, dateFrom, dateTo, 0, 0);
	}

	@Override
	public List<Order> findByBuyer(Status status, Date dateFrom, Date dateTo, long buyerId) {
		return findOrderByParam(status, dateFrom, dateTo, buyerId, 0);
	}

	@Override
	public List<Order> findBySeller(Status status, Date dateFrom, Date dateTo, long sellerId) {
		return findOrderByParam(status, dateFrom, dateTo, 0, sellerId);
	}

	private List<Order> findOrderByParam(Status status, Date dateFrom, Date dateTo, long buyerId, long sellerId) {

		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		if (null != status) {
			sb.append("t.status= :status ");
			params.put("status", status);
		}

		if (null != dateFrom) {
			if (!params.isEmpty()) {
				sb.append("and ");
			}
			sb.append("t.orderDate >= :dateFrom ");
			params.put("dateFrom", dateFrom);
		}

		if (null != dateTo) {
			if (!params.isEmpty()) {
				sb.append("and ");
			}
			sb.append("t.orderDate <= :dateTo ");
			params.put("dateTo", dateTo);
		}
		if (0 != buyerId) {
			if (!params.isEmpty()) {
				sb.append("and ");
			}
			sb.append("t.buyer.id = :buyerId ");
			params.put("buyerId", buyerId);
		}
		if (0 != sellerId) {
			if (!params.isEmpty()) {
				sb.append("and ");
			}
			sb.append("t.item.owner.id = :sellerId ");
			params.put("sellerId", sellerId);
		}
		return repo.find(params.size() == 0 ? null : sb.toString(), params.size() == 0 ? null : params);
	}
}