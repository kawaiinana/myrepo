package com.opm.shop.service.imp;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Category;
import com.opm.shop.entity.Item;
import com.opm.shop.repo.ItemRepo;
import com.opm.shop.service.ItemServiceLocal;

@Stateless
public class ItemService implements ItemServiceLocal {

	@Inject
	private ItemRepo repo;

	public void save(Item item) {
		repo.persit(item);
	}

	public void update(Item item) {
		repo.update(item);
	}

	@Override
	public List<Item> search(String keyword) {
		return repo.findBy(null, keyword);
	}

	@Override
	public List<Item> getAll() {
		return repo.find(null, null);
	}

	@Override
	public List<Item> findByCategory(Category category) {
		return null;
	}

	@Override
	public Item findById(long id) {
		Item item = repo.findById(id);
		item.getSize();
		item.getColor();
		item.getCountry();
		item.getState();
		item.getPrices();
		return item;
	}
	
	@Override
	public List<Item> search(Category third, Category second, Category first) {
		
		StringBuffer sb= new StringBuffer();
		Map<String, Object> params = new HashMap<>();
		
		if(null != third) {
			sb.append("t.category.id = :cat");
			params.put("cat", third.getId());
		} else if (null != second) {
			sb.append("t.category.id = :cat or t.category.parent.id = :cat");
			params.put("cat", second.getId());
		} else if (null != first) {
			sb.append("t.category.parent.parent.id = :cat or t.category.parent.id = :cat or t.category.id = :cat");
			params.put("cat", first.getId());
		}
		
		return repo.find(params.size() == 0? null: sb.toString(),params.size() == 0? null: params);
	}

	@Override
	public List<Item> find(int categoryId, String keyword) {
		StringBuffer stb = new StringBuffer();
		Map<String,Object> params = new HashMap<>();
		
		if( categoryId > 0){
			stb.append("t.category.id = :catId");
			params.put("catId", categoryId);
		}
		else if ( null!= keyword && !keyword.isEmpty()) {
			stb.append("t.name like :keyword");
			params.put("keyword",keyword.concat("%"));
		}
		return repo.find(params.size() == 0? null: stb.toString(),params.size() == 0? null: params);
		
	}

}