package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Category;
import com.opm.shop.entity.Item;
import com.opm.shop.service.ItemServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class ItemListBean implements Serializable {

	private List<Item> items;

	@Inject
	private ItemServiceLocal service;

	private Account loginUser ;

	@Named("categories")
	@Inject
	private List<Category> firstCategories;
	private List<Category> secondCategories;
	private List<Category> thirdCategories;

	private Category first;
	private Category second;
	private Category third;

	@PostConstruct
	public void init() {
		items = new ArrayList<>();
		first = firstCategories.isEmpty() ? null : firstCategories.get(0);
		changeFirst();
		search();
	}

	public void search() {
		items.clear();
		items.addAll(service.search(third, second, first));
	}

	public void changeFirst() {

		if (first == null) {
			secondCategories.clear();
			thirdCategories.clear();
		} else {
			secondCategories = first.getChildren();
			if (secondCategories.size() > 0) {
				second = secondCategories.get(0);
			}
			changeSecond();
		}
	}

	public void changeSecond() {

		if (second == null) {
			third = null;
			thirdCategories.clear();
		} else {
			thirdCategories = second.getChildren();
		}

	}

	public List<Category> getFirstCategories() {
		return firstCategories;
	}

	public void setFirstCategories(List<Category> firstCategories) {
		this.firstCategories = firstCategories;
	}

	public List<Category> getSecondCategories() {
		return secondCategories;
	}

	public void setSecondCategories(List<Category> secondCategories) {
		this.secondCategories = secondCategories;
	}

	public List<Category> getThirdCategories() {
		return thirdCategories;
	}

	public void setThirdCategories(List<Category> thirdCategories) {
		this.thirdCategories = thirdCategories;
	}

	public Category getFirst() {
		return first;
	}

	public void setFirst(Category first) {
		this.first = first;
	}

	public Category getSecond() {
		return second;
	}

	public void setSecond(Category second) {
		this.second = second;
	}

	public Category getThird() {
		return third;
	}

	public void setThird(Category third) {
		this.third = third;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public List<Item> search(Category category, String keyword) {
		return null;
	}

	public Account getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(Account loginUser) {
		this.loginUser = loginUser;
	}


}