package com.opm.shop.controller.admin;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Country;
import com.opm.shop.entity.State;
import com.opm.shop.service.StateServiceLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class StateBean implements Serializable{

	private List<State> states;
	private Country country;
	private State state;

	@Inject
	private StateServiceLocal service;

	@PostConstruct
	private void init() {
		states = service.findAll();
		search();
	}

	public void search() {	
		states = service.findByCountry(country);
	}

	public String delete(State state) {
		state.setDeleteFlag(true);
		service.save(state);
		return "";
	}

	public List<State> getStates() {
		return states;
	}

	public void setStates(List<State> states) {
		this.states = states;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

	
}