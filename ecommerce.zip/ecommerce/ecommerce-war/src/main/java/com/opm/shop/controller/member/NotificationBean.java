package com.opm.shop.controller.member;

public class NotificationBean {

    
    public NotificationBean() {
    }

  //  private void notification;

   
    public void save() {
    }

}