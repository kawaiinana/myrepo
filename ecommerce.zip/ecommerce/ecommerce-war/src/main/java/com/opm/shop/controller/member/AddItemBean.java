package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.flow.FlowScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.controller.admin.BrandBean;
import com.opm.shop.entity.Account;
import com.opm.shop.entity.CommissionRate;
import com.opm.shop.entity.Country;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Item.Status;
import com.opm.shop.entity.Price;
import com.opm.shop.entity.State;
import com.opm.shop.service.AddItemServiceLocal;
import com.opm.shop.service.CommissionRateLocal;

@SuppressWarnings("serial")
@Named
@FlowScoped("product")
public class AddItemBean implements Serializable {

	public AddItemBean() {
	}

	private List<CommissionRate> rateList;

	@Inject
	private BrandBean brandBean;

	private CommissionRate commissionRate;

	@Inject
	private AddItemServiceLocal service;

	@Inject
	private CommissionRateLocal rateService;

	@Inject
	private ItemListBean itemListBean;

	private Set<State> selectedState;

	private Set<Country> selectedCountry;

	private Set<Price> prices;
	
	@Named
	@Inject
	private Account loginUser;

	private Item item;

	@PostConstruct
	public void init() {
		item = new Item();
		selectedState = new LinkedHashSet<>();
		selectedCountry = new LinkedHashSet<>();
		prices = new LinkedHashSet<>();
	}

	public void calRate() {
		/*
		 * rateList = rateService.calculateRate(commissionRate.getAmountFrom(),
		 * commissionRate.getAmountTo(), commissionRate.getRate());
		 */ 
		item.setPrices(getPrices());
		System.out.println(item.getPrices());
	}

	public String save() {
		if (item.getSize() != null) {
			System.out.println(item.getName());
			System.out.println(item.getDescription());
			System.out.println(item.getColor());
			System.out.println(item.getSize());
			System.out.println(item.getPrice());
			System.out.println(getSelectedCountry());
		}
		item.setImage("//");
		item.setStatus(Status.Available);
		item.setCountry(selectedCountry);
		item.setPrices(getPrices());
		item.setPrices(prices);
		service.save(item);
		item = new Item();
		return "/member/product-listing.xhtml?faces-redirect=true";
	}

	public Account getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(Account loginUser) {
		this.loginUser = loginUser;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public List<CommissionRate> getRateList() {
		return rateList;
	}

	public void setRateList(List<CommissionRate> rateList) {
		this.rateList = rateList;
	}

	public CommissionRate getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(CommissionRate commissionRate) {
		this.commissionRate = commissionRate;
	}

	public ItemListBean getItemListBean() {
		return itemListBean;
	}

	public void setItemListBean(ItemListBean itemListBean) {
		this.itemListBean = itemListBean;
	}

	public BrandBean getBrandBean() {
		return brandBean;
	}

	public void setBrandBean(BrandBean brandBean) {
		this.brandBean = brandBean;
	}

	public Set<State> getSelectedState() {
		return selectedState;
	}

	public void setSelectedState(Set<State> selectedState) {
		this.selectedState = selectedState;
	}

	public Set<Country> getSelectedCountry() {
		return selectedCountry;
	}

	public void setSelectedCountry(Set<Country> selectedCountry) {
		this.selectedCountry = selectedCountry;
	}

	public Set<Price> getPrices() {
		return prices;
	}

	public void setPrices(Set<Price> prices) {
		this.prices = prices;
	}
}
