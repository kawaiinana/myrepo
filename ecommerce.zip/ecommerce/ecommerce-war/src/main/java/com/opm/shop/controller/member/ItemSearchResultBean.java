package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Item;
import com.opm.shop.service.ItemServiceLocal;

@Named
@RequestScoped
@SuppressWarnings("serial")
public class ItemSearchResultBean implements Serializable {

	private List<Item> items;
	private int categoryId;
	private String keyword;
	private String catId;

	@Inject
	private ItemServiceLocal service;

	@PostConstruct
	public void init() {
		keyword = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("keyword");
		catId =  FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		if (keyword == null)
			keyword = "";
		if(catId == null)
			catId = "";
		else categoryId = Integer.parseInt(catId);
		System.out.println("Search Keyword = ");
		System.out.println(keyword);
		System.out.println(categoryId);
		items = service.find(categoryId, keyword);
		//System.out.println(items.size());

	}

	public String search() {
		return "/member/product-search-result.xhtml?faces-redirect=true&keyword="+keyword+"&id="+categoryId;
	}

	public List<Item> getItems() {
		return items;
	}

	public void setItems(List<Item> items) {
		this.items = items;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	

}