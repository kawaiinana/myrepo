package com.opm.shop.common;

import java.io.IOException;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;
import javax.servlet.http.Part;

@ApplicationScoped
public class imageFileProducer {
	private Part file;
	private String path;

	@Named
	@Produces
	private String imgurl;

	@Named
	@Produces
	private String imgFilePath;

	@PostConstruct
	private void init() {
		imgurl = System.getProperty("ecommerce-war.image_url");
		imgFilePath = System.getProperty("ecommerce-war.img_file_path");
	}

	public void updoad() {
		try {
			if (null != path) {
				String fileName = file.getSubmittedFileName();
				System.out.println(fileName);
				String[] array = fileName.split("\\.");
				String extension = array[array.length - 1];
				path = String.format("%d.%s", new Date().getTime(), extension);

				file.write(imgFilePath.concat(path));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public Part getFile() {
		return file;
	}

	public void setFile(Part file) {
		this.file = file;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getImgurl() {
		return imgurl;
	}

	public void setImgurl(String imgurl) {
		this.imgurl = imgurl;
	}

	public String getImgFilePath() {
		return imgFilePath;
	}

	public void setImgFilePath(String imgFilePath) {
		this.imgFilePath = imgFilePath;
	}

}
