package com.opm.shop.controller.member;

import java.io.Serializable;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Member;
import com.opm.shop.service.MemberServiceLocal;

@SuppressWarnings("serial")
@ViewScoped
@Named
public class ProfileBean implements Serializable{

	@Inject 
	@Named
	private Member loginMember;
	
	@Inject
	private MemberServiceLocal service;
	
	public String updateProfile(){
		
		service.update(loginMember);
		return "/member/my-profile?faces-redirect=true";
	}
	
}
