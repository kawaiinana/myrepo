package com.opm.shop.controller.member;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Address;
import com.opm.shop.entity.Member.Status;
import com.opm.shop.service.MemberServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MemberDetailBean implements Serializable {

	public MemberDetailBean() {
	}

	@Inject
	private MemberServiceLocal service;
	
	private Address member;
	// private Gender gender;

	@PostConstruct
	public void init() {
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		member = service.findByMember(Long.parseLong(str));
	}
	
	public void ban() {
		member.getMember().setStatus(Status.Ban);
		service.update(member.getMember());
	}

	public String buy() {
		return "";
	}

	public Address getMember() {
		return member;
	}

	public void setMember(Address address) {
		this.member = address;
	}
	
}