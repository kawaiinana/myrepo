package com.jdc.sec.bean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

import com.opm.sec.entity.Member;
import com.opm.sec.entity.Member.Role;
import com.opm.sec.service.MemberService;

@Model
public class MemberBeans {

	private Role role;
	private String name;
	private List<Member> members;
	
	@Inject
	private MemberService service;
	
	@PostConstruct
	private void postConstruct() {
		role = Role.Member;
		search();
	}
	
	public String search() {
		members = service.find(role, name);
		return "";
	}
	
	public List<Member> getMembers() {
		return members;
	}
	public void setMembers(List<Member> members) {
		this.members = members;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
