package com.jdc.sec.resources;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;
import javax.enterprise.event.Event;
import javax.enterprise.event.Observes;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.sec.entity.LoginLog;
import com.opm.sec.entity.LoginLog.Type;
import com.opm.sec.entity.Member;
import com.opm.sec.service.MemberService;

@SessionScoped
@SuppressWarnings("serial")
public class LoginUserProducer implements Serializable {

	@Named
	@Produces
	private Member loginUser;
	
	@Inject
	private MemberService service;
	
	@Inject
	private Event<LoginLog> logEvent;
	
	public void load(@Observes String loginId) {
		loginUser = service.find(loginId);
		LoginLog log = new LoginLog();
		log.setMember(loginUser);
		log.setType(Type.Login);
		logEvent.fire(log);
	}
	
	public void logout(@Observes Type type) {
		LoginLog log = new LoginLog();
		log.setMember(loginUser);
		log.setType(type);
		logEvent.fire(log);
	}
}
