package com.jdc.sec.bean;

import javax.enterprise.event.Event;
import javax.enterprise.inject.Model;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import com.opm.sec.entity.LoginLog.Type;
import com.opm.sec.entity.Member;
import com.opm.sec.entity.Member.Role;
import com.opm.sec.service.MemberService;

@Model
public class SecurityBean {

	private String name;
	private String login;
	private String password;
	
	@Inject
	private MemberService service;
	
	@Inject
	private Event<String> loginEvent;
	@Inject
	private Event<Type> logOutEvent;
	
	public String login() {
		try {
			ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
			HttpServletRequest req = (HttpServletRequest) ctx.getRequest();
			
			req.login(login, password);
			
			loginEvent.fire(login);
			
			if(req.isUserInRole("Admin")) {
				return "/admin/home?faces-redirect=true";
			} else if (req.isUserInRole("Member")) {
				return "/member/home?faces-redirect=true";
			} else {
				FacesMessage m = new FacesMessage("Login Err", "You can not access this site!");
				FacesContext.getCurrentInstance().addMessage(null, m);
			}
			
		} catch (Exception e) {
			FacesMessage m = new FacesMessage("Login Err", "Please check your login id and password!");
			FacesContext.getCurrentInstance().addMessage(null, m);
		}
		return null;
	}
	
	public String signup() {
		
		Member member = new Member();
		member.setName(name);
		member.setLogin(login);
		member.setRole(Role.Member);
		member.setPassword(password);
		
		service.create(member);
		
		return login();
	}

	public String logout() {
		logOutEvent.fire(Type.Logout);
		FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
		return "/home?faces-redirect=true";
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
