package com.jdc.sec.converter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Named;

@Named
@RequestScoped
public class DateTimeConvert implements Converter{
	
	private DateFormat df;
	
	@PostConstruct
	private void postConstruct() {
		df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	}

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if(null != value) {
			return df.format(value);
		}
		return null;
	}

}
