package com.jdc.sec.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.sec.entity.Member;
import com.opm.sec.service.MemberService;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MemberEditBean implements Serializable {

	private Member member;
	
	@Inject
	private MemberService service;
	private boolean edit;
	
	public String save() {
		if(edit) {
			service.update(member);
		} else {
			service.create(member);
		}
		
		return "/admin/members?faces-redirect=true";
	}
	
	public boolean isEdit() {
		return edit;
	}

	public void setEdit(boolean edit) {
		this.edit = edit;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}
	
	@PostConstruct
	private void postConstruct() {
		
		member = new Member();
		
		ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
		String memberId = ctx.getRequestParameterMap().get("id");
		if(null != memberId) {
			member = service.find(memberId);
			edit = true;
		}
	}
}
