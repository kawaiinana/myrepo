package com.jdc.sec.resources;

import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;

import com.opm.sec.entity.Member.Role;

@ApplicationScoped
public class CommonResources {

	@Named
	@Produces
	public Role[] getRoles() {
		return Role.values();
	}
}
