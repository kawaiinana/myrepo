package com.jdc.sec.resources;

import java.util.Date;

import javax.enterprise.inject.Model;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.sec.entity.Member;
import com.opm.sec.entity.LoginLog;
import com.opm.sec.entity.LoginLog.Type;
import com.opm.sec.service.LogService;

@Model
public class LoginLogoutTimes {

	@Named
	@Inject
	private Member loginUser;
	
	@Inject
	private LogService service;
	
	@Named
	@Produces
	public Date getLastLogin() {
		LoginLog log = service.findLastLog(loginUser, Type.Login);
		if(null != log) {
			return log.getLogTime();
		}
		return null;
	}
	
	@Named
	@Produces
	public Date getLastLogout() {
		LoginLog log = service.findLastLog(loginUser, Type.Logout);
		if(null != log) {
			return log.getLogTime();
		}
		return null;
	}
}
