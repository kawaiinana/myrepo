package com.opm.sec.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Temporal;
import static javax.persistence.TemporalType.TIMESTAMP;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Enumerated;

@Entity
@SuppressWarnings("serial")
@NamedQueries({
	@NamedQuery(name="LoginLog.findLastLog",
			query="select l from LoginLog l where l.member.login = :login and "
					+ "l.type = :type and l.logTime = (select max(l.logTime) from "
					+ "LoginLog l where l.member.login = :login and l.type = :type)")
})
public class LoginLog implements Serializable{
	
	public enum Type {Login, Logout}
	
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;
	@Temporal(TIMESTAMP)
	private Date logTime;
	@ManyToOne
	private Member member;
	@Enumerated
	private Type type;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public Date getLogTime() {
		return logTime;
	}
	public void setLogTime(Date logTime) {
		this.logTime = logTime;
	}
	public Member getMember() {
		return member;
	}
	public void setMember(Member member) {
		this.member = member;
	}
	public Type getType() {
		return type;
	}
	public void setType(Type type) {
		this.type = type;
	}
	
	@PrePersist
	private void prePersist() {
		logTime = new Date();
	}
}
