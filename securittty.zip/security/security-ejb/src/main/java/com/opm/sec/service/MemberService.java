package com.opm.sec.service;

import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.ejb.LocalBean;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.opm.sec.entity.Member;
import com.opm.sec.entity.Member.Role;
import com.opm.sec.utils.PasswordUtils;

@Stateless
@LocalBean
public class MemberService {

	@Resource
	private SessionContext ctx;

	@Inject
	private EntityManager em;

	public void create(Member member) {
		em.persist(member);
	}

	public void update(Member member) {
		em.merge(member);
	}

	public void changePass(String loginId, String pass, String newPass, String confPass) {
		Member member = em.find(Member.class, loginId);

		try {
			if (!member.getPassword().equals(PasswordUtils.encript(pass))) {
				// TODO
			}

			if (!newPass.equals(confPass)) {
				// TODO
			}

			member.setPassword(newPass);

		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	public void changeName(String loginId, String name) {
		try {
			Member member = em.find(Member.class, loginId);
			member.setName(name);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public Member find(String login) {
		return em.find(Member.class, login);
	}

	public List<Member> find(Role role, String name) {

		StringBuffer sb = new StringBuffer("select m from Member m where 1 = 1 ");
		Map<String, Object> params = new HashMap<>();

		if (null != role) {
			sb.append("and m.role = :role ");
			params.put("role", role);
		}

		if (null != name && !name.isEmpty()) {
			sb.append("and m.name like :name");
			params.put("name", name.concat("%"));
		}

		TypedQuery<Member> q = em.createQuery(sb.toString(), Member.class);

		for (String key : params.keySet()) {
			q.setParameter(key, params.get(key));
		}

		return q.getResultList();
	}
}
