package com.opm.sec.entity;

import java.io.Serializable;
import java.lang.String;
import java.security.NoSuchAlgorithmException;

import javax.persistence.*;

import com.opm.sec.utils.PasswordUtils;

import static javax.persistence.EnumType.STRING;

@Entity
public class Member implements Serializable {
	
	public enum Role {Admin, Member, Others}
	   
	@Id
	private String login;
	private String name;
	private String password;
	@Enumerated(STRING)
	private Role role;
	
	@Transient
	private boolean changePass;
	
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}

	private static final long serialVersionUID = 1L;

	public Member() {
		super();
	}   
	public String getLogin() {
		return this.login;
	}

	public void setLogin(String login) {
		this.login = login;
	}   
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}   
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
		this.changePass = true;
	}
	
	@PreUpdate
	@PrePersist
	private void encript() {
		try {
			if(changePass) {
				password = PasswordUtils.encript(password);
			}
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
	}
   
}
