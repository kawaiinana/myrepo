package com.opm.sec.service;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import com.opm.sec.entity.Post;

@Local
@Stateless
public class PostService {

	@Inject
	private EntityManager em;
	
	public Post find(long id) {
		return em.find(Post.class, id);
	}

	public void save(Post post) {
		if(post.getId() > 0) {
			em.merge(post);
		} else {
			em.persist(post);
		}
	}


}
