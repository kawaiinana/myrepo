package com.opm.sec.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Lob;
import javax.persistence.Temporal;
import static javax.persistence.TemporalType.TIMESTAMP;
import javax.persistence.ManyToOne;
import javax.persistence.PrePersist;

@Entity
@SuppressWarnings("serial")
public class Comment implements Serializable {

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;
	@Lob
	private String comment;
	@Temporal(TIMESTAMP)
	private Date creation;
	@ManyToOne
	private Member owner;
	@ManyToOne
	private Post post;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Date getCreation() {
		return creation;
	}

	public void setCreation(Date creation) {
		this.creation = creation;
	}

	public Member getOwner() {
		return owner;
	}

	public void setOwner(Member owner) {
		this.owner = owner;
	}

	public Post getPost() {
		return post;
	}

	public void setPost(Post post) {
		this.post = post;
	}
	
	@PrePersist
	private void prePersist() {
		creation = new Date();
	}
}
