package com.opm.sec.service;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import com.opm.sec.entity.LoginLog;
import com.opm.sec.entity.LoginLog.Type;
import com.opm.sec.entity.Member;

@Local
@Stateless
public class LogService {

	@Inject
	private EntityManager em;
	
	public void outLog(@Observes LoginLog log) {
		em.persist(log);
	}
	
	public LoginLog findLastLog(Member member, Type type) {
		
		List<LoginLog> logs = em.createNamedQuery("LoginLog.findLastLog", LoginLog.class)
				.setParameter("login", member.getLogin())
				.setParameter("type", type)
				.getResultList();
		
		System.out.println(logs.size());
		
		if(logs.size() > 0) {
			System.out.println(logs.get(0).getLogTime());
			return logs.get(0);
		}
		
		return null;
	}
}
