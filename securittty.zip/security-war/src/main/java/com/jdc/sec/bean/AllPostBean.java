package com.jdc.sec.bean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;

import com.opm.sec.entity.Post;
import com.opm.sec.service.PostService;

@Model
public class AllPostBean {

	private List<Post> posts;
	
	@Inject
	private PostService service;
	
	@PostConstruct
	private void init() {
		posts = service.getAll();
	}
	
	public List<Post> getPosts() {
		return posts;
	}
	
	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}
}
