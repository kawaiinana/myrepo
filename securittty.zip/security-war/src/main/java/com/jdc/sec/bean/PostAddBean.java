package com.jdc.sec.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.jdc.sec.resources.ParamUtils;
import com.opm.sec.entity.Member;
import com.opm.sec.entity.Post;
import com.opm.sec.service.PostService;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class PostAddBean implements Serializable{

	private Post post;
	private boolean edit;
	
	@Named("loginUser")
	@Inject
	private Member member;
	
	@Inject
	private PostService service;
	
	@Inject
	private ParamUtils params;

	public boolean isEdit() {
		return edit;
	}

	public void setEdit(boolean edit) {
		this.edit = edit;
	}

	public Post getPost() {
		return post;
	}

	public void setPost(Post post) {
		this.post = post;
	}
	
	@PostConstruct
	private void postConstruct() {
		post = new Post();
		
		String postId = params.get("id");
		
		if(null != postId) {
			post = service.find(Long.parseLong(postId));
			edit = true;
		}
	}
	
	public String save() {
		
		if(post.getId() == 0) {
			post.setOwner(member);
		}
		service.save(post);
		return "/public/post?faces-redirect=true&id=" + post.getId();
	}
	
	
}
