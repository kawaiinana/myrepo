package com.jdc.sec.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.jdc.sec.resources.ParamUtils;
import com.opm.sec.entity.Message;
import com.opm.sec.entity.Message.Status;
import com.opm.sec.service.MessageService;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class MessageDetailsBean implements Serializable {

	private Message message;
	private List<Message> messages;
	
	@Inject
	private MessageService service;
	
	@Inject
	private ParamUtils params;
	
	@Inject
	private Event<Message> readEvent;
	
	@PostConstruct
	private void init() {
		String id = params.get("id");
		
		messages = new ArrayList<>();
		
		if(null != id) {
			message = service.find(Long.parseLong(id));
			
			if(message.getStatus() == Status.New) {
				message.setStatus(Status.Read);
				readEvent.fire(message);
			}
			
			Message parent = message.getParent();
			while(parent != null) {
				messages.add(parent);
				parent = parent.getParent();
			}
		}
		
	}
	
	public String delete() {
		service.delete(message);
		return "/member/messages?faces-redirect=true";
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public List<Message> getMessages() {
		return messages;
	}

	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}
	
}
