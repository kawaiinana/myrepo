package com.jdc.sec.bean;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.sec.entity.Member;
import com.opm.sec.entity.Post;
import com.opm.sec.service.PostService;

@Model
public class MyPostBean {

	private List<Post> posts;
	
	@Named
	@Inject
	private Member loginUser;
	
	@Inject
	private PostService service;

	public List<Post> getPosts() {
		return posts;
	}

	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}
	
	@PostConstruct
	private void init() {
		posts = service.find(loginUser);
	}
}
