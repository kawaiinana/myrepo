package com.jdc.sec.bean;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.jdc.sec.resources.ParamUtils;
import com.opm.sec.entity.Member;
import com.opm.sec.entity.Message;
import com.opm.sec.service.MemberService;
import com.opm.sec.service.MessageService;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MessageEditBean implements Serializable{

	private Message message;
	
	private boolean reply;
	
	@Inject
	private MessageService service;
	@Inject
	private MemberService memService;
	@Inject
	private ParamUtils param;
	
	@Named
	@Inject
	private Member loginUser;
	
	@PostConstruct
	private void init() {
		message = new Message();
		
		String id =  param.get("id");
		if(null != id) {
			Message parent = service.find(Long.parseLong(id));
			message.setParent(parent);
			String to = parent.getSendFrom();
			if(to.equalsIgnoreCase("system")) {
				to = "admin";
			}
			message.setSendTo(memService.find(to));
			message.setTitle("Re : " + parent.getTitle());
			reply = true;
		}
		
		String to = param.get("to");
		if(null != to) {
			if(to.equalsIgnoreCase("system")) {
				to = "admin";
			}
			message.setSendTo(memService.find(to));
		}
		
		message.setSendFrom(loginUser.getLogin());
	}
	
	public String send() {
		service.create(message);
		return "/member/messages?faces-redirect";
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public boolean isReply() {
		return reply;
	}

	public void setReply(boolean reply) {
		this.reply = reply;
	}
	
	
}
