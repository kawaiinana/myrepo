package com.jdc.sec.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.jdc.sec.resources.ParamUtils;
import com.opm.sec.entity.Comment;
import com.opm.sec.entity.Member;
import com.opm.sec.entity.Post;
import com.opm.sec.service.CommentService;
import com.opm.sec.service.PostService;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class PostDetailsBean implements Serializable {

	private Post post;
	private Comment comment;
	private List<Comment> comments;
	
	@Inject
	private PostService service;
	@Inject
	private CommentService cmtService;
	
	@Named
	@Inject
	private Member loginUser;
	
	@Inject
	private ParamUtils params;
	
	@PostConstruct
	private void init() {
		String id = params.get("id");
		comment = new Comment();
		
		if(null != id) {
			post = service.find(Long.parseLong(id));
			comments = service.getComments(post);
		}
	}
	
	public void update(Comment comment){
		service.update(comment);
	}
	
	public void addComment() {
		comment.setPost(post);
		comment.setOwner(loginUser);
		cmtService.add(comment);
		
		comment = new Comment();
		comments = service.getComments(post);
	}

	public String deleteComment(Comment comment) {
		cmtService.delete(comment);
		return "/public/post?faces-redirect=true&id="+comment.getPost().getId();
	}
	
	public Post getPost() {
		return post;
	}

	public void setPost(Post post) {
		this.post = post;
	}

	public Comment getComment() {
		return comment;
	}

	public void setComment(Comment comment) {
		this.comment = comment;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
}
