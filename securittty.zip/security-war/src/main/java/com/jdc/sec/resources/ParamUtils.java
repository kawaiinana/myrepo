package com.jdc.sec.resources;

import java.io.Serializable;

import javax.faces.context.FacesContext;

@SuppressWarnings("serial")
public class ParamUtils implements Serializable {

	public String get(String name) {
		return FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get(name);
	}
}
