package com.jdc.sec.resources;

import javax.enterprise.context.RequestScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.sec.entity.Member;
import com.opm.sec.service.MessageService;
import com.opm.sec.service.PostService;

@RequestScoped
public class SummaryResources {
	
	@Named
	@Inject
	private Member loginUser;
	
	@Inject
	private PostService postService;
	@Inject
	private MessageService messageService;

	@Named("postCount")
	@Produces
	public long getMyPostCount() {
		return postService.getPostCount(loginUser);
	}
	
	@Named("commentCount")
	@Produces
	public long getMyCommentCount() {
		return postService.getCommentCount(loginUser);
	}
	
	@Named("messageCount")
	@Produces
	public long getMyMessageCount() {
		return messageService.getMessageCount(loginUser);
	}
}
