package com.jdc.sec.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.sec.entity.Member;
import com.opm.sec.entity.Message;
import com.opm.sec.entity.Message.Status;
import com.opm.sec.service.MessageService;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MessagesBean implements Serializable {

	@Named
	@Inject
	private Member loginUser;
	
	@Inject
	private MessageService service;
	
	private List<Message> messages;
	
	@PostConstruct
	private void init() {
		messages = service.find(loginUser, Status.New);
	}

	public List<Message> getMessages() {
		return messages;
	}

	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}
	
	public void load(boolean send, Status status) {
		if(send) {
			this.messages = service.findSend(loginUser, status);
		} else {
			this.messages = service.find(loginUser, status);
		}
	}
	
}
