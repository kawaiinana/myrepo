package com.jdc.sec.bean;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.sec.entity.Comment;
import com.opm.sec.entity.Member;
import com.opm.sec.service.CommentService;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CommentsBean implements Serializable {

	@Named
	@Inject
	private Member loginUser;
	private List<Comment> comments;
	
	@Inject
	private CommentService service;
	
	@PostConstruct
	private void init() {
		comments = service.find(loginUser);
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}
	
	public void update(Comment comment){
		service.update(comment);
	}
	
	public String delete(Comment comment) {
		service.delete(comment);
		return "/member/comments?faces-redirect=true";
	}
	
}
