package com.opm.sec.service;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import com.opm.sec.entity.Comment;
import com.opm.sec.entity.Member;
import com.opm.sec.entity.Post;

@Local
@Stateless
public class PostService {

	@Inject
	private EntityManager em;
	
	public Post find(long id) {
		return em.find(Post.class, id);
	}

	public void save(Post post) {
		if(post.getId() > 0) {
			em.merge(post);
		} else {
			em.persist(post);
		}
	}

	@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
	public List<Comment> getComments(Post post) {
		return em.createNamedQuery("Comment.findByPost", Comment.class)
				.setParameter("postId", post.getId()).getResultList();
	}

	public List<Post> find(Member loginUser) {
		return em.createNamedQuery("Post.findByOwner", Post.class)
				.setParameter("login", loginUser.getLogin())
				.getResultList();
	}

	public List<Post> getAll() {
		return em.createNamedQuery("Post.getAll", Post.class).getResultList();
	}

	public long getPostCount(Member member) {
		return em.createNamedQuery("Post.getCountByUser", Long.class)
				.setParameter("login", member.getLogin())
				.getSingleResult();
	}

	public long getCommentCount(Member member) {
		return em.createNamedQuery("Comment.getCountByUser", Long.class)
				.setParameter("login", member.getLogin())
				.getSingleResult();
	}

	public void update(Comment comment) {

		em.merge(comment);
	}


}
