package com.opm.sec.service;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.event.Observes;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import com.opm.sec.entity.Member;
import com.opm.sec.entity.Message;
import com.opm.sec.entity.Message.Status;

@Local
@Stateless
public class MessageService {
	
	@Inject
	private EntityManager em;

	public long getMessageCount(Member loginUser) {
		return em.createNamedQuery("Message.findCountByUser", Long.class)
				.setParameter("login", loginUser.getLogin())
				.setParameter("status", Status.New)
				.getSingleResult();
	}

	public List<Message> find(Member loginUser, Status status) {
		return em.createNamedQuery("Message.findByUser", Message.class)
				.setParameter("login", loginUser.getLogin())
				.setParameter("status", status)
				.getResultList();
	}

	public List<Message> findSend(Member loginUser, Status status) {
		return em.createNamedQuery("Message.findBySendUser", Message.class)
				.setParameter("login", loginUser.getLogin())
				.setParameter("status", status)
				.getResultList();
	}

	public void create(Message message) {
		em.persist(message);
	}

	public Message getLastNewMessage(Member m, String title, String system) {
		List<Message> list = em.createNamedQuery("Message.getLastNewMessage", Message.class)
				.setParameter("login", m.getLogin())
				.setParameter("sendFrom", system)
				.setParameter("title", title)
				.setParameter("status", Status.New)
				.getResultList();
		
		if(list.size() > 0) {
			return list.get(0);
		}
		
		return null;
	}

	public Message find(long id) {
		return em.find(Message.class, id);
	}
	
	public void setRead(@Observes Message message) {
		em.merge(message);
	}

	public void delete(Message message) {
		em.remove(em.find(Message.class, message.getId()));
	}


}
