package com.opm.sec.service;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import com.opm.sec.entity.Comment;
import com.opm.sec.entity.Member;

@Local
@Stateless
public class CommentService {
	
	@Inject
	private EntityManager em;

	public List<Comment> find(Member loginUser) {
		return em.createNamedQuery("Comment.findByOwner", Comment.class)
				.setParameter("login", loginUser.getLogin())
				.getResultList();
	}

	public void delete(Comment comment) {
		em.remove(em.find(Comment.class, comment.getId()));
	}

	public void add(Comment comment) {
		em.persist(comment);
	}

	public void update(Comment comment) {

		em.merge(comment);
	}

}
