package com.opm.sec.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import static javax.persistence.TemporalType.TIMESTAMP;
import javax.persistence.Enumerated;

@Entity
@NamedQueries({
	@NamedQuery(name="Message.findCountByUser", query="select count(m) from Message m where m.sendTo.login = :login and m.status = :status"),
	@NamedQuery(name="Message.findByUser", query="select m from Message m where m.sendTo.login = :login and m.status = :status"),
	@NamedQuery(name="Message.getLastNewMessage", query="select m from Message m where m.sendTo.login = :login and m.status = :status and m.sendFrom = :sendFrom and m.title = :title"),
	@NamedQuery(name="Message.findBySendUser", query="select m from Message m where m.sendFrom = :login and m.status = :status")
})
@SuppressWarnings("serial")
public class Message implements Serializable {

	public enum Status {New, Read}
	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;
	private String title;
	@Lob
	private String body;
	@Temporal(TIMESTAMP)
	private Date sendDate;
	@ManyToOne
	private Member sendTo;
	private String sendFrom;
	@ManyToOne
	private Message parent;
	
	@OneToMany(orphanRemoval = true)
	private List<Message> replyMessages;
	
	@Enumerated
	private Status status;
	
	@PrePersist
	private void prePersist() {
		status = Status.New;
		sendDate = new Date();
	}
	
	public List<Message> getReplyMessages() {
		return replyMessages;
	}

	public void setReplyMessages(List<Message> replyMessages) {
		this.replyMessages = replyMessages;
	}

	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public Date getSendDate() {
		return sendDate;
	}
	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}
	public Member getSendTo() {
		return sendTo;
	}

	public void setSendTo(Member sendTo) {
		this.sendTo = sendTo;
	}

	public String getSendFrom() {
		return sendFrom;
	}
	public void setSendFrom(String sendFrom) {
		this.sendFrom = sendFrom;
	}

	public Message getParent() {
		return parent;
	}

	public void setParent(Message parent) {
		this.parent = parent;
	}
	
}
