package com.opm.sec.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.PrePersist;
import javax.persistence.Temporal;
import static javax.persistence.TemporalType.TIMESTAMP;

@Entity
@SuppressWarnings("serial")
@NamedQueries({
	@NamedQuery(name="Post.findByOwner", query="select p from Post p where p.owner.login = :login"),
	@NamedQuery(name="Post.getAll", query="select p from Post p"),
	@NamedQuery(name="Post.getCountByUser", query="select count(p) from Post p where p.owner.login = :login")
})
public class Post implements Serializable {

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;
	private String title;
	@Lob
	private String body;
	@ManyToOne
	private Member owner;
	@Temporal(TIMESTAMP)
	private Date creation;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public Member getOwner() {
		return owner;
	}
	public void setOwner(Member owner) {
		this.owner = owner;
	}
	public Date getCreation() {
		return creation;
	}
	public void setCreation(Date creation) {
		this.creation = creation;
	}
	
	@PrePersist
	private void prePersist() {
		creation = new Date();
	}
}
