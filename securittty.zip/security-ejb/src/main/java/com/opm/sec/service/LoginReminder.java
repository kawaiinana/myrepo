package com.opm.sec.service;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.sec.entity.LoginLog;
import com.opm.sec.entity.LoginLog.Type;
import com.opm.sec.entity.Member;
import com.opm.sec.entity.Member.Role;
import com.opm.sec.entity.Message;

@Local
@Stateless
public class LoginReminder {
	
	@Inject
	private MemberService memService;
	
	@Inject
	private LogService logService;
	
	@Inject
	private MessageService mesService;
	
	private static final String TITLE = "Remind to Login";
	private static final String SYSTEM = "System";
	
	
	@Schedule(minute="*/5", hour="*")
	public void remindToUser() {
		
		// find members
		List<Member> members = memService.find(Role.Member, null);
		
		// iterate
		for(Member m : members) {
			// check member to last login time
			LoginLog lastLog = logService.findLastLog(m, Type.Login);
			
			if(isLongTimeToLogin(lastLog)) {
				// check is send 
				if(!isAlreadSend(m)) {
					// send message
					Message message = new Message();
					message.setSendFrom(SYSTEM);
					message.setTitle(TITLE);
					message.setBody("You didn't login for a long time. Please login again!");
					message.setSendTo(m);
					
					mesService.create(message);
				}
			}
		}
	}


	private boolean isAlreadSend(Member m) {
		return null != mesService.getLastNewMessage(m, TITLE, SYSTEM);
	}


	private boolean isLongTimeToLogin(LoginLog lastLog) {
		
		long maxTime = 1000 * 60 * 5;
		
		if(null != lastLog) {
			// define false
			long duration = new Date().getTime() - lastLog.getLogTime().getTime();
			return duration >= maxTime;
		}
		
		return true;
	}

}
