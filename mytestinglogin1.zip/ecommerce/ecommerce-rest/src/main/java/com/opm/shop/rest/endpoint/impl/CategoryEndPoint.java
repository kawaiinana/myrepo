package com.opm.shop.rest.endpoint.impl;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.opm.shop.entity.Category;
import com.opm.shop.service.CategoryServiceLocal;

@Path("/categories")
public class CategoryEndPoint {

	@Inject
	private CategoryServiceLocal service;

	@GET
	@Path("{id: \\d+}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response findById(@PathParam("id") int id) {
		Category category = service.findById(id);
		if (null != category) {
			return Response.ok(category).build();
		}
		return Response.status(Status.NOT_FOUND).entity("Category not found!").build();
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response findAll() {
		List<Category> categoryList = service.findAll();
		return Response.ok(categoryList).build();
	}

	@GET
	@Path("/findParents")
	@Produces(MediaType.APPLICATION_JSON)
	public Response findParents() {
		List<Category> categoryList = service.findParents();
		return Response.ok(categoryList).build();
	}
}
