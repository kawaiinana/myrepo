package com.opm.shop.rest.endpoint.impl;

import java.util.List;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.opm.shop.entity.Comment;
import com.opm.shop.rest.endpoint.BaseEndPoint;
import com.opm.shop.service.CommentServiceLocal;

@Path("/comments")
public class CommentEndPoint implements BaseEndPoint<Comment> {

	@Inject
	private CommentServiceLocal service;

	@Override
	public Response create(Comment comment) {
		try {
			service.save(comment);
			return Response.ok(comment).build();
		} catch (Exception e) {
			return Response.status(Status.NOT_IMPLEMENTED).entity("Comment upload fail!").build();
		}
	}

	@Override
	public Response update(Comment comment) {
		service.update(comment);
		return Response.ok(comment).build();
	}

	@Produces(MediaType.APPLICATION_JSON)
	@GET
	@Path("{id:\\d+}")
	public Response findByOrderId(@PathParam("id") long id) {
		List<Comment> comments = service.findByOrderId(id);
		return Response.ok(comments).build();
	}

}
