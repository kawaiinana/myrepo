$(window).scroll(function () {
    if ( $(window).scrollTop() >= ($('#content-wrapper').position().top + $('#content-wrapper').height()) - ($(window).height() + 50)) {
	 $('.nextBtn').click();
    }
});