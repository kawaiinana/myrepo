package com.opm.shop.common;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

@SuppressWarnings("serial")
@ManagedBean(name = "loginPageCode")
@SessionScoped
public class LoginPageCode implements Serializable {

	public String getFacebookUrlAuth() {
		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
		String sessionId = session.getId();
		String appId = "881523795333038";
		String redirectUrl = "http://localhost:8080/ecommerce-war/";
		String returnValue = "https://www.facebook.com/dialog/oauth?client_id=" + appId + "&redirect_uri=" + redirectUrl
				+ "&scope=email,user_birthday&state=" + sessionId;
		return returnValue;
	}

	public String getUserFromSession() {
		HttpSession session = (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false);
		String userName = (String) session.getAttribute("FACEBOOK_USER");
		if (userName != null) {
			System.out.println("This is user name" + userName);
			return "Hello " + userName;
		} else {
			return "";
		}
	}
}
