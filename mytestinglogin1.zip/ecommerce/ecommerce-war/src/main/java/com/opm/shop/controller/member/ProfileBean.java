package com.opm.shop.controller.member;

import java.io.IOException;
import java.io.Serializable;
import java.security.NoSuchAlgorithmException;
import java.util.Date;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.Part;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Member;
import com.opm.shop.service.AccountServiceLocal;
import com.opm.shop.service.AddressServiceLocal;
import com.opm.shop.service.MemberServiceLocal;
import com.opm.shop.utils.PasswordUtils;

@SuppressWarnings("serial")
@ViewScoped
@Named
public class ProfileBean implements Serializable {

	private Part file;
	private String path;
	private boolean agree=true;
	
	@NotNull
	@Pattern(regexp = "[a-zA-Z0-9]+",message="Must enter password")
	private String curPassword;
	
	@Size(min=8,message="Enter password of at least 8 digit")
	@NotNull
	@Pattern(regexp = "[a-zA-Z0-9]+",message="Must enter new password")
	private String newPassword;
	
	@Inject
	@Named
	private Account loginUser;
	
	@Inject
	@Named
	private Member loginMember;

	@Named
	@Inject
	private String imageFilePath;
	
	@Inject
	private AddressServiceLocal addService;

	@Inject
	private MemberServiceLocal memService;

	@Inject
	private AccountServiceLocal accService;
	
	@PostConstruct
	private void init(){
		curPassword = new String();
	}

	public void upload() {
		try {
			if (null != file) {
				String fileName = file.getSubmittedFileName();
				System.out.println(fileName);
				String[] array = fileName.split("\\.");
				String extension = array[array.length - 1];
				path = String.format("%d.%s", new Date().getTime(), extension);
				file.write(imageFilePath.concat(path));
				loginMember.setImage(path);
				memService.update(loginMember);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public String updateProfile() {
		if (agree == true) {
			memService.update(loginMember);
			if (addService.findByLoginMember(loginMember.getId()) == null) {
				return "/member/my-address?faces-redirect=true";
			} else {
				return "/member/member-home?faces-redirect=true";
			}
		}
		FacesMessage message = new FacesMessage("agree", "Please check term and service");
		FacesContext.getCurrentInstance().addMessage(null, message);

		return null;
	}

	public String updateAccount(String confirmPassword) {
		String currentPassword = new String();
		try {
			currentPassword = PasswordUtils.encript(curPassword);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		}
		if(!loginUser.getPassword().equals(currentPassword)){
			FacesMessage message = new FacesMessage("Your currrent passwrod is wrong!");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return "";
		}else if(!newPassword.equals(confirmPassword)){
			FacesMessage message = new FacesMessage("New password and confirm password must be the same!");
			FacesContext.getCurrentInstance().addMessage(null, message);
			return "";
		}else{
			loginUser.setPassword(newPassword);
			accService.accountUpdate(loginUser);
			
			Flash f= FacesContext.getCurrentInstance().getExternalContext().getFlash();
			f.put("email", loginUser.getEmail());
			f.put("password", newPassword);
			FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
			return "/dummy-login-page?faces-redirect=true";
		}		
	}
	
	public boolean isAgree() {
		return agree;
	}
	public void setAgree(boolean agree) {
		this.agree = agree;
	}

	public String getNewPassword() {
		return newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	
	public String getImageFilePath() {
		return imageFilePath;
	}

	public void setImageFilePath(String imageFilePath) {
		this.imageFilePath = imageFilePath;
	}

	public String getCurPassword() {
		return curPassword;
	}

	public void setCurPassword(String curPassword) {
		this.curPassword = curPassword;
	}
	
	public Member getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Member loginMember) {
		this.loginMember = loginMember;
	}

	public Part getFile() {
		return file;
	}

	public void setFile(Part file) {
		this.file = file;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
}
