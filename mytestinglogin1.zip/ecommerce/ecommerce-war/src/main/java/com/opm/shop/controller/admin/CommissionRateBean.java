package com.opm.shop.controller.admin;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.opm.shop.common.Pager;
import com.opm.shop.entity.CommissionRate;
import com.opm.shop.entity.CommissionRate.RateType;
import com.opm.shop.service.CommissionRateLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CommissionRateBean implements Serializable {

	private List<CommissionRate> comRateList;
	private CommissionRate commissionRate;

	@Temporal(TemporalType.TIMESTAMP)
	private Date refDate;

	private RateType type;

	private int maxItemSize = 10;

	private Pager pager;

	@Inject
	private CommissionRateLocal service;

	@PostConstruct
	public void init() {
		commissionRate = new CommissionRate();
		try {
			search(1);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String addRate() {
		try {
			service.save(commissionRate);
			comRateList.add(commissionRate);
			commissionRate = new CommissionRate();
			return "/admin/commission-rate.xhtml?faces-redirect=true";

		} catch (RuntimeException e) {
			FacesMessage message = new FacesMessage("AmountError", e.getCause().getMessage());
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		return "";
	}

	public String delete(CommissionRate c) {
		c.setDeleteFlag(true);
		service.delete(c);
		return "/admin/commission-rate.xhtml?faces-redirect=true";
	}

	public String update(CommissionRate c) {
		commissionRate = c;
		return "/admin/commission-rate.xhtml?faces-redirect=true";
	}

	public void search(int currentPage) {
		
		if(currentPage > 0) {
			Long totalSize = service.findCount(type, refDate);
			
			if((currentPage - 1) * maxItemSize <= totalSize) {
				pager = new Pager(totalSize.intValue(), currentPage, maxItemSize);
				
				comRateList = service.find(type, refDate, (currentPage - 1) * maxItemSize, maxItemSize);
			}
		}

	}

	public List<CommissionRate> getComRateList() {
		return comRateList;
	}

	public void setComRateList(List<CommissionRate> comRateList) {
		this.comRateList = comRateList;
	}

	public CommissionRate getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(CommissionRate commissionRate) {
		this.commissionRate = commissionRate;
	}

	public Date getRefDate() {
		return refDate;
	}

	public void setRefDate(Date refDate) {
		this.refDate = refDate;
	}

	public RateType getType() {
		return type;
	}

	public void setType(RateType type) {
		this.type = type;
	}

	public int getMaxItemSize() {
		return maxItemSize;
	}

	public void setMaxItemSize(int maxItemSize) {
		this.maxItemSize = maxItemSize;
	}

	public Pager getPager() {
		return pager;
	}

	public void setPager(Pager pager) {
		this.pager = pager;
	}

}
