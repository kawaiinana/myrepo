package com.opm.shop.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

@SuppressWarnings("serial")
public class FbConnection implements Serializable {
	public static final String FB_APP_ID = "881523795333038";
	public static final String FB_APP_SECRET = "761b80e4414917db313801d486203066";
	public static final String REDIRECT_URI = "http://localhost:8080/ecommerce-war/";

	private String accessToken = "";

	public String getFbAuthUrl() {
		String fbLoginUrl = "";
		try {
			fbLoginUrl = "http://www.facebook.com/dialog/oauth?" + "client_id=" + FbConnection.FB_APP_ID
					+ "&redirect_uri=" + URLEncoder.encode(FbConnection.REDIRECT_URI, "UTF-8") + "&scope=email";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fbLoginUrl;
	}

	public String getFbGraphUrl(String code) {
		String fbGraphUrl = "";
		try {
			fbGraphUrl = "https://graph.facebook.com/oauth/access_token?" + "client_id=" + FbConnection.FB_APP_ID
					+ "&redirect_uri=" + URLEncoder.encode(FbConnection.REDIRECT_URI, "UTF-8") + "&client_secret="
					+ FB_APP_SECRET + "&code=" + code;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fbGraphUrl;
	}

	public String getAccessToken(String code) {
		if (".".equals(accessToken)) {
			URL fbGraphUrl;
			try {
				fbGraphUrl = new URL(getFbGraphUrl(code));
			} catch (Exception e) {
				e.printStackTrace();
				throw new RuntimeException("Invalid code !" + e);
			}
			URLConnection fbConnection;
			StringBuffer b = null;
			try {
				fbConnection = fbGraphUrl.openConnection();
				BufferedReader in;
				in = new BufferedReader(new InputStreamReader(fbConnection.getInputStream()));
				String inputLine;
				b = new StringBuffer();
				while ((inputLine = in.readLine()) != null)
					b.append(inputLine + "\n");
				in.close();
			} catch (IOException e) {
				e.printStackTrace();
				throw new RuntimeException("Unable to connect facebook" + e);
			}

			accessToken = b.toString();
			if (accessToken.startsWith("{")) {
				throw new RuntimeException("ERROR: Access Token Invalid: " + accessToken);
			}
		}
		return accessToken;
	}
}
