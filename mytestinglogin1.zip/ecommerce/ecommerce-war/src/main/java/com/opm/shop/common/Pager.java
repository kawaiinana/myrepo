package com.opm.shop.common;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Pager implements Serializable {

	private int totalCount;
	private int currentPage;
	private int maxSize;

	private int lastPage;
	private int firstPage;

	public Pager(int totalCount, int currentPage, int maxSize) {

		this.totalCount = totalCount;
		this.currentPage = currentPage;
		this.maxSize = maxSize;

		firstPage = 1;
		lastPage = totalCount / maxSize;
		lastPage = (totalCount % maxSize > 0) ? lastPage + 1 : lastPage;

	}

	public int getTotalCount() {
		return totalCount;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public int getMaxSize() {
		return maxSize;
	}

	public int getLastPage() {
		return lastPage;
	}

	public int getFirstPage() {
		return firstPage;
	}
	
	public int getNext() {
		return currentPage + 1;
	}
	
	public int getPrev() {
		return currentPage - 1;
	}
	
	public int getNumberOne() {
		
		int result = currentPage - 2;
		
		if(result == - 1) {
			result = currentPage;
		}
		
		if(result == 0) {
			result = currentPage - 1;
		}
		
		if(lastPage <= 5) {
			result = 1;
		}
		
		if(result + 4 >= lastPage) {
			result = lastPage - 4;
		}

		return result;
	}
	
	public int getNumberTwo() {
		int page = getNumberOne() + 1;
		return page > lastPage ? 0 : page;
	}

	public int getNumberThree() {
		int page = getNumberOne() + 2;
		return page > lastPage ? 0 : page;
	}

	public int getNumberFour() {
		int page = getNumberOne() + 3;
		return page > lastPage ? 0 : page;
	}

	public int getNumberFive() {
		int page = getNumberOne() + 4;
		return page > lastPage ? 0 : page;
	}

	public boolean isNeedInFront() {
		// last is greater than 5 && current is greater than 4
		return (lastPage > 5 && currentPage > firstPage) || (currentPage > firstPage);
	}
	
	public boolean isNeedBehind() {
		// last is greater than 5 && current + 2 < than last page
		return (lastPage > 5 && currentPage < lastPage) || (currentPage < lastPage);
	}
	

}
