package com.opm.shop.controller.member;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.enterprise.inject.Model;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

@Model
public class DummyLoginBean {

	private String test;
	
	@Inject
	private Event<String> loginEvent;
	
	@PostConstruct
	private void init(){
		try {
			Flash f= FacesContext.getCurrentInstance().getExternalContext().getFlash();
			String email = (String) f.get("email");
			String password = (String) f.get("password");
			
			ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
			HttpServletRequest req = (HttpServletRequest) ctx.getRequest();
			req.login(email, password);
			loginEvent.fire(email);
			
			FacesContext.getCurrentInstance().getExternalContext().redirect("member/member-home.xhtml");
			
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		}
	}

	public String getTest() {
		return test;
	}

	public void setTest(String test) {
		this.test = test;
	}
	
	
}
