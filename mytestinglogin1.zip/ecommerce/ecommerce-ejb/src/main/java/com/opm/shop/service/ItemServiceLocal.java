package com.opm.shop.service;


import java.util.List;

import javax.ejb.Local;

import com.opm.shop.entity.Category;
import com.opm.shop.entity.Item;

@Local
public interface ItemServiceLocal {

	void save(Item item);

	void update(Item item);

	Item findById(long id);

	List<Item> find(int categoryId, String keyword);
	
	List<Item> find(int categoryId, String keyword,int start, int limit);
	
	long findCount(int categoryId, String keyword);

	List<Item> findByMemberId(long id, int start, int limit);
	
	List<Item> findAll(int start,int limit);
	
	List<Item> find(String keyword, int brandId, double startprice, double endprice, int categoryId);
}