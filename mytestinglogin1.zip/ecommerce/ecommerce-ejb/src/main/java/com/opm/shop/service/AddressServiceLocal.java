package com.opm.shop.service;

import java.util.List;

import javax.ejb.Local;

import com.opm.shop.entity.Address;

@Local
public interface AddressServiceLocal {

	void save(Address address);

	void update(Address address);

	List<Address> findAllAddress();

	Address findByLoginMember(long id);

}
