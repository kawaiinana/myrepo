package com.opm.shop.producers;
import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.enterprise.inject.Produces;
import javax.inject.Named;
@ApplicationScoped
public class OrderFormat {
	
	@Named
	@Produces
	private String format;
	
	@PostConstruct
	private void init() {
		format=String.format("VMO-%04d", 12);
	}
}
