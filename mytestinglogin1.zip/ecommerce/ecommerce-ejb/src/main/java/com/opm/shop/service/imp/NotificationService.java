package com.opm.shop.service.imp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Notification.Status;
import com.opm.shop.repo.AccountRepo;
import com.opm.shop.repo.NotificationRepo;
import com.opm.shop.service.NotificationServiceLocal;

@Stateless
public class NotificationService implements NotificationServiceLocal {

	@Inject
	private NotificationRepo repo;
	
	@Inject
	private AccountRepo accountRepo;

	@Override
	public void save(Notification noti) {
		repo.persit(noti);
	}
	
	@Override
	public void update(Notification noti) {
		repo.update(noti);
	}

	@Override
	public List<Notification> findByNewStatus(long notiReceiver, int start, int limit) {
		Map<String, Object> params = new HashMap<>();
		params.put("status", Status.New);
		params.put("notiReceiver", notiReceiver);
		return repo.find("t.status = :status and t.notiReceiver.id = :notiReceiver order by t.security.modification desc", params, start,
				limit);
	}

	@Override
	public List<Notification> findByOldStatus(long notiReceiver, int start, int limit) {
		Map<String, Object> params = new HashMap<>();
		params.put("status", Status.Read);
		params.put("notiReceiver", notiReceiver);
		return repo.find("t.status = :status and t.notiReceiver.id = :notiReceiver order by t.security.modification desc", params, start,
				limit);
	}

	@Override
	public Account findAdmin() {
		Map<String, Object> params = new HashMap<>();
		params.put("role", "Admin");		
		List<Account> admins = accountRepo.find("t.roles = :role ", params);
		
		return admins.get(0);
	}

	@Override
	public Long findCount(long notiReceiver, String nNoti, String oNoti) {		
		Map<String, Object> params = new HashMap<>();
		if(nNoti != null){
			params.put("status", Status.New);
			params.put("notiReceiver", notiReceiver);
			return repo.findCount("t.status = :status and t.notiReceiver.id = :notiReceiver", params);
		}
		params.put("status", Status.Read);
		params.put("notiReceiver", notiReceiver);
		return repo.findCount("t.status = :status and t.notiReceiver.id = :notiReceiver", params);		
	}

}
