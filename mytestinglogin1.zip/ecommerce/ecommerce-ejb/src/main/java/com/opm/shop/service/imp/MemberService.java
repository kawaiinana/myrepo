package com.opm.shop.service.imp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Address;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Member.Status;
import com.opm.shop.repo.AddressRepo;
import com.opm.shop.repo.MembereRepo;
import com.opm.shop.service.MemberServiceLocal;

@Stateless
public class MemberService implements MemberServiceLocal {

	@Inject
	private MembereRepo memRepo;
	@Inject
	private AddressRepo addRepo;

	@Override
	public void save(Member data) {
		if (data.getId() == 0) {
			memRepo.persit(data);
		} else {
			memRepo.update(data);
		}
	}

	@Override
	public Member findById(long id) {
		return memRepo.findById(id);
	}

	@Override
	public List<Member> getAll() {
		return memRepo.find(null, null);
	}

	@Override
	public List<Member> find(String name, int start, int limit) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();

		if (null != name && !name.isEmpty()) {
			sb.append(
					"upper(t.firstName) like upper(:name) or upper(t.lastName) like upper(:name) or upper(t.nickname) like upper(:name)");
			params.put("name", name.concat("%"));
		}

		return memRepo.find(params.size() == 0 ? null : sb.toString(), params.size() == 0 ? null : params, start,
				limit);
	}

	public Address findByMember(long member) {

		String where = "t.member.id = :member and t.primary = :primary";
		Map<String, Object> params = new HashMap<>();
		params.put("member", member);
		// change primary address to false
		params.put("primary", false);

		List<Address> list = addRepo.find(where, params);

		for (Address address : list) {
			return address;
		}
		return null;
	}

	@Override
	public void update(Member member) {
		memRepo.update(member);
	}

	@Override
	public List<Member> findActiveMembers() {
		String where = "t.status = :status ";
		Map<String, Object> params = new HashMap<>();
		params.put("status", Status.Active);
		return memRepo.find(where, params);
	}

	@Override
	public long findCount(String name) {
		StringBuffer sb = new StringBuffer();
		Map<String, Object> params = new HashMap<>();

		if (null != name && !name.isEmpty()) {
			sb.append("upper(t.firstName) like upper(:name) or upper(t.lastName) like upper(:name) or upper(t.nickname) like upper(:name)");
			params.put("name", name.concat("%"));
		}
		return memRepo.findCount(params.size() == 0 ? null : sb.toString(), params.size() == 0 ? null : params);
	}
}
