package com.opm.shop.service;

import java.util.List;

import javax.ejb.Local;

import com.opm.shop.entity.Address;
import com.opm.shop.entity.Member;


@Local
public interface MemberServiceLocal {

	void save(Member member);

	Member findById(long l);

	List<Member> getAll();
	
	List<Member> find(String name, int start, int limit);
	
	Address findByMember(long member);

	void update(Member member);

	List<Member> findActiveMembers();
	
	long findCount(String name);
	
}