package com.opm.myshop.model.entity;

import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
@SuppressWarnings("serial")
public class Product implements Serializable {

    public Product() {
    }

    @Id
    @GeneratedValue(strategy = IDENTITY)
	private long id;

    private String name;

    @ManyToOne
	private Category category;

    @ManyToOne
	private Brand brand;

    private String image;

    @Lob
	private String description;

    @Enumerated
	private Status status;

    @ElementCollection
	private Set<String> sizes;

    @ElementCollection
	private Set<String> colors;

    @OneToMany(mappedBy = "product")
	private Set<Price> prices;

    @ManyToOne
	private Member owner;

    @Embedded
	private SecurityInfo security;


    public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Category getCategory() {
		return category;
	}


	public void setCategory(Category category) {
		this.category = category;
	}


	public Brand getBrand() {
		return brand;
	}


	public void setBrand(Brand brand) {
		this.brand = brand;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Status getStatus() {
		return status;
	}


	public void setStatus(Status status) {
		this.status = status;
	}


	public Set<String> getSizes() {
		return sizes;
	}


	public void setSizes(Set<String> sizes) {
		this.sizes = sizes;
	}


	public Set<String> getColors() {
		return colors;
	}


	public void setColors(Set<String> colors) {
		this.colors = colors;
	}


	public Set<Price> getPrices() {
		return prices;
	}


	public void setPrices(Set<Price> prices) {
		this.prices = prices;
	}


	public Member getOwner() {
		return owner;
	}


	public void setOwner(Member owner) {
		this.owner = owner;
	}


	public SecurityInfo getSecurity() {
		return security;
	}


	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}


	public enum Status {
        Available,
        SoldOut
    }

}