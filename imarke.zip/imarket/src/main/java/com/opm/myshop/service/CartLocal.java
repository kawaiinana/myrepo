package com.opm.myshop.service;

import javax.ejb.Local;

import com.opm.myshop.model.entity.Product;
import com.opm.myshop.model.entity.Purchase;

@Local
public interface CartLocal {

	void addProduct(Product product);
	void clear();
	void setCount(Product p, int count);
	Purchase getPurchase();
	void removeProduct(Product product);
	int getCount();
	int getTotal();
}
