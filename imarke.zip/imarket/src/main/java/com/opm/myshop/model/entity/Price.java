package com.opm.myshop.model.entity;

import java.io.Serializable;

import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;

@Entity
@SuppressWarnings("serial")
public class Price implements Serializable {

	public Price() {
	}

	@EmbeddedId
	private PricePK id;

	private double price;

	@Embedded
	private SecurityInfo security;

	@ManyToOne
	private CommisionRate cmRate;

	@ManyToOne
	@JoinColumn(name = "productId", insertable = false, updatable = false)
	private Product product;

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public PricePK getId() {
		return id;
	}

	public void setId(PricePK id) {
		this.id = id;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}

	public CommisionRate getCmRate() {
		return cmRate;
	}

	public void setCmRate(CommisionRate cmRate) {
		this.cmRate = cmRate;
	}

}