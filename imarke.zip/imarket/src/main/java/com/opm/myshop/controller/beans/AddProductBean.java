package com.opm.myshop.controller.beans;

import javax.inject.Inject;

import com.opm.myshop.model.entity.Product;

public class AddProductBean {

	private Product product;
	
	@Inject
	private AddProductCategoryBean catBean;
	
	@Inject
	private AddProductImageBean imgBean;
}
