package com.opm.myshop.model.entity;

import java.io.Serializable;

import javax.persistence.Embedded;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@SuppressWarnings("serial")
public class PurchaseItem implements Serializable {

	public PurchaseItem() {
	}

	@EmbeddedId
	private PurchaseItemPK id;

	@ManyToOne
	@JoinColumn(name = "purchaseId", insertable = false, updatable = false)
	private Purchase purchase;

	@ManyToOne
	@JoinColumn(name = "productId", insertable = false, updatable = false)
	private Product product;

	private int count;


	private double total;

	private double cmFees;

	@Enumerated
	private Status status;

	@Embedded
	private SecurityInfo security;

	public PurchaseItemPK getId() {
		return id;
	}

	public void setId(PurchaseItemPK id) {
		this.id = id;
	}

	public Purchase getPurchase() {
		return purchase;
	}

	public void setPurchase(Purchase purchase) {
		this.purchase = purchase;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public double getCmFees() {
		return cmFees;
	}

	public void setCmFees(double cmFees) {
		this.cmFees = cmFees;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}

	public enum Status {
		Ordered, Confirmed, Cancel, Delivered, Finished
	}

}