package com.opm.myshop.model.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

import org.hibernate.validator.constraints.NotEmpty;
import javax.persistence.OneToMany;
import static javax.persistence.FetchType.EAGER;

@Entity
@SuppressWarnings("serial")
@NamedQueries({
	@NamedQuery(name="Category.findAll", query="select c from Category c"),
	@NamedQuery(name="Category.findByName", query="select c from Category c where c.name = :name"),
	@NamedQuery(name="Category.findPrimaries", query="select c from Category c where c.parent = null")
})
public class Category implements Serializable {

    public Category() {
    }

    @Id
    @GeneratedValue(strategy = IDENTITY)
	private int id;

    @NotEmpty(message="Please Enter Category Name!")
    @Column(unique=true)
    private String name;

    @ManyToOne
	private Category parent;
    
    
    @OneToMany(mappedBy = "parent", fetch = EAGER, orphanRemoval = true)
	private Set<Category> children;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Category getParent() {
		return parent;
	}

	public void setParent(Category parent) {
		this.parent = parent;
	}

	public Set<Category> getChildren() {
		return children;
	}

	public void setChildren(Set<Category> children) {
		this.children = children;
	}

	//Set ko list pyan pyaung pee ui repeat pat poh
	public List<Category> getChildList(){
		return new ArrayList<>(children);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Category other = (Category) obj;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	
	

}