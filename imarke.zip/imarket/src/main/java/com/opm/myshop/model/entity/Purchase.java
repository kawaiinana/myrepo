package com.opm.myshop.model.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import static javax.persistence.TemporalType.TIMESTAMP;
import javax.persistence.Embedded;
import javax.persistence.OneToMany;

@Entity
@SuppressWarnings("serial")
public class Purchase implements Serializable {

	public Purchase() {
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;

	@ManyToOne
	private Member member;

	@Temporal(TIMESTAMP)
	private Date refDate;

	@OneToMany(mappedBy = "purchase")
	private Set<PurchaseItem> items;

	private double total;

	@Embedded
	private SecurityInfo security;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

	public Date getRefDate() {
		return refDate;
	}

	public void setRefDate(Date refDate) {
		this.refDate = refDate;
	}

	public Set<PurchaseItem> getItems() {
		return items;
	}

	public void setItems(Set<PurchaseItem> items) {
		this.items = items;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}

}