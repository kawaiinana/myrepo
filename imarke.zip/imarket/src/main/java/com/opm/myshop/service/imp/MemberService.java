package com.opm.myshop.service.imp;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import com.opm.myshop.model.entity.Member;
import com.opm.myshop.service.MemberServiceLocal;

@Stateless
public class MemberService implements MemberServiceLocal {
	
	@Inject
	private EntityManager em;

	@Override
	public void create(Member member) {

		em.persist(member);
	}

	@Override
	public List<Member> findAll() {

		
		return em.createNamedQuery("Member.findAll",Member.class)
				.getResultList();
	}

	@Override
	public void changePass(String oldPass, String newPass, String confPass) {
		// TODO Auto-generated method stub

	}

}
