package com.opm.myshop.service.imp;

import java.io.Serializable;

import javax.ejb.Stateful;

import com.opm.myshop.model.entity.Product;
import com.opm.myshop.model.entity.Purchase;
import com.opm.myshop.service.CartLocal;

@Stateful
public class Cart implements CartLocal, Serializable{

	private static final long serialVersionUID = 1L;

	@Override
	public void addProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setCount(Product p, int count) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Purchase getPurchase() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeProduct(Product product) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getTotal() {
		// TODO Auto-generated method stub
		return 0;
	}

}
