package com.opm.myshop.controller.producers;

import javax.enterprise.inject.Produces;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class Resources {

	@Produces
	@PersistenceContext(unitName="imarket")
	private EntityManager em;
}
