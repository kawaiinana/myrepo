package com.opm.myshop.controller.converter;

import javax.enterprise.inject.Model;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Inject;

import com.opm.myshop.model.entity.Category;
import com.opm.myshop.service.CategoryServiceLocal;

@Model
public class CategoryConverter implements Converter{

	@Inject
	private CategoryServiceLocal service;
	
	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		if(null != value && !value.isEmpty()){
			Category c = service.findByname(value);
			
			return c;
		}
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {

		if(null != value){
			Category c = (Category) value;
			return c.getName();
		}
		return null;
	}

}
