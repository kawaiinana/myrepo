package com.opm.myshop.controller.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.inject.Model;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.ws.RespectBinding;

import com.opm.myshop.model.entity.Category;
import com.opm.myshop.service.CategoryServiceLocal;

@ViewScoped
@Named
public class CategoryBean implements Serializable{

	private Category primary1;
	private Category primary2;
	private Category secondary;
	
	private String name1;
	private String name2;

	private List<Category> primaries;
	private List<Category> secondaries;
	private boolean showSecondary;
	
	private List<Category> categories;
	
	@Inject
	private CategoryServiceLocal service;
	
	@PostConstruct
	private void init(){
		primaries = service.findPrimary();
		primary1 = primaries.get(0);
		primary2 = primaries.get(0);
		
		categories = primary1.getChildList();
		
		secondaries = primary2.getChildList();
		secondary = secondaries.size()>0 ? secondaries.get(0) : null;
	}
	
	public String addCategory(){ //void change pee ya ag lote pay par
		
		Category c = new Category();
		
		if(showSecondary){
			c.setParent(secondary);
			c.setName(name2);
			
		}else{
			c.setParent(primary1);
			c.setName(name1);
		}
		
		service.add(c);
		
		name1="";
		name2="";
		
		return "admin/categories?faces-redirect=true";
	}
	
	public void changeCategory(){
		
		secondaries = primary2.getChildList();
		if(null != secondaries && secondaries.size() > 0){
			secondary = secondaries.get(0);
		}else {
			secondary = null;
		}
		loadCategories();
		
	}
	
	public void switchView(boolean secondary){
		
		showSecondary = secondary;
		loadCategories();
	}
	
	public void loadCategories(){
		if (showSecondary) {
			categories = (null == secondary) ? new ArrayList<>() : secondary.getChildList();
		} else {
			categories = (null == primary1) ? new ArrayList<>() : primary1.getChildList();
		}
	}

	public Category getPrimary1() {
		return primary1;
	}

	public void setPrimary1(Category primary1) {
		this.primary1 = primary1;
	}

	public Category getPrimary2() {
		return primary2;
	}

	public void setPrimary2(Category primary2) {
		this.primary2 = primary2;
	}

	public Category getSecondary() {
		return secondary;
	}

	public void setSecondary(Category secondary) {
		this.secondary = secondary;
	}

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}

	public String getName2() {
		return name2;
	}

	public void setName2(String name2) {
		this.name2 = name2;
	}

	public List<Category> getSecondaries() {
		return secondaries;
	}

	public void setSecondaries(List<Category> secondaries) {
		this.secondaries = secondaries;
	}

	public boolean isShowSecondary() {
		return showSecondary;
	}

	public void setShowSecondary(boolean showSecondary) {
		this.showSecondary = showSecondary;
	}

	public List<Category> getPrimaries() {
		return primaries;
	}

	public void setPrimaries(List<Category> primaries) {
		this.primaries = primaries;
	}

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}
	
	
}
