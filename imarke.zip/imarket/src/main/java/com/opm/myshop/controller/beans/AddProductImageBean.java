package com.opm.myshop.controller.beans;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;

import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.Part;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class AddProductImageBean implements Serializable{

	private Part file;
	private String path;

	@Named
	@Inject
	private String imageFilePath;
	
	public void upload(){
		try {
			if(null != path){
				String fileName = file.getSubmittedFileName();
				System.out.println(fileName);
				String[] array = fileName.split("\\.");
				String extension = array[array.length-1];
				path = String.format("%d.%s", new Date().getTime(),extension);
				
				file.write(imageFilePath.concat(path));
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Part getFile() {
		return file;
	}

	public void setFile(Part file) {
		this.file = file;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	
	
}
