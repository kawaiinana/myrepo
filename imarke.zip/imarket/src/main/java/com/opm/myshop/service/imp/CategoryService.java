package com.opm.myshop.service.imp;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import com.opm.myshop.model.entity.Category;
import com.opm.myshop.service.CategoryServiceLocal;

@Stateless
public class CategoryService implements CategoryServiceLocal {

	@Inject
	private EntityManager em;
	
	@Override
	public List<Category> findAll() {
		return em.createNamedQuery("Category.findAll", Category.class).getResultList();
	}

	@Override
	public void add(Category c) {

		em.persist(c);
	}

	@Override
	public Category findByname(String value) {
		List<Category> list = em.createNamedQuery("Category.findByName", Category.class)
								.setParameter("name", value)
								.getResultList();
		
		if(!list.isEmpty()){
			return list.get(0);
		}
		return null;
	}

	@Override
	public List<Category> findPrimary() {
		return em.createNamedQuery("Category.findPrimaries", Category.class).getResultList();
	}

}
