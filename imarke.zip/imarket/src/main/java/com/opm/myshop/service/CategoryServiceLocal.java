package com.opm.myshop.service;

import java.util.List;

import javax.ejb.Local;

import com.opm.myshop.model.entity.Category;

@Local
public interface CategoryServiceLocal {
	
	List<Category> findAll(); 
	
	void add(Category c);

	Category findByname(String value);

	List<Category> findPrimary();
}
