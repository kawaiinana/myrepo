package com.opm.myshop.controller.producers;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.enterprise.inject.Produces;

@ApplicationScoped
public class ImageFileProducer {

	@Produces
	@Named
	private String imageUrl;

	@Produces
	@Named
	private String imageFilePath;
	
	@PostConstruct
	private void init(){
		imageUrl = System.getProperty("imarket.image_url");
		
		imageFilePath = System.getProperty("imarket.image_file_path");
	}
}
