package com.opm.myshop.controller.beans;

import javax.enterprise.inject.Model;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.Digits;

import org.hibernate.validator.constraints.NotEmpty;

import com.opm.myshop.model.entity.Member;
import com.opm.myshop.model.entity.Member.Role;
import com.opm.myshop.service.MemberServiceLocal;

@Model
public class SecurityBean {

	@NotEmpty(message="You must enter Your Name!")
	private String name;
	@NotEmpty(message="You must enter Login ID!")
	private String loginId;
	@NotEmpty(message="You must enter Password!")
	private String password;
	
	private String email;
	
	@Inject
	private MemberServiceLocal service;
	
	public String signUp() {
		
		Member m = new Member();
		m.setLoginId(loginId);
		m.setName(name);
		m.setEmail(email);
		m.setRole(Role.Member);
		m.setPassword(password);
		
		service.create(m);
		
		return login();
	}
	
	public String login() {
		
		try {
			
			ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
			HttpServletRequest req = (HttpServletRequest) ctx.getRequest();
			req.login(loginId, password);

			if(req.isUserInRole("Admin")) {
				return "/admin/home?faces-redirect=true";
			}
			
			return "/member/home?faces-redirect=true";
			
		} catch (Exception e) {
			FacesMessage message = new FacesMessage("Login Error", "Please check your Login ID and Password!");
			FacesContext.getCurrentInstance().addMessage(null, message);
		}
		
		return "";
	}
	
	public String logout() {
		ExternalContext ctx = FacesContext.getCurrentInstance().getExternalContext();
		ctx.invalidateSession();
		return "/index?faces-redirect=true";
	}
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
}
