package com.opm.myshop.service;

import java.util.List;

import javax.ejb.Local;

import com.opm.myshop.model.entity.Member;

@Local
public interface MemberServiceLocal {

	void create(Member member);
	List<Member> findAll();
	void changePass(String oldPass,String newPass,String confPass);
}
