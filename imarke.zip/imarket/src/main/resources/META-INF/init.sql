insert into Category (name) values ('Mens');
insert into Category (name) values ('Ladies');
insert into Category (name) values ('Boys');
insert into Category (name) values ('Girls');

insert into Member (loginId, name, password, role) values ('imadmin', 'Imarket Admin', 'bwGRyKXwghMTBeCDtvbAKUNrj04NClNS5Zqz5VfbK0U=', 'Admin');
