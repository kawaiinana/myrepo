package com.opm.shop.repo;

import com.opm.shop.entity.Notification;

public class NotificationRepo extends AbstractRepository<Notification> {

	public NotificationRepo() {
		super(Notification.class);
	}

} 