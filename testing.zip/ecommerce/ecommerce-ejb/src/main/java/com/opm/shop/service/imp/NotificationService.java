package com.opm.shop.service.imp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.opm.shop.entity.Member;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Notification.Status;
import com.opm.shop.repo.NotificationRepo;
import com.opm.shop.service.NotificationServiceLocal;

@Stateless
public class NotificationService implements NotificationServiceLocal {

	@Inject
	private NotificationRepo repo;

	@Override
	public void save(Notification noti) {
		repo.persit(noti);
	}

	@Override
	public List<Notification> findByNewStatus() {
		Map<String, Object> params = new HashMap<>();
		params.put("status", Status.New);
		return repo.find("t.status = :status ", params);
	}

	public long getNotiCount(Member member) {
		Map<String, Object> params = new HashMap<>();
		params.put("status", Status.New);
		return repo.findCount("t.status = :status ", params);
	}
}
