package com.opm.shop.entity;

import static javax.persistence.EnumType.STRING;
import static javax.persistence.FetchType.EAGER;
import static javax.persistence.GenerationType.IDENTITY;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.MapKeyColumn;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Basic;

@SuppressWarnings("serial")
@Entity
public class Item implements Serializable {

	public enum Status {
		Available, SoldOut, Ban
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)
	private long id;
	private String name;
	private double price;

//	@MapKeyColumn(name = "language")
//	@ElementCollection
//	private Map<String, String> names;

	@Lob
	private String description;

	@Basic(fetch = EAGER)
	@ElementCollection
	private List<String> image;

	@Enumerated(STRING)
	private Status status;

	private String size;

	private String color;

	@MapKeyColumn(name = "language")
	@ElementCollection
	private Map<String, String> descriptions;

	@ElementCollection(fetch = EAGER)
	private Set<Country> country;

	@ElementCollection(fetch = EAGER)
	private Set<State> state;

	@ManyToOne
	private Member owner;

	@ManyToOne
	private Category category;

	@ManyToOne(fetch = FetchType.LAZY)
	private Brand brand;

	@ManyToOne
	private ItemState itemState;

	@ElementCollection(fetch = FetchType.EAGER)
	private Set<Price> prices;

	@Embedded
	private SecurityInfo security;

	@PrePersist
	private void prePersist() {
		security = new SecurityInfo();
		security.setCreation(new Date());
		security.setModification(new Date());
		security.setCreateUser(2);
	}

	@PreUpdate
	private void preUpdate() {
		if (null == security) {
			security = new SecurityInfo();
			security.setCreation(new Date());
			security.setCreateUser(2);
		}
		security.setModification(new Date());
	}

	private int level() {
		return category.getParent() == null ? 1
				: category.getParent().getParent() == null ? 2
						: category.getParent().getParent().getParent() == null ? 3 : 0;
	}

	public String getFirstCategory() {
		return level() == 1 ? category.getName()
				: level() == 2 ? category.getParent().getName()
						: level() == 3 ? category.getParent().getParent().getName() : "";
	}

	public String getSecondCategory() {
		return level() == 1 ? ""
				: level() == 2 ? category.getName() : level() == 3 ? category.getParent().getName() : "";
	}

	public String getThirdCategory() {
		return level() == 1 ? "" : level() == 2 ? "" : level() == 3 ? category.getName() : "";
	}

	public Item() {
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

//	public Map<String, String> getNames() {
//		return names;
//	}
//
//	public void setNames(Map<String, String> names) {
//		this.names = names;
//	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	public List<String> getImage() {
		return image;
	}

	public void setImage(List<String> image) {
		this.image = image;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;

	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Set<Country> getCountry() {
		return country;
	}

	public void setCountry(Set<Country> country) {
		this.country = country;
	}

	public Set<State> getState() {
		return state;
	}

	public void setState(Set<State> state) {
		this.state = state;
	}

	public Map<String, String> getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(Map<String, String> descriptions) {
		this.descriptions = descriptions;
	}

	public Member getOwner() {
		return owner;
	}

	public void setOwner(Member owner) {
		this.owner = owner;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	public ItemState getItemState() {
		return itemState;
	}

	public void setItemState(ItemState itemState) {
		this.itemState = itemState;
	}

	public Set<Price> getPrices() {
		return prices;
	}

	public void setPrices(Set<Price> prices) {
		this.prices = prices;
	}

	public SecurityInfo getSecurity() {
		return security;
	}

	public void setSecurity(SecurityInfo security) {
		this.security = security;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((country == null) ? 0 : country.hashCode());
//		result = prime * result + ((names == null) ? 0 : names.hashCode());
		result = prime * result + ((prices == null) ? 0 : prices.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (brand == null) {
			if (other.brand != null)
				return false;
		} else if (!brand.equals(other.brand))
			return false;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
//		if (names == null) {
//			if (other.names != null)
//				return false;
//		} else if (!names.equals(other.names))
//			return false;
		if (prices == null) {
			if (other.prices != null)
				return false;
		} else if (!prices.equals(other.prices))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		return true;
	}

}