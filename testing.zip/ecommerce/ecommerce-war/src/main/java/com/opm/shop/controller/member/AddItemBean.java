package com.opm.shop.controller.member;

import java.io.IOException;
import java.io.Serializable;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import javax.annotation.PostConstruct;
import javax.faces.flow.FlowScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.Part;

import com.opm.shop.controller.admin.BrandBean;
import com.opm.shop.entity.Account;
import com.opm.shop.entity.CommissionRate;
import com.opm.shop.entity.Country;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Item.Status;
import com.opm.shop.entity.Price;
import com.opm.shop.entity.State;
import com.opm.shop.service.ItemServiceLocal;

@SuppressWarnings("serial")
@Named
@FlowScoped("product")
public class AddItemBean implements Serializable {

	public AddItemBean() {
	}

	private List<CommissionRate> rateList;
	
	private Part file;

	private String path;

	@Named
	@Inject
	private String imageFilePath;
	
	private List<String> images;

	@Inject
	private BrandBean brandBean;

	private CommissionRate commissionRate;

	@Inject
	private ItemServiceLocal service;

	@Inject
	private ItemListBean itemListBean;

	private Set<State> selectedState;

	private Set<Country> selectedCountry;

	private Set<Price> prices;
	
	@Named
	@Inject
	private Account loginUser;

	private Item item;

	@PostConstruct
	public void init() {
		item = new Item();
		selectedState = new LinkedHashSet<>();
		selectedCountry = new LinkedHashSet<>();
		prices = new LinkedHashSet<>();
	}

	public void calRate() {
		/*
		 * rateList = rateService.calculateRate(commissionRate.getAmountFrom(),
		 * commissionRate.getAmountTo(), commissionRate.getRate());
		 */ 
	//	Item rate = service.findByPrice(item.getPrice());
		//System.out.println(rate.toString() + " this is calculate Rate");
		
		item.setPrices(getPrices());
		System.out.println(item.getPrices());
	}
	
public void upload() {
		
		System.out.println("File In Start Upload"+file);
		try {
			if (null != file) {
				String fileName = file.getSubmittedFileName();
				System.out.println(fileName);
				String[] array = fileName.split("\\.");
				String extension = array[array.length - 1];
				path = String.format("%d.%s", new Date().getTime(), extension);
				file.write(imageFilePath.concat(path));
				System.out.println("Path in For Looping="+path);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		images.add(path);
		item.setImage(images);
		service.save(item);
		System.out.println("Path in end upload=" + path);
		System.out.println("File in end upload="+file);

	}

	public String save() {
		if (item.getSize() != null) {
			System.out.println(item.getName());
			System.out.println(item.getDescription());
			System.out.println(item.getColor());
			System.out.println(item.getSize());
			System.out.println(item.getPrice());
			System.out.println(getSelectedCountry());
		}
		calRate();
		item.setStatus(Status.Available);
		item.setState(selectedState);
		item.setCountry(selectedCountry);
		service.save(item);
		item = new Item();
		return "/member/product-listing.xhtml?faces-redirect=true";
	}
	
	public Part getFile() {
		return file;
	}

	public void setFile(Part file) {
		this.file = file;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getImageFilePath() {
		return imageFilePath;
	}

	public void setImageFilePath(String imageFilePath) {
		this.imageFilePath = imageFilePath;
	}

	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

	public Account getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(Account loginUser) {
		this.loginUser = loginUser;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public List<CommissionRate> getRateList() {
		return rateList;
	}

	public void setRateList(List<CommissionRate> rateList) {
		this.rateList = rateList;
	}

	public CommissionRate getCommissionRate() {
		return commissionRate;
	}

	public void setCommissionRate(CommissionRate commissionRate) {
		this.commissionRate = commissionRate;
	}

	public ItemListBean getItemListBean() {
		return itemListBean;
	}

	public void setItemListBean(ItemListBean itemListBean) {
		this.itemListBean = itemListBean;
	}

	public BrandBean getBrandBean() {
		return brandBean;
	}

	public void setBrandBean(BrandBean brandBean) {
		this.brandBean = brandBean;
	}

	public Set<State> getSelectedState() {
		return selectedState;
	}

	public void setSelectedState(Set<State> selectedState) {
		this.selectedState = selectedState;
	}

	public Set<Country> getSelectedCountry() {
		return selectedCountry;
	}

	public void setSelectedCountry(Set<Country> selectedCountry) {
		this.selectedCountry = selectedCountry;
	}

	public Set<Price> getPrices() {
		return prices;
	}

	public void setPrices(Set<Price> prices) {
		this.prices = prices;
	}
}
