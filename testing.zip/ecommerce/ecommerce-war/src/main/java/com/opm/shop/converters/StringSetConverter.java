package com.opm.shop.converters;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.enterprise.context.RequestScoped;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.inject.Named;

@Named
@RequestScoped
public class StringSetConverter implements Converter {

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		// TODO Auto-generated method stub
		return null ;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		if(null != value && value instanceof Set) {
			Set<String> set = (Set<String>) value;
			List<String> list = new ArrayList<>(set);
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < list.size(); i++) {
				
				if(i > 0) {
					sb.append(", ");
				}
				
				sb.append(list.get(i));
			}
			
			return sb.toString();
		}
		return null;
	}

}
