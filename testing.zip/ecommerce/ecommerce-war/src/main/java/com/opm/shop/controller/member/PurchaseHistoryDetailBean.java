package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.event.Event;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Account;
import com.opm.shop.entity.Comment;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.Notification;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.CommentServiceLocal;
import com.opm.shop.service.NotificationServiceLocal;
import com.opm.shop.service.OrderServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class PurchaseHistoryDetailBean implements Serializable {

	public PurchaseHistoryDetailBean() {
	}

	@Inject
	private OrderServiceLocal service;
	
	private Order order;
	
	private Notification noti;
	
	@Inject
	@Named
	private Account loginMember;
	
	@Named("loginMember")
	@Inject
	private Member loginMem;
	private boolean enableAction;
	
	private Comment comment;

	private List<Comment> comments;
	
	@Inject
	private CommentServiceLocal commentService;
	
	@Inject
	private NotificationServiceLocal notiService;
	
	@Inject
	private Event<Comment> notiEvent;

	private long count;
	
	@PostConstruct
	public void init() {
		noti = new Notification();
		order = new Order();
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		comment=new Comment();
		
		if (null != str) {
			order = service.findById(Long.parseLong(str));
			enableAction = order.getStatus() == Status.ConfirmShipment;
			comments=commentService.findByOrderId(Long.parseLong(str));
		}

	}
	
	public String addComment(boolean isSellerComment) {
		
		comment.setOrder(order);
		comment.setOwner(loginMem);
		
		commentService.save(comment);
		
		addCommentNoti(isSellerComment);
		notiEvent.fire(comment);
		
		if(!isSellerComment){
			return "/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		}else{
			return "/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		}
	}
	
	public void addCommentNoti(boolean isSellerComment){
		
		if(isSellerComment){
			noti.setNotiReceiver(order.getBuyer());
			noti.setNotiURL("/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
		}else {
			noti.setNotiReceiver(order.getItem().getOwner());
			noti.setNotiURL("/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId());
		}
		noti.getSecurity().setCreation(new Date());
		noti.setOrder(order);
		noti.setStatus(com.opm.shop.entity.Notification.Status.New);
		noti.setNotiString(loginMem.getNickname()+" commented on "+order.getItem().getName() +" Order.");
		
		notiService.save(noti);
		
	}
	
	public String deleteComment(long commentId,boolean isSellerComment){
		
		commentService.delete(commentId);
		
		if(!isSellerComment){
			return "/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		}else{
			return "/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		}
	}
	
	public String updateComment(Comment comment,boolean isSellerComment) {
		
		commentService.update(comment);
		
		if(!isSellerComment){
			return "/member/purchase-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		}else{
			return "/member/sale-history-detail.xhtml?faces-redirect=true&id=" + order.getId();
		}
	}


	public boolean isEnableAction() {
		return enableAction;
	}

	public void setEnableAction(boolean enableAction) {
		this.enableAction = enableAction;
	}

	public String confrimShippmentAction() {

		order.setStatus(Status.Completed);
		order.getSecurity().setModUser(loginMember.getId());
		service.save(order);
		return "/member/purchase-history.xhtml?faces-redirect=true";
	}

	public String orderCancelAction() {
		return "";
	}

	public Order getOrder() {
		return order;
	}

	public Member getLoginMem() {
		return loginMem;
	}

	public void setLoginMem(Member loginMem) {
		this.loginMem = loginMem;
	}

	public Comment getComment() {
		return comment;
	}

	public void setComment(Comment comment) {
		this.comment = comment;
	}

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Account getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Account loginMember) {
		this.loginMember = loginMember;
	}

	public Notification getNoti() {
		return noti;
	}

	public void setNoti(Notification noti) {
		this.noti = noti;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	
}