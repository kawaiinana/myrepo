package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Address;
import com.opm.shop.entity.City;
import com.opm.shop.entity.Country;
import com.opm.shop.entity.Item;
import com.opm.shop.entity.Member;
import com.opm.shop.entity.State;
import com.opm.shop.service.AddressServiceLocal;
import com.opm.shop.service.CityServiceLocal;
import com.opm.shop.service.CountryServiceLocal;
import com.opm.shop.service.StateServiceLocal;

@SuppressWarnings("serial")
@ViewScoped
@Named
public class AddressBean implements Serializable {

	@Named
	@Inject
	private Member loginMember;

	@Inject
	private AddressServiceLocal addService;

	@Inject
	private CityServiceLocal cityService;

	@Inject
	private StateServiceLocal stateService;
	@Inject
	private CountryServiceLocal countryService;
	
	private Item item;
	
	private List<Address> addresses;
	private Address address;
	private List<Country> countries;
	private List<State> states;
	private List<City> cities;

	private Country country;
	private State state;

	@PostConstruct
	private void init() {

		address = addService.findByLoginMember(loginMember.getId());

		if (null == address) {
			address = new Address();			
			states = new ArrayList<>();
			cities = new ArrayList<>();
		} else {
			country = address.getCity().getState().getCountry();
			state = address.getCity().getState();
			
			states = stateService.findByCountry(country);
			cities = cityService.findByState(state);

		}
		
		countries = countryService.getAll();
		addresses = addService.findAllAddress();
	}

	public void loadStates() {
		if (country == null) {
			states.clear();
			cities.clear();
		} else {
			states = stateService.findByCountry(country);
		}

	}

	public void loadCities() {
		cities = cityService.findByState(state);
	}

	public void loads() {
		loadStates();
		loadCities();
	}

	public String create() {

		if (!addresses.stream().filter(a -> a.getMember().getId() == loginMember.getId()).findAny().isPresent()) {
			System.out.println("Address Created!");
			address.setMember(loginMember);
			addService.save(address);
		} else {
			System.out.println("Address Updated!");
			System.out.println("Address Id : " + address.getId());
			address.setMember(loginMember);
			addService.update(address);
		}

		return "/index?faces-redirect=true";
	}

	public void checkOutCreate(){

		if (!addresses.stream().filter(a -> a.getMember().getId() == loginMember.getId()).findAny().isPresent()) {
			System.out.println("Address Created!");
			address.setMember(loginMember);
			addService.save(address);
		} else {
			System.out.println("Address Updated!");
			System.out.println("Address Id : " + address.getId());
			address.setMember(loginMember);
			addService.update(address);
		}
	}

	public Member getLoginMember() {
		return loginMember;
	}

	public void setLoginMember(Member loginMember) {
		this.loginMember = loginMember;
	}

	public AddressServiceLocal getAddService() {
		return addService;
	}

	public void setAddService(AddressServiceLocal addService) {
		this.addService = addService;
	}

	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public List<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(List<Address> addresses) {
		this.addresses = addresses;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public List<Country> getCountries() {
		return countries;
	}

	public void setCountries(List<Country> countries) {
		this.countries = countries;
	}

	public List<State> getStates() {
		return states;
	}

	public void setStates(List<State> states) {
		this.states = states;
	}

	public List<City> getCities() {
		return cities;
	}

	public void setCities(List<City> cities) {
		this.cities = cities;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	public State getState() {
		return state;
	}

	public void setState(State state) {
		this.state = state;
	}

}
