package com.opm.shop.controller.member;

import java.io.Serializable;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;

import com.opm.shop.entity.Comment;
import com.opm.shop.entity.Order;
import com.opm.shop.entity.Order.Status;
import com.opm.shop.service.CommentServiceLocal;
import com.opm.shop.service.OrderServiceLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CommentBean implements Serializable{
	
	private Order order;
	
	private Comment comment;
	
	private List<Comment> comments;
	
	private OrderServiceLocal orderService;
	
	private CommentServiceLocal commentService;
	
	@PostConstruct
	public void init() {		
		
	}


}
