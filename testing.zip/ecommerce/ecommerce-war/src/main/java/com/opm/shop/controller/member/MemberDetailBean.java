package com.opm.shop.controller.member;

import java.io.Serializable;

import javax.annotation.PostConstruct;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Address;

import com.opm.shop.entity.Member;
import com.opm.shop.entity.Member.Status;
import com.opm.shop.service.MemberServiceLocal;

@Named
@ViewScoped
@SuppressWarnings("serial")
public class MemberDetailBean implements Serializable {

	public MemberDetailBean() {
	}

	@Inject
	private MemberServiceLocal service;
	
	private Address member;
	private Member mem;
	
	// private Gender gender;

	@PostConstruct
	public void init() {
		
		String str = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("id");
		mem = service.findById(Long.parseLong(str));
		member = service.findByMember(Long.parseLong(str));
		//System.out.println("member"+member);
		
	}
	
	public void ban() {
		mem.setStatus(Status.Ban);
		service.update(mem);
	}

	public String buy() {
		return "";
	}

	public Address getMember() {
		return member;
	}

	public void setMember(Address address) {
		this.member = address;
	}

	public Member getMem() {
		return mem;
	}

	public void setMem(Member mem) {
		this.mem = mem;
	}
	
}