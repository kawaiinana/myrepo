package com.opm.shop.controller.admin;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject;
import javax.inject.Named;

import com.opm.shop.entity.Category;
import com.opm.shop.service.CategoryServiceLocal;

@SuppressWarnings("serial")
@Named
@ViewScoped
public class CategoryBean implements Serializable {
	@Inject
	private CategoryServiceLocal service;

	private Category category;
	private Category filterFirstCategory;
	private Category filterSecondCategory;
	private Category firstCategory;
	private Category secondCategory;
	private int categoryLevel;

	private List<Category> categoryList;
	private List<Category> filterSecondCategories;
	private List<Category> secondCategories;

	@PostConstruct
	private void init() {
		firstCategoryAction();
		categoryList = service.findAll();
		System.out.println("Reload Category");
	}

	public String search() {
		categoryList = new ArrayList<>();
		if (filterSecondCategory != null) {
			categoryList = filterSecondCategory.getChildren();
		} else if (filterFirstCategory != null) {
			categoryList = filterFirstCategory.getChildren();
		} else if (filterFirstCategory == null)
			categoryList = service.findAll();
		return "" ;
	}

	public String delete(Category c) {
		c.setDeleteFlag(true);
		service.save(c);
		return "/admin/category.xhtml?faces-redirect=true";
	}

	public void add() {
		firstCategoryAction();
	}

	public void edit(Category c) {
		category = c;
		categoryLevel = 1;
	}

	public String save() {
		
		try {
			if (categoryLevel == 2) {
				if(firstCategory==null){
					FacesMessage message = new FacesMessage("Please Choose First Category");
					FacesContext.getCurrentInstance().addMessage(null, message);
					return "";
				}
				category.setParent(firstCategory);
			} else if (categoryLevel == 3) {
				if(secondCategory==null){
					FacesMessage message = new FacesMessage("Please Choose First Category");
					FacesContext.getCurrentInstance().addMessage(null, message);
					return "";
				}
				category.setParent(secondCategory);
			}
			
			service.save(category);
			
			return "/admin/category.xhtml?faces-redirect=true";			
		} catch (RuntimeException e) {
			FacesMessage message = new FacesMessage("Application Error", e.getCause().getMessage());
			FacesContext.getCurrentInstance().addMessage(null, message);
		}

		return "";

	}

	private void reset() {
		firstCategory = null;
		category = new Category();
		loadCategories();
	}

	public void firstCategoryAction() {
		categoryLevel = 1;
		reset();
	}

	public void secondCategoryAction() {
		categoryLevel = 2;
		reset();
	}

	public void thirdCategoryAction() {
		categoryLevel = 3;
		reset();
		loadCategories();
		System.out.println(secondCategories);
	}

	public void loadSecondCategories() {
		if (filterFirstCategory == null)
			filterSecondCategories = new ArrayList<>();
		else
			filterSecondCategories = filterFirstCategory.getChildren();
	}

	public void loadCategories() {
		System.out.println(firstCategory);
		if (firstCategory == null)
			secondCategories = new ArrayList<>();
		else
			secondCategories = firstCategory.getChildren();	
	}


	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public int getCategoryLevel() {
		return categoryLevel;
	}

	public void setCategoryLevel(int categoryLevel) {
		this.categoryLevel = categoryLevel;
	}

	public List<Category> getCategoryList() {
		return categoryList;
	}

	public void setCategoryList(List<Category> categoryList) {
		this.categoryList = categoryList;
	}

	public Category getFilterFirstCategory() {
		return filterFirstCategory;
	}

	public void setFilterFirstCategory(Category filterFirstCategory) {
		this.filterFirstCategory = filterFirstCategory;
	}

	public Category getFilterSecondCategory() {
		return filterSecondCategory;
	}

	public void setFilterSecondCategory(Category filterSecondCategory) {
		this.filterSecondCategory = filterSecondCategory;
	}

	public List<Category> getFilterSecondCategories() {
		return filterSecondCategories;
	}

	public void setFilterSecondCategories(List<Category> filterSecondCategories) {
		this.filterSecondCategories = filterSecondCategories;
	}

	public Category getFirstCategory() {
		return firstCategory;
	}

	public void setFirstCategory(Category firstCategory) {
		this.firstCategory = firstCategory;
	}

	public Category getSecondCategory() {
		return secondCategory;
	}

	public void setSecondCategory(Category secondCategory) {
		this.secondCategory = secondCategory;
	}

	public List<Category> getSecondCategories() {
		return secondCategories;
	}

	public void setSecondCategories(List<Category> secondCategories) {
		this.secondCategories = secondCategories;
	}

}